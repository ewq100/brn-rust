from pathlib import Path
import subprocess,sys,json,hashlib,difflib,datetime
arm=sys.argv[1];root=Path(sys.argv[2]);out=Path('/workspace/brn-provider-263/maintenance')/('alias-full-'+arm);out.mkdir(exist_ok=True)
ai='crates/brn-ai/src/';app='crates/brn-threads-app/src/';core='crates/brn-threads-core/src/'
paths=[str(p.relative_to(root)) for d in (ai,app,core) for p in (root/d).glob('*.rs')]
base={p:(root/p).read_bytes() for p in paths}
def read(p):return (root/p).read_text()
def write(p,s):(root/p).write_text(s)
def repl(p,a,b):
 s=read(p);assert a in s,(p,a);write(p,s.replace(a,b))
modified=[]
try:
 if arm=='before':
  for p,a,b in [
   (ai+'lib.rs','"copilot" => Some(Self::Copilot)','"copilot" | "github-copilot" => Some(Self::Copilot)'),
   (app+'run.rs','"copilot" => Provider::Copilot','"copilot" | "github-copilot" => Provider::Copilot'),
   (app+'subscription_search.rs','"copilot" => {','"copilot" | "github-copilot" => {'),
   (ai+'threads_research.rs','settings.provider.eq_ignore_ascii_case("copilot")','["copilot", "github-copilot"].iter().any(|s| settings.provider.eq_ignore_ascii_case(s))'),
   (app+'settings.rs','!helper.provider.eq_ignore_ascii_case("copilot")','!["copilot", "github-copilot"].iter().any(|s| helper.provider.eq_ignore_ascii_case(s))'),
   (ai+'threads.rs','Provider::Copilot => s.provider.eq_ignore_ascii_case("copilot"),','Provider::Copilot => ["copilot", "github-copilot"].iter().any(|name| s.provider.eq_ignore_ascii_case(name)),'),
   (core+'store.rs','|| (subscription_provider(&run.provider) && subscription_provider(&settings.provider)))','|| (subscription_provider(&run.provider) && subscription_provider(&settings.provider))\n        || [&run.provider, &settings.provider].iter().all(|p| ["copilot", "github-copilot"].iter().any(|name| p.eq_ignore_ascii_case(name))))'),
  ]:repl(p,a,b);modified.append(p)
 else:
  p=core+'types.rs';repl(p,'("copilot", "copilot"),','("copilot", "copilot"), ("github-copilot", "copilot"),');modified.append(p)
 p=ai+'threads_research.rs';write(p,read(p)+'''
#[cfg(test)]
#[test]
fn maintenance_263_alias_full_helper() {
 let choice=HelperChoice::from_settings(&HelperSettings {provider:"GitHub-CoPiLoT".into(),model:"gpt-6-luna".into(),effort:"high".into(),auth_file:None,credentials_dir:None}).unwrap();
 assert_eq!(choice.selection.provider,Provider::Copilot);assert_eq!(choice.effort,ReasoningEffort::High);
}
''')
 p=app+'subscription_search.rs';write(p,read(p)+'''
#[cfg(test)]
#[test]
fn maintenance_263_alias_full_saved_settings_and_run_fence() {
 let root=tempfile::tempdir().unwrap();
 let mut workspace=Workspace::open_without_default_credentials(root.path().join("workspace")).unwrap();
 let mut s=workspace.settings().unwrap();
 s.provider="GitHub-CoPiLoT".into();s.model="gpt-6-luna".into();s.effort="high".into();s.auth_file=None;s.credentials_dir=Some(root.path().join("synthetic-credentials").display().to_string());s.delegation_chosen=true;
 s.helper=Some(brn_threads_core::HelperSettings {provider:s.provider.clone(),model:s.model.clone(),effort:s.effort.clone(),auth_file:None,credentials_dir:s.credentials_dir.clone()});
 workspace.configure(s.clone()).unwrap();
 let saved=workspace.settings().unwrap();assert_eq!(saved.provider,s.provider);assert_eq!(saved.helper,s.helper);
 let (selection,effort)=resolve_run_selection(&saved,None).unwrap();assert_eq!(selection.provider,Provider::Copilot);assert_eq!(effort,ReasoningEffort::High);
 assert_eq!(prepare(&saved,"q".into()).unwrap_err(),SearchError::CopilotNoLogin.to_string());
 let account=brn_ai::conversion::ConversionAccount::capture(Provider::from_setting(&saved.provider),None,None);
 assert!(matches!(account,brn_ai::conversion::ConversionAccount::Copilot {credentials_dir:None,account:None}));
 let chat=workspace.new_thread("alias fixture").unwrap();
 let prepared=workspace.prepare_thread_run(crate::ThreadRunStart {thread:chat.id,prompt:"No model dispatch".into(),request_message:None,queue_claim:None,owner_request:None,sources:vec![],max_tool_rounds:Some(1),trace:crate::TraceLevel::Off,offered_copilot_models:None,requested_skills:vec![]}).unwrap();
 let record=workspace.store.record(prepared.prepared.run_id()).unwrap().unwrap();
 let RecordData::Run(run)=record.data else {panic!("prepared run")};
 assert!(run.provider.eq_ignore_ascii_case("copilot"));assert_eq!(run.state,brn_threads_core::RunState::Working);
 drop(prepared);
 s.effort="HIGH".into();s.model="invalid model".into();
 assert!(matches!(resolve_run_selection(&s,Some(&["gpt-6-luna".into()])),Err(crate::RunSelectionError::CopilotCatalogue {..})));
 assert!(matches!(resolve_run_selection(&s,None),Err(crate::RunSelectionError::Effort)));
}
''')
 patch=''.join(''.join(difflib.unified_diff(base[p].decode().splitlines(True),read(p).splitlines(True),fromfile=p,tofile=p)) for p in base if (root/p).read_bytes()!=base[p]);(out/'change.patch').write_text(patch)
 with (out/'test.log').open('wb') as f:
  result=subprocess.run(['python3','/workspace/brn-environment/run-with-reaping.py','cargo','test','--workspace','--lib','maintenance_263_alias_full','--locked','--offline'],cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 import re
 log=(out/'test.log').read_text();cases=re.findall(r'^test .*maintenance_263_alias_full.* \.\.\. ok$',log,re.M)
 receipt={'arm':arm,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'exit_status':result.returncode,'intended_cases':cases,'production_files':modified,'acceptance_scope':'Saved helper configuration and a real canonical-provider prepared Run admitted through the durable settings fence; direct helper/search/refinement selection and error precedence. No model request.','pilot_limit':'Earlier alias pass was a limited routing pilot; first full-scope launch was invalid fixture setup and is retained separately. This is one bounded corrected full-scope run at most10min per arm, with7 baseline production sites. Original2-attempt plan was exceeded by the invalid setup invocation; no invocation is erased or Cycle2 budget reopened. No elapsed/coding-difficulty claim.','log_sha256':hashlib.sha256((out/'test.log').read_bytes()).hexdigest()}
 (out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
 assert result.returncode==0 and len(cases)==2,receipt
finally:
 for p,data in base.items():(root/p).write_bytes(data)
 assert all((root/p).read_bytes()==data for p,data in base.items())
print(json.dumps({'arm':arm,'accepted':True,'source_restored':True}))
