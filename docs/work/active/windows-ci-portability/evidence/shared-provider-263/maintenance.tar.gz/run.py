from pathlib import Path
import sys,subprocess,json,hashlib,time,datetime
arm=sys.argv[1]; root=Path(sys.argv[2]); out=Path('/workspace/brn-provider-263/maintenance')/arm;out.mkdir(exist_ok=True)
ai='crates/brn-ai/src/'; app='crates/brn-threads-app/src/'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base={str(p.relative_to(root)):p.read_bytes() for d in ('crates/brn-ai/src','crates/brn-threads-app/src') for p in (root/d).glob('*.rs')}
start=time.monotonic(); receipts=[]
def read(p):return (root/p).read_text()
def write(p,s):(root/p).write_text(s)
def repl(p,a,b):
 s=read(p);assert a in s,(p,a);write(p,s.replace(a,b))
def append(p,s):write(p,read(p)+'\n'+s)
def run(label,args):
 with (out/(label+'.log')).open('wb') as f:
  p=subprocess.run(['python3','/workspace/brn-environment/run-with-reaping.py',*args],cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 assert p.returncode==0,(label,p.returncode)
 return {'command':args,'exit_status':p.returncode,'log':label+'.log','sha256':sha(out/(label+'.log'))}
def restore():
 for p,data in base.items():(root/p).write_bytes(data)
for task in ('alias','binding-diagnostic','retry-hint'):
 assert time.monotonic()-start<1800,'per-arm allocation exhausted'
 modified=[]
 try:
  if task=='alias':
   owner=ai+('lib.rs' if arm=='before' else 'provider.rs')
   repl(owner,'"copilot" => Some(Self::Copilot)','"copilot" | "github-copilot" => Some(Self::Copilot)');modified.append(owner)
   if arm=='before':
    repl(app+'run.rs','"copilot" => Provider::Copilot','"copilot" | "github-copilot" => Provider::Copilot');modified.append(app+'run.rs')
    repl(app+'subscription_search.rs','"copilot" => {','"copilot" | "github-copilot" => {');modified.append(app+'subscription_search.rs')
    repl(ai+'threads_research.rs','settings.provider.eq_ignore_ascii_case("copilot")','["copilot", "github-copilot"].iter().any(|s| settings.provider.eq_ignore_ascii_case(s))');modified.append(ai+'threads_research.rs')
   append(ai+'threads_research.rs','''#[cfg(test)]
#[test]
fn maintenance_263_alias_helper() {
 let choice=HelperChoice::from_settings(&HelperSettings {provider:"GitHub-CoPiLoT".into(),model:"gpt-6-luna".into(),effort:"high".into(),auth_file:None,credentials_dir:None}).unwrap();
 assert_eq!(choice.selection.provider, Provider::Copilot);
 assert_eq!(choice.effort, ReasoningEffort::High);
 assert!(choice.account.is_none());
}
''')
   append(app+'subscription_search.rs','''#[cfg(test)]
#[test]
fn maintenance_263_alias_hosts() {
 let root=tempfile::tempdir().unwrap();
 let workspace=Workspace::open_without_default_credentials(root.path()).unwrap();
 let mut s=workspace.settings().unwrap();
 s.provider="GitHub-CoPiLoT".into();s.model="gpt-6-luna".into();s.effort="high".into();s.auth_file=None;s.credentials_dir=None;
 let (selection,effort)=resolve_run_selection(&s,None).unwrap();
 assert_eq!(selection.provider,Provider::Copilot);assert_eq!(effort,ReasoningEffort::High);
 assert_eq!(prepare(&s,"q".into()).unwrap_err(),SearchError::CopilotNoLogin.to_string());
 let account=brn_ai::conversion::ConversionAccount::capture(Provider::from_setting(&s.provider),None,None);
 assert!(matches!(account,brn_ai::conversion::ConversionAccount::Copilot {credentials_dir:None,account:None}));
 s.effort="HIGH".into();s.model="invalid model".into();
 assert!(matches!(resolve_run_selection(&s,Some(&["gpt-6-luna".into()])),Err(crate::RunSelectionError::CopilotCatalogue {..})));
 assert!(matches!(resolve_run_selection(&s,None),Err(crate::RunSelectionError::Effort)));
}
''')
  elif task=='binding-diagnostic':
   for p in [ai+'auth.rs',ai+'error.rs']:
    repl(p,'"account_changed"','"sign_in_changed"');modified.append(p)
   for test in ('provider_tests.rs','auth_race_tests.rs'):
    if (root/(ai+test)).exists():repl(ai+test,'Some("account_changed")','Some("sign_in_changed")')
   append(ai+'auth.rs','''#[cfg(all(test,unix))]
#[test]
fn maintenance_263_binding_diagnostic() {
 let root=tempfile::tempdir_in(std::env::temp_dir().canonicalize().unwrap()).unwrap();
 let auth=Auth::open(&root.path().join("credentials")).unwrap();
 let pin=auth.copilot_account().unwrap();
 let token=auth.credentials_dir().join("github-token");std::fs::write(&token,"SYNTHETIC_CHANGED").unwrap();
 std::fs::set_permissions(token,std::fs::Permissions::from_mode(0o600)).unwrap();
 let error=auth.check_copilot_account(&pin).unwrap_err();
 assert_eq!(error.kind,AiErrorKind::ReconnectNeeded);
 assert_eq!(error.detail.as_ref().unwrap().code.as_deref(),Some("sign_in_changed"));
 assert!(error.to_string().contains("account changed"));
}
''')
  else:
   p=ai+('threads.rs' if arm=='before' else 'provider.rs');modified.append(p)
   repl(p,'&& !cancel.is_cancelled()\n}', '&& !cancel.is_cancelled()\n        && !matches!(&answer.terminal, AiTerminal::Failed(e) if e.retry_after_seconds.is_some())\n}')
   append(p,'''#[cfg(test)]
#[test]
fn maintenance_263_retry_hint() {
 let cancel=CancellationToken::new();
 let mut error=AiError::new(AiErrorKind::ModelRefused);
 let mut answer=AiAnswer{text:String::new(),terminal:AiTerminal::Failed(error.clone())};
 assert!(copilot_responses_retry(false,&answer,&cancel));
 error.retry_after_seconds=Some(5);answer.terminal=AiTerminal::Failed(error);
 assert!(!copilot_responses_retry(false,&answer,&cancel));
 answer.terminal=AiTerminal::Failed(AiError::new(AiErrorKind::ModelRefused));answer.text="partial".into();
 assert!(!copilot_responses_retry(false,&answer,&cancel));answer.text.clear();
 assert!(!copilot_responses_retry(true,&answer,&cancel));cancel.cancel();assert!(!copilot_responses_retry(false,&answer,&cancel));
}
''')
  patch=subprocess.check_output(['git','diff','--','crates/brn-ai/src','crates/brn-threads-app/src'],cwd=root)
  # For the after arm, preserve the experimental diff relative to the frozen
  # candidate bytes rather than include its uncommitted extraction.
  import difflib
  patch=''.join(''.join(difflib.unified_diff(base[p].decode().splitlines(True),read(p).splitlines(True),fromfile=p,tofile=p)) for p in base if (root/p).read_bytes()!=base[p]).encode()
  (out/(task+'.patch')).write_bytes(patch)
  checks=[run(task,['cargo','test','--workspace','--lib','maintenance_263','--locked','--offline'])]
  if task=='binding-diagnostic':checks.append(run(task+'-existing',['cargo','test','--workspace','--lib','account','--locked','--offline']))
  if task=='retry-hint':checks.append(run(task+'-existing',['cargo','test','--workspace','--lib','copilot','--locked','--offline']))
  receipts.append({'task':task,'accepted':True,'production_files':modified,'attempts':1,'rework':0,'checks':checks,'patch_sha256':sha(out/(task+'.patch'))})
 finally:
  restore()
  assert all((root/p).read_bytes()==data for p,data in base.items()),'source not restored'
 (out/'results.json').write_text(json.dumps({'arm':arm,'receipts':receipts,'elapsed_measurement':'not collected/compared; wall limit only','source_restored':True},indent=2)+'\n')
print(json.dumps({'arm':arm,'tasks':len(receipts),'all_accepted':all(x['accepted']for x in receipts),'source_restored':True}))
