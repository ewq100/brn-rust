from pathlib import Path
import subprocess,sys,json,hashlib,difflib,re,time
arm=sys.argv[1];root=Path(sys.argv[2]);out=Path('/workspace/brn-provider-263/confirmation')/arm;out.mkdir(exist_ok=True)
ai='crates/brn-ai/src/';app='crates/brn-threads-app/src/'
paths=[str(p.relative_to(root)) for d in (ai,app) for p in (root/d).glob('*.rs')];base={p:(root/p).read_bytes() for p in paths};production=[]
def read(p):return (root/p).read_text()
def write(p,s):(root/p).write_text(s)
def repl(p,a,b):
 s=read(p);assert a in s,(p,a);write(p,s.replace(a,b))
def prod(p,a,b):repl(p,a,b);production.append(p)
started=time.monotonic()
try:
 prod(ai+'auth.rs','    pub fn open(credentials_dir: &Path) -> AiResult<Self> {','''    // Temporary independent maintenance task; never retained in product.
    pub fn open_passive(credentials_dir: &Path) -> AiResult<Self> {
        if !credentials_dir.is_absolute() || credentials_dir.components().any(|c| matches!(c, std::path::Component::ParentDir | std::path::Component::CurDir)) {
            return Err(unsafe_credentials());
        }
        match std::fs::symlink_metadata(credentials_dir) {
            Err(e) if e.kind()==std::io::ErrorKind::NotFound => {
                let mut ancestor=credentials_dir;
                while matches!(std::fs::symlink_metadata(ancestor),Err(ref e) if e.kind()==std::io::ErrorKind::NotFound) {
                    ancestor=ancestor.parent().ok_or_else(unsafe_credentials)?;
                }
                validate_ancestors(ancestor)?;
                return Err(AiError::new(AiErrorKind::ReconnectNeeded));
            }
            _ => {}
        }
        Self::open(credentials_dir)
    }
    pub fn open(credentials_dir: &Path) -> AiResult<Self> {''')
 if arm=='before':
  prod(ai+'threads.rs','Auth::open(credentials_dir?).ok()?.copilot_account().ok()','Auth::open_passive(credentials_dir?).ok()?.copilot_account().ok()')
  prod(ai+'threads.rs','let auth = Auth::open(dir)?.with_http(http);','let auth = if selection.provider == Provider::Copilot { Auth::open_passive(dir)? } else { Auth::open(dir)? }.with_http(http);')
  prod(ai+'conversion.rs','.and_then(|dir| Auth::open(dir).ok()?.copilot_account().ok())','.and_then(|dir| Auth::open_passive(dir).ok()?.copilot_account().ok())')
  prod(ai+'conversion.rs','let auth = with_transport(Auth::open(dir)?);','let auth = with_transport(Auth::open_passive(dir)?);')
  prod(ai+'copilot_search.rs','Auth::open(&request.credentials_dir)','Auth::open_passive(&request.credentials_dir)')
  prod(app+'subscription_search.rs','Auth::open(&credentials_dir)','Auth::open_passive(&credentials_dir)')
 else:
  prod(ai+'provider.rs','Auth::open(credentials_dir?).ok()?.copilot_account().ok()','Auth::open_passive(credentials_dir?).ok()?.copilot_account().ok()')
  prod(ai+'provider.rs','let auth = Auth::open(dir)?.with_http(http);','let auth = if selection.provider == Provider::Copilot { Auth::open_passive(dir)? } else { Auth::open(dir)? }.with_http(http);')
 p=ai+'threads_copilot_denial_tests.rs';write(p,read(p)+'''
#[tokio::test]
async fn confirmation_263_parent_absent_and_later_signin() {
    for later in [false,true] {
        let (_root,mut request,_) = tests::fixture();
        let creds=tempfile::tempdir_in(std::env::temp_dir().canonicalize().unwrap()).unwrap();
        let missing=creds.path().join("missing-parent").join("credentials");
        let codex=cache_tests::codex_file(&creds);
        request.selection.provider=Provider::Copilot;
        request.auth_file=Some(codex.clone());request.credentials_dir=Some(missing.clone());
        cache_tests::configure(&request,"Copilot");
        let data=request.data_dir.clone();
        let unchanged=|data:&PathBuf| {Store::open(data).unwrap().records().unwrap().into_iter().filter(|r|matches!(r.data,RecordData::Note(_)|RecordData::Action(_))).collect::<Vec<_>>()};
        let old=unchanged(&data);
        let prepared=prepare_run(request).unwrap();
        assert!(!missing.exists());assert!(!missing.parent().unwrap().exists());
        let old_codex=std::fs::read(&codex).unwrap();
        if later {std::fs::create_dir(missing.parent().unwrap()).unwrap();crate::Auth::open(&missing).unwrap();std::fs::write(missing.join("github-token"),"synthetic-new-signin").unwrap();use std::os::unix::fs::PermissionsExt;std::fs::set_permissions(missing.join("github-token"),std::fs::Permissions::from_mode(0o600)).unwrap();}
        let http=SequencedHttpClient::new([]);
        let result=run_prepared_over(prepared,CancellationToken::new(),Arc::new(|_|{}),Some(DynHttpClient::new(http.clone()))).await.unwrap();
        assert_eq!(failure(&result).0,AiErrorKind::ReconnectNeeded);
        assert!(http.requests().is_empty());assert_eq!(old,unchanged(&data));assert_eq!(old_codex,std::fs::read(&codex).unwrap());
        if later {assert_eq!(std::fs::read_to_string(missing.join("github-token")).unwrap(),"synthetic-new-signin");} else {assert!(!missing.exists());assert!(!missing.parent().unwrap().exists());}
    }
}
#[tokio::test]
async fn confirmation_263_existing_parent_still_uses_selected_account() {
    let (root,mut request,_) = tests::fixture();
    request.selection.provider=Provider::Copilot;
    request.auth_file=Some(cache_tests::codex_file(&root));request.credentials_dir=Some(credentials(&root));
    let model=request.selection.model.clone();let effort=request.effort;
    cache_tests::configure(&request,"Copilot");
    let http=SequencedHttpClient::new([session(),MockHttpResponse::success_typed(cache_tests::sse(&[json!({"id":"chat","object":"chat.completion.chunk","created":1,"model":model,"choices":[{"index":0,"delta":{"content":"Done"},"finish_reason":"stop"}],"usage":{"prompt_tokens":10,"completion_tokens":1,"total_tokens":11}})]),"text/event-stream")]);
    let result=run_prepared_over(prepare_run(request).unwrap(),CancellationToken::new(),Arc::new(|_|{}),Some(DynHttpClient::new(http.clone()))).await.unwrap();
    assert!(!matches!(result.answer.terminal,AiTerminal::Failed(_)),"{:?}",result.answer.terminal);
    let sent=http.requests();assert_eq!(sent.len(),2);assert!(sent[1].uri.starts_with("https://copilot.example.invalid/"));
    let body:Value=serde_json::from_slice(&sent[1].body).unwrap();assert_eq!(body["model"],model);assert_eq!(body["reasoning_effort"],effort.as_str());
}
''')
 p=ai+'threads_research_tests.rs';write(p,read(p)+'''
#[tokio::test]
async fn confirmation_263_independent_helper_is_visibly_unavailable() {
    let (_root,request,_) = setup();
    let creds=tempfile::tempdir_in(std::env::temp_dir().canonicalize().unwrap()).unwrap();
    let missing=creds.path().join("missing-parent").join("credentials");
    let mut helper=luna();helper.provider="copilot".into();helper.credentials_dir=Some(missing.display().to_string());helper.auth_file=Some(cache_tests::codex_file(&creds).display().to_string());set_helper(&request,Some(helper));
    let (scope,input)=begin(&request).unwrap();assert!(!missing.exists());
    let http=rig::test_utils::SequencedHttpClient::new([]);
    scope.helper.as_ref().unwrap().set_source(HelperSource::Provider(Some(DynHttpClient::new(http.clone()))));
    let call=json!({"questions":[question("a")]});
    let (answer,events,model)=parent(scope.clone(),&input,vec![vec![MockStreamEvent::tool_call("helper","research",call),tokens(1)],answer_turn()],CancellationToken::new()).await;
    assert!(!matches!(answer.terminal,AiTerminal::Failed(_)),"{:?}",answer.terminal);
    assert_eq!(model.requests().len(),2);assert!(http.requests().is_empty());assert!(!missing.exists());assert!(!missing.parent().unwrap().exists());
    assert_eq!(scope.helper.as_ref().unwrap().requested(),["gpt-6-luna"]);
    let history=format!("{:?}",model.requests().last().unwrap().chat_history);assert!(history.contains("unavailable"));assert!(history.contains("no other model is used"));
    assert!(events.iter().any(|e|matches!(e,AiEvent::Activity(a) if a.contains("unavailable"))));
    assert_eq!(request.selection.provider,Provider::Chatgpt);assert_eq!(request.effort,ReasoningEffort::Medium);
}
''')
 p=ai+'document_refine_tests.rs'
 # Existing helper/job fixtures run on cloud Unix for this temporary Text conversion only.
 repl(p,'#[cfg(target_os = "macos")]\nfn helpers()','#[cfg(unix)]\nfn helpers()');repl(p,'#[cfg(target_os = "macos")]\nfn job(','#[cfg(unix)]\nfn job(')
 write(p,read(p)+'''
#[tokio::test]
#[cfg(unix)]
async fn confirmation_263_refinement_missing_late_and_off() {
    let root=root();let codex=auth(&root);let missing=root.path().join("missing-parent").join("credentials");
    let account=ConversionAccount::capture(Some(Provider::Copilot),Some(&codex),Some(&missing));
    assert!(!missing.exists());assert!(!missing.parent().unwrap().exists());
    for late in [false,true] {
        if late {std::fs::create_dir(missing.parent().unwrap()).unwrap();crate::Auth::open(&missing).unwrap();std::fs::write(missing.join("github-token"),"synthetic-late-signin").unwrap();std::fs::set_permissions(missing.join("github-token"),std::fs::Permissions::from_mode(0o600)).unwrap();}
        let http=SequencedHttpClient::new([]);let outcome=refine(result(),&account,CancellationToken::new(),Some(DynHttpClient::new(http.clone())),TIMEOUT).await;
        assert!(matches!(outcome,Err(ConversionFailure::Provider(e)) if e.kind==crate::AiErrorKind::ReconnectNeeded));assert!(http.requests().is_empty());
        if late {assert_eq!(std::fs::read_to_string(missing.join("github-token")).unwrap(),"synthetic-late-signin");} else {assert!(!missing.exists());}
    }
    let never=root.path().join("off-missing-parent").join("credentials");
    let mut input=job(&root,DocumentConverter::Xberg,false,DocumentKind::Text,b"Exact text".to_vec());input.provider=Some(Provider::Copilot);input.auth_file=Some(codex);input.credentials_dir=Some(never.clone());
    let http=SequencedHttpClient::new([]);let converted=convert_job(input,CancellationToken::new(),Arc::new(AtomicBool::new(false)),Arc::new(|_|{}),Some(DynHttpClient::new(http.clone())),TIMEOUT).await.unwrap();
    assert_eq!(converted.markdown,"Exact text\\n");assert!(!never.exists());assert!(!never.parent().unwrap().exists());assert!(http.requests().is_empty());
}
''')
 p=app+'subscription_search.rs';write(p,read(p)+'''
#[test]
fn confirmation_263_search_start_is_passive() {
    let root=tempfile::tempdir_in(std::env::temp_dir().canonicalize().unwrap()).unwrap();
    let missing=root.path().join("missing-parent").join("credentials");
    let workspace=Workspace::open_without_default_credentials(root.path().join("workspace")).unwrap();let mut s=workspace.settings().unwrap();s.provider="Copilot".into();s.model="gpt-6-luna".into();s.effort="high".into();s.auth_file=None;s.credentials_dir=Some(missing.display().to_string());
    assert_eq!(prepare(&s,"q".into()).unwrap_err(),SearchError::CopilotNoLogin.to_string());assert!(!missing.exists());assert!(!missing.parent().unwrap().exists());
}
''')
 # Name() is the existing effort serializer; avoid any policy implementation duplication in test.
 patch=''.join(''.join(difflib.unified_diff(base[p].decode().splitlines(True),read(p).splitlines(True),fromfile=p,tofile=p)) for p in base if (root/p).read_bytes()!=base[p]);(out/'change.patch').write_text(patch)
 commands=[['cargo','test','--workspace','--lib','confirmation_263','--locked','--offline'],['cargo','test','-p','brn-ai','--lib','copilot_refines_with_its_own_account_and_never_falls_back_to_codex','--locked','--offline'],['cargo','test','-p','brn-ai','--lib','codex_runs_pin_one_session_and_an_append_only_prefix_on_either_credential_route','--locked','--offline'],['cargo','test','-p','brn-ai','--lib','auth::tests','--locked','--offline']]
 results=[]
 for i,cmd in enumerate(commands):
  with (out/f'test-{i}.log').open('wb') as f:r=subprocess.run(['python3','/workspace/brn-environment/run-with-reaping.py']+cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=max(1,900-int(time.monotonic()-started)))
  log=(out/f'test-{i}.log').read_text();cases=re.findall(r'^test .* \.\.\. ok$',log,re.M)
  results.append({'command':cmd,'status':r.returncode,'passed_cases':cases})
  if r.returncode!=0:break
 receipt={'arm':arm,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'production_files':sorted(set(production)),'production_sites':len(production),'results':results,'accepted':len(results)==len(commands) and all(r['status']==0 and len(r['passed_cases'])>0 for r in results) and len(results[0]['passed_cases'])==5,'source_restored':False,'scope':'one fresh read-only evaluator challenge; temporary maintenance behavior only, not retained; same lead/configuration/tools, no elapsed-speed claim','budget':'max2attempts/15min per arm'}
 (out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
finally:
 for p,data in base.items():(root/p).write_bytes(data)
 assert all((root/p).read_bytes()==data for p,data in base.items())
 if (out/'result.json').exists():
  r=json.loads((out/'result.json').read_text());r['source_restored']=True;receipt['source_restored']=True;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(receipt));assert receipt['accepted']
