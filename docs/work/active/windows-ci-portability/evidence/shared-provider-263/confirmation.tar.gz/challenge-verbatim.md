Frozen challenge: make passive Copilot operation startup leave missing credential storage absent.

A configured Copilot credential directory may not exist because the owner has never signed in. Preparing or attempting ordinary work must report that sign-in is needed without creating that directory or its missing parents. Account capture must remain observational. Explicit sign-in and successful authentication of an existing signed-in account retain their current storage behavior.

Acceptance checks, using fresh synthetic directories and recording transport requests:

1. **Parent chat:** configure Copilot with a nonexistent absolute credential path beneath an existing temporary directory. Prepare the run, then attempt it through the synthetic transport. Check directory absence after preparation and after completion. The result must indicate `ReconnectNeeded`; there must be zero authentication or model HTTP requests and no generated Note changes or candidates. Normal Run bookkeeping is permitted.

2. **Independent helper:** run a synthetic successful parent with a separately configured Copilot helper whose credential directory is absent. Preparation and a research attempt must leave that directory absent. The parent must receive the existing visible helper-unavailable outcome, with zero helper HTTP requests and no substitution of the parent’s provider, account, model, or effort.

3. **Refinement:** enable document refinement on Copilot with an absent credential directory and otherwise valid synthetic converted content. Capture/start and attempted refinement must leave the directory absent. The outcome must be a provider reconnect failure, with zero HTTP requests and no refined candidate. Repeat with refinement Off: ordinary conversion succeeds, the directory remains absent, and no provider request occurs.

4. **Late sign-in remains fenced:** prepare an operation while its credential directory is absent, then independently install synthetic signed-in credentials there before execution. Execution must refuse to adopt that later account, send zero HTTP requests, and preserve the newly installed credential bytes.

5. **Existing signed-in account still works:** supply safe existing synthetic Copilot credentials and successful synthetic authentication/model responses. Parent chat and refinement must succeed on their explicitly selected routes. Assert the requested model and reasoning effort; refinement remains Luna/high, tool-free, and without conversation history. Authentication cache writes remain permitted. No fallback account or provider is used.

6. **Provider isolation:** repeat the absent-Copilot cases with a valid synthetic ChatGPT auth file also supplied. They must still fail as above without reading or using that file. Selecting ChatGPT separately must retain its existing successful synthetic behavior.

Scope is limited to missing credential storage during passive Copilot startup and refusal. Preserve existing-directory validation, account-change fences, explicit sign-in, authenticated cache writes, cancellation, response limits, retry/schema rules, checked writes, and Undo. No new providers, defaults, routing optimizations, or executor abstractions.

Feasible offline on both `ce36eb947a5e24c36046cb72e07fb5b9ce444164` and `b924029a8fb7712f8383bf7a8b7f5d68f2922591`, using existing preparation, handler, and synthetic-transport facilities. This specification was not implemented or executed. Inspection used **8 read-only tool calls**; no files were changed.
