#!/usr/bin/env bash
# Invoke from a fresh shell that sourced activate.sh exactly once.
set -euo pipefail
cd /workspace/brn-cycle2
export TMPDIR=/var/tmp/brn-cycle2-fixtures CARGO_TERM_COLOR=never
evidence=/workspace/brn-cycle2-evidence
python3 - <<'PY'
import os,json,hashlib,pathlib
keys=('C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','LIBRARY_PATH','PKG_CONFIG_PATH','PKG_CONFIG_SYSROOT_DIR','LIBCLANG_PATH','LD_LIBRARY_PATH','PATH','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS')
data={k:os.environ.get(k,'') for k in keys}
p=pathlib.Path('/workspace/brn-cycle2-evidence')
(p/'fixed-native-environment.sha256').write_text(hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()+'\n')
(p/'fixed-native-environment.json').write_text(json.dumps(data,indent=2)+'\n')
PY
for arm in A B2; do
 export CARGO_TARGET_DIR="/workspace/brn-cycle2-$arm"
 export BRN_XBERG_HELPER="$CARGO_TARGET_DIR/document-helpers/artifacts/brn-xberg-helper"
 export BRN_XBERG_HELPER_BRN="$CARGO_TARGET_DIR/document-helpers/artifacts/brn-xberg-helper-brn"
 for kind in full libs bins; do
  flags=(); if [[ "$kind" == libs ]]; then flags=(--lib); elif [[ "$kind" == bins ]]; then flags=(--bins); fi
  cargo test --workspace "${flags[@]}" --no-run --locked --offline --message-format=json > "$evidence/fixed-$arm-$kind.jsonl" 2> "$evidence/fixed-$arm-$kind.stderr"
 done
 bash scripts/build-document-helpers.sh --offline --jobs 1 --target-root "$CARGO_TARGET_DIR/document-helpers" > "$evidence/fixed-$arm-helpers-warm.log" 2>&1
 bash scripts/build-document-helpers.sh --offline --jobs 1 --target-root "$CARGO_TARGET_DIR/document-helpers" > "$evidence/fixed-$arm-helpers.log" 2>&1
 if rg -q 'Compiling ' "$evidence/fixed-$arm-helpers.log"; then echo 'Helper not fresh: stop before comparisons'; exit 126; fi
done
python3 - <<'PY'
import json,pathlib
p=pathlib.Path('/workspace/brn-cycle2-evidence')
for arm in ['A','B2']:
 data={}
 for kind in ['full','libs','bins']:
  rows=[json.loads(l) for l in (p/f'fixed-{arm}-{kind}.jsonl').read_text().splitlines() if l.startswith('{')]
  artifacts=[r for r in rows if r.get('reason')=='compiler-artifact']
  assert artifacts and all(r['fresh'] for r in artifacts), (arm,kind,'nonfresh original artifact')
  units={}
  for r in artifacts:
   key=(r['package_id'],r['target']['name'],tuple(r['target']['kind']),json.dumps(r['profile'],sort_keys=True))
   units.setdefault(key,set()).add(tuple(r['features']))
  data[kind]=units
 for kind in ['libs','bins']:
  for k,features in data[kind].items():
   assert k in data['full'] and features==data['full'][k], (arm,kind,k,'feature mismatch')
 print(arm,'fresh full/lib/bin artifacts; all common unit features match')
PY
deadline=$(( $(date -d "$(cat "$evidence/trial-start.txt")" +%s) + 5400 ))
restore_sources() { for p in core ai ui; do python3 "$evidence/probe.py" "$p" restore; done; }
trap restore_sources EXIT
for probe in core ai ui; do
 case "$probe" in
  core) prefix=locator::tests::; kind=--lib; reserve=600 ;;
  ai) prefix=codex_auth::portable_tests::; kind=--lib; reserve=600 ;;
  ui) prefix=threads_state::tests::; kind=--bins; reserve=120 ;;
 esac
 index=0
 for arm in A B B A; do
  index=$((index+1))
  if (( $(date +%s) + reserve > deadline )); then echo 'Budget stop before next workflow'; exit 124; fi
  target=/workspace/brn-cycle2-A; if [[ "$arm" == B ]]; then target=/workspace/brn-cycle2-B2; fi
  label="fixed-$probe-$arm-$index"
  command="python3 $evidence/probe.py $probe set || exit \$?; "
  if [[ "$arm" == B ]]; then
   command+="focused_status=0; cargo test --workspace $kind $prefix --locked --offline || focused_status=\$?; gate_status=0; bash -x scripts/verify-storage.sh && bash -x scripts/verify-end-to-end.sh --fixtures-only || gate_status=\$?; if [ \"\$focused_status\" -ne 0 ]; then exit \"\$focused_status\"; fi; exit \"\$gate_status\""
  else
   command+='bash -x scripts/verify-storage.sh && bash -x scripts/verify-end-to-end.sh --fixtures-only'
  fi
  python3 "$evidence/observe.py" "$label" "$target" "$prefix" python3 /workspace/brn-environment/run-with-reaping.py bash -c "$command"
  python3 "$evidence/probe.py" "$probe" restore
  export CARGO_TARGET_DIR="$target" BRN_XBERG_HELPER="$target/document-helpers/artifacts/brn-xberg-helper" BRN_XBERG_HELPER_BRN="$target/document-helpers/artifacts/brn-xberg-helper-brn"
  {
   date -u +%FT%TZ
   cargo build --workspace --locked --offline
   cargo clippy --workspace --all-targets --locked --offline -- -D warnings
   cargo test --workspace --no-run --locked --offline
   cargo test -p brn --features scripted-document-tests --bin brn --no-run --locked --offline --jobs 1
   cargo test --workspace "$kind" --no-run --locked --offline --message-format=json > "$evidence/$label-restored-artifacts.jsonl"
   date -u +%FT%TZ
  } > "$evidence/$label-restore.log" 2>&1
  python3 - "$evidence/$label-restored-artifacts.jsonl" <<'PY'
import json,sys
rows=[json.loads(l) for l in open(sys.argv[1]) if l.startswith('{')]
artifacts=[r for r in rows if r.get('reason')=='compiler-artifact']
assert artifacts and all(r['fresh'] for r in artifacts), 'restoration not fresh'
PY
  df -Pk /workspace | tail -1 >> "$evidence/disk-observations.txt"
  if (( $(df -Pk /workspace | awk 'NR==2 {print $4}') < 2097152 )); then echo 'Disk budget stop'; exit 125; fi
 done
done
