#!/usr/bin/env bash
set -euo pipefail
cd /workspace/brn-cycle2
source /workspace/brn-environment/activate.sh
export TMPDIR=/var/tmp/brn-cycle2-fixtures
date -u +%FT%TZ > /workspace/brn-cycle2-evidence/trial-start.txt
python3 /workspace/brn-cycle2-evidence/observe.py noop-A /workspace/brn-cycle2-A locator::tests:: python3 /workspace/brn-environment/run-with-reaping.py bash -c 'bash -x scripts/verify-storage.sh && bash -x scripts/verify-end-to-end.sh --fixtures-only'
python3 /workspace/brn-cycle2-evidence/observe.py noop-B /workspace/brn-cycle2-B locator::tests:: python3 /workspace/brn-environment/run-with-reaping.py bash -c 'focused_status=0; cargo test -p brn-threads-core --lib locator::tests:: --locked --offline || focused_status=$?; gate_status=0; bash -x scripts/verify-storage.sh && bash -x scripts/verify-end-to-end.sh --fixtures-only || gate_status=$?; if [ "$focused_status" -ne 0 ]; then exit "$focused_status"; fi; exit "$gate_status"'
