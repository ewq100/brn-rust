"""Disposable observation of existing commands; not a shipped gate."""
import hashlib, json, os, re, resource, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path

label, target, prefix = sys.argv[1:4]
command = sys.argv[4:]
root = Path(__file__).parent
env = dict(os.environ, CARGO_TARGET_DIR=target, CARGO_TERM_COLOR='never',
    BRN_XBERG_HELPER=target+'/document-helpers/artifacts/brn-xberg-helper',
    BRN_XBERG_HELPER_BRN=target+'/document-helpers/artifacts/brn-xberg-helper-brn')
record = dict(label=label, target=target, relevant_prefix=prefix, command=command,
              start=datetime.now(timezone.utc).isoformat(), events=[])
record['source_diff'] = subprocess.check_output(['git', 'diff', '--', 'crates/']).decode()
record['commit'] = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
record['environment'] = {k:env.get(k) for k in ('CARGO_INCREMENTAL','CARGO_BUILD_JOBS','TMPDIR','BRN_XBERG_HELPER','BRN_XBERG_HELPER_BRN')}
record['helper_sha256'] = {k: hashlib.sha256(Path(env[k]).read_bytes()).hexdigest()
    for k in ('BRN_XBERG_HELPER','BRN_XBERG_HELPER_BRN') if Path(env[k]).exists()}
record['cpu_stat_before'] = Path('/sys/fs/cgroup/cpu.stat').read_text()
start = time.monotonic()
with (root / (label + '.log')).open('w') as log:
    child = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    try:
        for line in child.stdout:
            elapsed = time.monotonic() - start
            log.write(line); log.flush()
            if re.search(r'^test ' + re.escape(prefix) + r'.* \.\.\. (ok|FAILED)', line) and 'first_relevant_s' not in record:
                record['first_relevant_s'] = elapsed
                record['first_relevant_line'] = line.strip()
            if re.search(r'Compiling brn|Finished |Running |test result:|^\+ (cargo|bash|python3)|verification passed', line):
                record['events'].append([elapsed, line.strip()])
    except BaseException:
        child.terminate(); child.wait()
        raise
    record['exit_code'] = child.wait()
record['elapsed_s'] = time.monotonic() - start
record['source_diff_end'] = subprocess.check_output(['git', 'diff', '--', 'crates/']).decode()
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
record['resources'] = dict(user_s=usage.ru_utime, system_s=usage.ru_stime,
    maxrss_kib=usage.ru_maxrss, inblock=usage.ru_inblock, outblock=usage.ru_oublock)
record['cpu_stat_after'] = Path('/sys/fs/cgroup/cpu.stat').read_text()
record['end'] = datetime.now(timezone.utc).isoformat()
(root / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('events','source_diff','source_diff_end','cpu_stat_before','cpu_stat_after')}), flush=True)
sys.exit(record['exit_code'])
