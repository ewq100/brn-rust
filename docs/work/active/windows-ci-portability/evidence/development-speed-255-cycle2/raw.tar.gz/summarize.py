import json, pathlib, re
from datetime import datetime

root = pathlib.Path(__file__).parent
classes = {
 'baseline-A': ('setup', 'failed: container PID 1 retained a killed descendant as a zombie'),
 'baseline-A-reaped': ('setup', 'passed with subreaper; fixtures-only inherited older external helpers; not a comparison'),
 'baseline-B-relocated': ('setup', 'passed with current pinned helpers'),
 'noop-A': ('control', 'original full-gate no-op'),
 'noop-B': ('candidate-1', 'rejected package-only startup control: extra graph and excessive wall/CPU overhead'),
 'core-A-1': ('excluded', 'nested activation changed native setup and cache conditions'),
 'core-B-2': ('excluded', 'nested activation and helper freshness not established'),
 'fixed-core-A-1': ('unreplicated', 'single core observation, not ABBA/confirmation'),
 'fixed-core-B-2': ('unreplicated', 'first feedback earlier, full gate over threshold; helper rebuild cause unresolved'),
 'fixed-ui-A-1': ('excluded', 'cross-probe shared-source mtime left core/AI stale in inactive root'),
 'fixed-ui-B-2': ('unpaired', 'correctness passed; paired UI baseline has unmatched rebuild work'),
 'fixed-ai-A-1': ('unpaired', 'baseline correctness passed; no candidate/repeat before protocol stop'),
}
records = {name:json.loads((root/(name+'.json')).read_text()) for name in classes}
observations = []
for name,(role,reason) in classes.items():
 r=records[name]; log=(root/(name+'.log')).read_text()
 prefix=r['relevant_prefix']
 tests=re.findall(r'^test '+re.escape(prefix)+r'.* \.\.\. (ok|FAILED|ignored.*)$', log, re.M)
 observations.append({
  'id':name,'role':role,'qualification':reason,'start_utc':r['start'],'end_utc':r['end'],
  'first_relevant_s':r.get('first_relevant_s'),'full_workflow_s':r['elapsed_s'],
  'exit_code':r['exit_code'],'intended_test_results':len(tests),
  'cpu_s':r['resources']['user_s']+r['resources']['system_s'],
  'maximum_child_rss_kib':r['resources']['maxrss_kib'],
  'input_blocks_512b':r['resources']['inblock'],'output_blocks_512b':r['resources']['outblock'],
  'native_setup_sha256':r.get('native_setup_environment_sha256'),
  'helper_sha256':r.get('helper_sha256'),'postrun_test_artifacts':r.get('artifact_sha256_after'),
  'cli_journey_completed':'"journey":"passed","steps":108,"checks":1266' in log,
  'raw_record':name+'.json','raw_log':name+'.log',
 })

def stats(raw):
 return {k:int(v) for k,v in (line.split() for line in raw.splitlines())}
def window(first,last):
 a=records[first]; b=records[last]
 before=stats(a['cpu_stat_before']); after=stats(b['cpu_stat_after'])
 return {'start_utc':a['start'],'end_utc':b['end'],
  'wall_s':(datetime.fromisoformat(b['end'])-datetime.fromisoformat(a['start'])).total_seconds(),
  'cgroup_cpu_s':(after['usage_usec']-before['usage_usec'])/1e6,
  'cgroup_throttled_s':(after.get('throttled_usec',0)-before.get('throttled_usec',0))/1e6,
  'scope':'entire container counter delta, including setup/restorations/diagnostics between observations; not candidate-only CPU'}
def pair(a,b):
 a=records[a]; b=records[b]
 ca=sum(a['resources'][k] for k in ['user_s','system_s']); cb=sum(b['resources'][k] for k in ['user_s','system_s'])
 return {'first_relevant_a_s':a.get('first_relevant_s'),'first_relevant_b_s':b.get('first_relevant_s'),
  'full_a_s':a['elapsed_s'],'full_b_s':b['elapsed_s'],
  'full_wall_overhead_percent':100*(b['elapsed_s']/a['elapsed_s']-1),
  'cpu_a_s':ca,'cpu_b_s':cb,'cpu_overhead_percent':100*(cb/ca-1),
  'qualification':'single observations only; no repeatable speedup or universal slowdown established'}

summary={'schema':1,'source_commit':'6897fe56ce9457fa7d60d0354b0ba4627d5049bb',
 'outcome':'no workflow/configuration retained; justified protocol stop with incomplete acceptance evidence',
 'timed_comparison_count':9,'comparison_cap':16,'setup_complete_workflows':3,
 'failed_launches_without_gate':1,'preflight_stop_before_sample':1,
 'complete_observation_workflows':len(records),'failed_complete_observation_workflows':sum(r['exit_code']!=0 for r in records.values()),
 'sum_observed_workflow_wall_s':sum(r['elapsed_s'] for r in records.values()),
 'sum_observed_workflow_child_cpu_s':sum(r['resources']['user_s']+r['resources']['system_s'] for r in records.values()),
 'whole_experiment_observed_window':window('baseline-A','fixed-ai-A-1'),
 'trial_window':window('noop-A','fixed-ai-A-1'),
 'original_trial_deadline_utc':'2026-11-06T21:15:47Z',
 'package_only_control':pair('noop-A','noop-B'),
 'single_fixed_core_pair':pair('fixed-core-A-1','fixed-core-B-2'),
 'abba_complete':False,'fresh_confirmation_complete':False,
 'council':{'sessions_run':0,'diagnosis':'incomplete: installed skill/cloud routes unavailable','final_review':'incomplete','score':'no score'},
 'limits':['No UI speedup is inferred from unmatched UI rebuilds, despite identical emitted binaries.',
           'Helper rebuild cause is unresolved; no causal helper regression or pure-linker speed claim.',
           'Cargo summaries include setup with compilation/linking; suite execution/launch events are separate in raw records.',
           'No paired hosted-CI measurement, live provider, owner-Mac or native interaction result.'],
 'observations':observations}
for name in ['harmless-statuses','restored-source-sha256']:
 p=root/'correctness'/(name+'.json')
 if p.exists(): summary[name]=json.loads(p.read_text())
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['observations','limits']},indent=2))
