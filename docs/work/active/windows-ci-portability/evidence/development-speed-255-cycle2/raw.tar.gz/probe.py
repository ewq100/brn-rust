"""The three prescribed reversible edits; only measurement scratch use."""
import pathlib, subprocess, sys
probe, action = sys.argv[1:]
paths = dict(core='crates/brn-threads-core/src/locator.rs', ai='crates/brn-ai/src/codex_auth.rs', ui='crates/brn-desktop/src/threads_state.rs')
path = pathlib.Path(paths[probe])
original = subprocess.check_output(['git', 'show', 'HEAD:'+str(path)])
replacements = dict(core=(b'stored == canonical', b'canonical == stored'),
    ai=(b'selection.provider != Provider::Chatgpt', b'Provider::Chatgpt != selection.provider'),
    ui=(b'"Maintenance is paused. Your saved choice will apply when you resume."',
        b'concat!("Maintenance is paused. ", "Your saved choice will apply when you resume.")'))
if action == 'set':
    old, new = replacements[probe]
    assert old in original
    content = original.replace(old, new, 1)
    if probe == 'ui':
        content = subprocess.check_output(['rustfmt', '--edition', '2024', '--emit', 'stdout'], input=content)
elif action == 'restore':
    content = original
elif action == 'fail':
    assert probe == 'core'
    content = original + b'\n#[cfg(test)]\n#[test]\nfn cycle2_harmless_failure() {\n    assert_eq!(canonical_locator("synthetic://cycle2"), "synthetic://deliberate-mismatch");\n}\n'
    content = subprocess.check_output(['rustfmt', '--edition', '2024', '--emit', 'stdout'], input=content)
else:
    raise ValueError(action)
if path.read_bytes() != content:
    path.write_bytes(content)
