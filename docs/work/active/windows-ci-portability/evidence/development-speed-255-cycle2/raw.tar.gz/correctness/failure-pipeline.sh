#!/usr/bin/env bash
set -euo pipefail
cd /workspace/brn-cycle2
evidence=/workspace/brn-cycle2-evidence
python3 "$evidence/probe.py" core fail
focused_status=0
cargo test --workspace --lib locator::cycle2_harmless_failure --locked --offline -- --exact > "$evidence/correctness/harmless-focused.log" 2>&1 || focused_status=$?
gate_status=0
bash -x scripts/verify-storage.sh > "$evidence/correctness/harmless-full-gate.log" 2>&1 || gate_status=$?
python3 - "$focused_status" "$gate_status" <<'PY'
import json,sys,pathlib
p=pathlib.Path('/workspace/brn-cycle2-evidence/correctness')
(p/'harmless-statuses.json').write_text(json.dumps({'focused_exit':int(sys.argv[1]),'full_gate_exit':int(sys.argv[2]),'full_gate_invoked_after_focused_failure':True},indent=2)+'\n')
PY
if [[ "$focused_status" -ne 0 ]]; then exit "$focused_status"; fi
exit "$gate_status"
