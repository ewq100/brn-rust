#!/usr/bin/env bash
# Same fixed comparison; interleaved to cover all three paths within the cap.
# Caller activates the cloud environment once; this file never reactivates it.
set -euo pipefail
cd /workspace/brn-cycle2
export TMPDIR=/var/tmp/brn-cycle2-fixtures CARGO_TERM_COLOR=never
evidence=/workspace/brn-cycle2-evidence
deadline=$(( $(date -d "$(cat "$evidence/trial-start.txt")" +%s) + 5400 ))
restore_sources() { for p in core ai ui; do python3 "$evidence/probe.py" "$p" restore; done; }
restore_artifacts() {
 local label="$1" kind="$2" target="$3"
 export CARGO_TARGET_DIR="$target" BRN_XBERG_HELPER="$target/document-helpers/artifacts/brn-xberg-helper" BRN_XBERG_HELPER_BRN="$target/document-helpers/artifacts/brn-xberg-helper-brn"
 {
  date -u +%FT%TZ
  cargo build --workspace --locked --offline
  cargo clippy --workspace --all-targets --locked --offline -- -D warnings
  cargo test --workspace --no-run --locked --offline
  cargo test -p brn --features scripted-document-tests --bin brn --no-run --locked --offline --jobs 1
  cargo test --workspace "$kind" --no-run --locked --offline --message-format=json > "$evidence/$label-restored-artifacts.jsonl"
  date -u +%FT%TZ
 } > "$evidence/$label-restore.log" 2>&1
 python3 - "$evidence/$label-restored-artifacts.jsonl" <<'PY'
import json,sys
rows=[json.loads(l) for l in open(sys.argv[1]) if l.startswith('{')]
artifacts=[r for r in rows if r.get('reason')=='compiler-artifact']
assert artifacts and all(r['fresh'] for r in artifacts), 'restoration not fresh'
PY
}
trap restore_sources EXIT
# Complete the same original-source restoration after the gracefully paused run.
restore_sources
restore_artifacts fixed-core-B-2 --lib /workspace/brn-cycle2-B2
while read -r probe arm index; do
 case "$probe" in
  core) prefix=locator::tests::; kind=--lib; reserve=600 ;;
  ai) prefix=codex_auth::portable_tests::; kind=--lib; reserve=600 ;;
  ui) prefix=threads_state::tests::; kind=--bins; reserve=120 ;;
 esac
 if (( $(date +%s) + reserve > deadline )); then echo 'Budget stop before next workflow'; exit 124; fi
 target=/workspace/brn-cycle2-A; if [[ "$arm" == B ]]; then target=/workspace/brn-cycle2-B2; fi
 label="fixed-$probe-$arm-$index"
 command="python3 $evidence/probe.py $probe set || exit \$?; "
 if [[ "$arm" == B ]]; then
  command+="focused_status=0; cargo test --workspace $kind $prefix --locked --offline || focused_status=\$?; gate_status=0; bash -x scripts/verify-storage.sh && bash -x scripts/verify-end-to-end.sh --fixtures-only || gate_status=\$?; if [ \"\$focused_status\" -ne 0 ]; then exit \"\$focused_status\"; fi; exit \"\$gate_status\""
 else
  command+='bash -x scripts/verify-storage.sh && bash -x scripts/verify-end-to-end.sh --fixtures-only'
 fi
 python3 "$evidence/observe.py" "$label" "$target" "$prefix" python3 /workspace/brn-environment/run-with-reaping.py bash -c "$command"
 python3 "$evidence/probe.py" "$probe" restore
 restore_artifacts "$label" "$kind" "$target"
 df -Pk /workspace | tail -1 >> "$evidence/disk-observations.txt"
 if (( $(df -Pk /workspace | awk 'NR==2 {print $4}') < 2097152 )); then echo 'Disk budget stop'; exit 125; fi
done < "$evidence/remaining-schedule.txt"
