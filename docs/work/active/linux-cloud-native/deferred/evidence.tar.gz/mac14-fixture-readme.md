# MAC14 checked synthetic fixture

Source: `crates/brn-threads-app/examples/native_connections_fixture.rs`.

Build under the lead-owned Cargo slot:

```bash
source /workspace/brn-environment/activate.sh
cargo build -p brn-threads-app --example native_connections_fixture --locked --offline --jobs 1
"$CARGO_TARGET_DIR/debug/examples/native_connections_fixture" --output /absolute/new-root
```

The parent must exist, be canonical, and output must not exist. The generator fails rather than overwrites. It uses only checked owner services and never invokes models or discovers credentials. It writes `workspace/`, `manifest.json`, `initial-records.json`, `initial-history.json`.

Fixture:

- Project A — retained private source
- Project B — shared connections
- Private neighbor copper-orchid-731, created privately in A, linked into B
- General center for Connections, explicitly linked into B
- RELATED link from general center to private neighbor
- Unrelated sentinel

Initial verification reopens workspace, confirms private neighbor visible in A/B and not generally, confirms scoped Connections B contains neighbor, and exact original records unchanged. Manifest includes creation/link/relation receipts and expected UTF-8 text hashes. Generator does not unlink/undo or exercise the desktop.

Native route: Projects → B → general center → Connections → Open beside → Projects. Observe private neighbor. Activate B's actual Unlink for private neighbor; observe immediate retirement and settled success, same center/scope/visible panel. Read-only `connections --note CENTRE --project B`, `read --id PRIVATE` and `history` qualify durable outcome. Identify exact B unlink receipt and use actual Changes Undo. Confirm Connections neighbor returns and all three Note records remain byte/version identical to initial records. The membership changes and associated receipts are expected differences; do not compare full records arrays for equality.

Preparation source follows existing desktop regression `connections_result_is_cleared_when_project_unlink_revokes_neighbor_visibility`; it is not a substitute for native observation. No Mac acceptance is claimed.
