import os,sys,json,subprocess,time,pathlib
ROOT=pathlib.Path('/workspace/brn-environment/logs/deferred-linux')
BIN=pathlib.Path(os.environ['CARGO_TARGET_DIR'])/'debug'
os.environ['DISPLAY']=':98'
def cli(data,*args):
 p=subprocess.run([str(BIN/'brn'),'--json','--data-dir',str(data),*map(str,args)],capture_output=True,text=True)
 d=json.loads(p.stdout)
 if not d['ok']: raise RuntimeError((args,d))
 return d

def snap(data,name):
 d={k:cli(data,k) for k in ['records','recovery','history','candidates']}
 (ROOT/(name+'.json')).write_text(json.dumps(d,indent=2))
 return d

def xd(*args): subprocess.run(['xdotool',*map(str,args)],check=True)
def capture(name):
 time.sleep(1)
 subprocess.run(['import','-window','root',str(ROOT/(name+'.png'))],check=True)
def launch(data,name):
 log=open(ROOT/(name+'.log'),'w')
 p=subprocess.Popen([str(BIN/'brn-desktop'),'--data-dir',str(data)],stdout=log,stderr=log,start_new_session=True)
 (ROOT/'app-pid').write_text(str(p.pid))
 subprocess.run(['timeout','30s','xdotool','search','--sync','--onlyvisible','--name','^BRN$'],check=True,stdout=subprocess.DEVNULL)
 time.sleep(2)
 return p.pid

def seed(name,private=False):
 root=pathlib.Path('/var/tmp/brn-rust-cloud-fixtures')/('linux-'+name+'-'+str(time.time_ns()))
 root.mkdir(mode=0o700)
 data=root/'data'; cli(data,'init','--purpose','test')
 sentinel=cli(data,'note-create','--title','Unrelated sentinel','--text','Leave this sentinel unchanged.')
 if private:
  project=cli(data,'project-create','--title','Private synthetic Project')
  (ROOT/(name+'-project.json')).write_text(json.dumps(project,indent=2))
  # Record shape is validated by inspection below before private setup.
 else:
  note=cli(data,'note-create','--title',name,'--text','Initial saved text.')
  (ROOT/(name+'-note.json')).write_text(json.dumps(note,indent=2))
 (ROOT/(name+'-root')).write_text(str(root))
 snap(data,name+'-before')
 return root
if __name__=='__main__':
 cmd=sys.argv[1]
 if cmd=='seed': print(seed(sys.argv[2],len(sys.argv)>3))
 elif cmd=='launch': launch(sys.argv[2],sys.argv[3])
 elif cmd=='capture': capture(sys.argv[2])
 elif cmd=='snap': snap(sys.argv[2],sys.argv[3])
def ax(command='dump',**kwargs):
 args=['/usr/bin/python3','/workspace/brn-environment/a11y/query.py',command]
 for k,v in kwargs.items(): args += ['--'+k,str(v)]
 p=subprocess.run(args,capture_output=True,text=True)
 if p.returncode: raise RuntimeError(p.stderr+p.stdout)
 d=json.loads(p.stdout)
 if command!='dump':
  with (ROOT/'ax-actions.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
 time.sleep(.5)
 return d

def saveax(name):
 d=ax();(ROOT/(name+'-ax.json')).write_text(json.dumps(d,indent=2));return d

def paste(text):
 subprocess.run(['xclip','-selection','clipboard','-in'],input=text,text=True,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
 xd('key','ctrl+v')
def open_note(name):
 ax('action',name='Notes',role='button')
 rows=ax(); match=[r for r in rows if r.get('name')==name and r.get('role')=='button']
 assert match,name
 ax('action',path=match[0]['path'])

def wait_draft(data,expected):
 for i in range(60):
  rows=cli(data,'recovery')['result']
  if rows and rows[0]['markdown']==expected:return rows[0]
  time.sleep(.5)
 raise AssertionError(rows)

def notes(snapshot):
 return [r for r in snapshot['records']['result'] if 'Note' in r.get('data',{})]

def wait_exit(pid):
 for i in range(60):
  p=pathlib.Path('/proc')/str(pid)/'stat'
  if not p.exists() or p.read_text().split()[2]=='Z':return
  time.sleep(.25)
 raise AssertionError('process did not exit')
