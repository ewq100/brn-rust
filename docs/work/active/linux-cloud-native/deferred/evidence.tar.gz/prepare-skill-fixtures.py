import json, os, pathlib, subprocess, tempfile
OUT=pathlib.Path('/workspace/brn-environment/logs/deferred-linux')
BIN=pathlib.Path(os.environ['CARGO_TARGET_DIR'])/'debug/brn'
def setup(mode):
 root=pathlib.Path(tempfile.mkdtemp(prefix='brn-native-skills-'+mode+'-',dir='/tmp'))
 data=root/'data'; calls=[]
 def cli(*args):
  argv=[str(BIN),'--json','--data-dir',str(data),*map(str,args)]
  p=subprocess.run(argv,text=True,capture_output=True)
  try: result=json.loads(p.stdout)
  except Exception: raise RuntimeError((args,p.returncode,p.stdout,p.stderr))
  calls.append({'argv':argv,'returncode':p.returncode,'response':result})
  (OUT/f'skills-{mode}-commands.json').write_text(json.dumps(calls,indent=2)+'\n')
  if not result.get('ok'): raise RuntimeError((args,result))
  return result
 cli('init','--purpose','test')
 project=cli('project-create','--title',f'{mode.title()} skill controls')
 project_id=next(c['id'] for c in project['changed'] if c['kind']=='Project')
 def package(name,body):
  path=root/name; path.mkdir(exist_ok=True)
  (path/'SKILL.md').write_text(f'---\nname: {name}\ndescription: Synthetic native skill controls.\n---\n{body}\n')
  return path
 inventory=cli('skill-install','--source',package('native-inventory','Inspect this instruction-only synthetic package.'))['result']
 stale_path=package('native-stale','Synthetic v1 instruction bytes.')
 v1=cli('skill-install','--source',stale_path)['result']
 cli('skill-enable','--id',v1['id'],'--digest',v1['digest'],'--project',project_id)
 cli('skill-remove','--name','native-stale','--digest',v1['digest'])
 package('native-stale','Synthetic v2 instruction bytes, explicitly different from v1.')
 v2=cli('skill-install','--source',stale_path)['result']
 assert v1['digest'] != v2['digest']
 if mode=='inactive':
  preview=cli('project-delete-preview','--project',project_id)['result']
  preview_path=root/'delete-preview.json'; preview_path.write_text(json.dumps(preview))
  cli('project-delete','--preview-file',preview_path,'--actions','{}')
 records=cli('records'); settings=cli('settings'); skills=cli('skills','--project',project_id)
 binding=next(b for b in settings['result']['skills'] if b['id']==v1['id'] and b['project']==project_id)
 assert binding['digest']==v1['digest'] and not binding['enabled'] and not binding['selected']
 p=next(r for r in records['result'] if r['id']==project_id)
 assert p['archived']==(mode=='inactive')
 manifest={'mode':mode,'root':str(root),'data':str(data),'project_id':project_id,'inventory':inventory,'stale_old':v1,'stale_current':v2,'expected_binding_before':binding,'records_before':records,'settings_before':settings,'skills_before':skills,'setup':'public CLI only; removal revokes enabled/selected but retains old digest binding; no provider command','ui_route':'Projects > '+('Trash > ' if mode=='inactive' else '')+mode.title()+' skill controls; select project, no unrelated chat selected; Settings > Skills'}
 (OUT/f'skills-{mode}-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps({'mode':mode,'data':str(data),'project':project_id,'manifest':str(OUT/f'skills-{mode}-manifest.json')}))
for mode in ('inactive','active'): setup(mode)
