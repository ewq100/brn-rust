#!/usr/bin/env bash
set -euo pipefail
source /workspace/brn-batch-evidence/environment.sh
export CARGO_BUILD_JOBS=3
export BRN_XBERG_HELPER=/workspace/brn-daily-helpers/artifacts/brn-xberg-helper
export BRN_XBERG_HELPER_BRN=/workspace/brn-daily-helpers/artifacts/brn-xberg-helper-brn
cd /workspace/brn-daily
mkdir -p "$CARGO_TARGET_DIR/debug"
printf '%s  %s\n' ee475910694951858eb8ae84daa4232a1724e03affb7968322a512684e963b1c "$BRN_XBERG_HELPER" cd286c69654e486c0b86086fd666bd910e934167d899811c322809f3598f6d2b "$BRN_XBERG_HELPER_BRN" | sha256sum -c -
cp "$BRN_XBERG_HELPER" "$BRN_XBERG_HELPER_BRN" "$CARGO_TARGET_DIR/debug/"
git rev-parse HEAD > /workspace/brn-batch-evidence/integrated-gates-source.txt
git diff --exit-code 2c33838d609cf76c55d8cd253d3ba12bada6d483 HEAD -- Cargo.lock crates/brn-intake tools/xberg-intake-helper scripts/prepare-xberg-adapted.py
stage() {
  local label=$1
  shift
  local started finished result
  started=$(date -u +%FT%TZ)
  if "$@" > "/workspace/brn-batch-evidence/${label}.log" 2>&1; then result=0; else result=$?; fi
  finished=$(date -u +%FT%TZ)
  printf '%s\t%s\t%s\t%s\n' "$label" "$result" "$started" "$finished" >> /workspace/brn-batch-evidence/integrated-gates-results.tsv
  printf '%s: exit %s\n' "$label" "$result"
  if (( result != 0 )); then tail -60 "/workspace/brn-batch-evidence/${label}.log"; fi
  return "$result"
}
stage integrated-format cargo fmt --all -- --check
stage integrated-build cargo build --workspace --locked --offline
stage integrated-clippy cargo clippy --workspace --all-targets --locked --offline -- -D warnings
stage integrated-workspace-tests cargo test --workspace --no-fail-fast --locked --offline
stage integrated-scripted-documents cargo test -p brn --features scripted-document-tests --bin brn document_route_tests --locked --offline --jobs 1
stage integrated-scripted-clippy cargo clippy -p brn --features scripted-document-tests --all-targets --locked --offline --jobs 1 -- -D warnings
stage integrated-end-to-end bash scripts/verify-end-to-end.sh --fixtures-only
