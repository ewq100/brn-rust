#!/usr/bin/env python3
"""Run one command under a Linux subreaper when the container PID 1 does not reap.
No signals, retries, test changes or background work; preserve command exit status.
"""
import ctypes, os, subprocess, sys
if not sys.argv[1:]:
    raise SystemExit("usage: run-with-reaping.py COMMAND [ARG...]")
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
    raise OSError(ctypes.get_errno(), "could not enable child reaping")
child = subprocess.Popen(sys.argv[1:])
while True:
    pid, status = os.waitpid(-1, 0)
    if pid == child.pid:
        result = os.waitstatus_to_exitcode(status)
        break
while True:
    try:
        if os.waitpid(-1, os.WNOHANG)[0] == 0:
            break
    except ChildProcessError:
        break
raise SystemExit(result if result >= 0 else 128-result)

