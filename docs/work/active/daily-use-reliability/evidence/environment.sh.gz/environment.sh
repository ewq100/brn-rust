export CARGO_HOME=/workspace/brn-environment/cargo
export RUSTUP_HOME=/workspace/brn-environment/rustup
export CARGO_TARGET_DIR=/workspace/brn-environment/target
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export RUST_BACKTRACE=1
export TMPDIR=/tmp/brn-daily-fixtures
