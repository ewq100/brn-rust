#!/bin/zsh
set -eu
. /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-tls-qualification-20261022T1006
export ORT_SKIP_DOWNLOAD=1 ORT_OFFLINE=1
cargo test --workspace --no-fail-fast --locked --offline --jobs 1
