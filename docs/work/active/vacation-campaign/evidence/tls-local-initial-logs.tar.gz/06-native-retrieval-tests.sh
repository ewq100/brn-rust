#!/bin/zsh
set -eu
. /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-tls-qualification-20261022T1006
export ORT_SKIP_DOWNLOAD=1 ORT_OFFLINE=1
cargo test -p brn-retrieval --features native --lib --test model_download --locked --offline --jobs 1
