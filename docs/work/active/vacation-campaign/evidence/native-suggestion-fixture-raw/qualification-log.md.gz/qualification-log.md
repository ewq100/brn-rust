# Native suggestion fixture qualification

Source pin: `f819329707d95b29389de50b6cddb3af17d5c11d`.
Full approved source diff SHA-256 vs `4e81fcba`: `d0dc6ad93128ab9088b6d2e4d0aecf95551f800b2c154f78ede14f79411d42d6`.
Output root: `/Users/evokessler/.codex/worktrees/notice-state/native-suggestion-fixture-evidence/workspace-1` (absent before run; harness creates it exclusively).
Canonical TMPDIR: `/private/tmp`.
Shared Cargo target: `/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target`.
Guide bundle source: `brn-threads-guidance-17`; actual persisted run guide identity will be recorded from the fixture's runtime report or read-only workspace inspection.

## Earlier compile failure retained

Command:

```sh
env TMPDIR=/private/tmp PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/usr/bin:/bin CARGO_TARGET_DIR=/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 /Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin/cargo test -p brn --test agent_runs --locked --offline --jobs 1 --no-run --message-format=short
```

Raw compiler diagnostic:

```text
Compiling brn v0.0.0 (/Users/evokessler/.codex/worktrees/notice-state/brn-rust/crates/brn)
crates/brn/tests/agent_runs.rs:1142:44: error[E0609]: no field `prepared` on type `&brn_threads_app::Prepared`: unknown field
error: could not compile `brn` (test "agent_runs") due to 1 previous error
```

Correction: use the public `Prepared.request_hash` field directly. Subsequent final-source Clippy and no-run compile passed. The recurring `rust-objcopy` SIGABRT while stripping debug info is a warning; Cargo exits successfully.

## Final pinned-source qualification

All commands used Rust 1.98.1, `TMPDIR=/private/tmp`, shared target above, `CARGO_INCREMENTAL=0`, `CARGO_PROFILE_DEV_DEBUG=0`, `CARGO_PROFILE_TEST_DEBUG=0`, `--no-default-features --locked --offline --jobs 1`. The qualification commands ran under `env -i` with `HOME=/private/tmp`, `CARGO_HOME=/Users/evokessler/.cargo`, `RUSTUP_HOME=/Users/evokessler/.rustup`, and `PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:/opt/homebrew/bin:/usr/bin:/bin`.

Compile-only command (exit 0; raw output in `compile-no-run.log`):

```sh
cargo test -p brn --no-default-features --test agent_runs --locked --offline --jobs 1 --no-run --message-format=short
```

The explicit output root was absent before invocation. The manual parent/child command (exit 0; raw output in `fixture-parent.log`):

```sh
cargo test -p brn --no-default-features --test agent_runs --locked --offline --jobs 1 native_suggestion_fixture_parent -- --ignored --exact --nocapture
```

It received `BRN_NATIVE_SUGGESTION_SOURCE_REVISION=f819329707d95b29389de50b6cddb3af17d5c11d` and `BRN_NATIVE_SUGGESTION_OUTPUT=/Users/evokessler/.codex/worktrees/notice-state/native-suggestion-fixture-evidence/workspace-1`. The parent created that output directory exclusively. It served the synthetic Copilot session on loopback only (3 HTTP exchanges, model `synthetic`, cached token `SYNTHETIC`); the child environment was cleared and restored only its private home/temp, required loader/PATH, closed proxies, fixture paths, source pin and parent gate. No real credentials or provider were used.

Parent/child result: 1 passed, 0 failed; child performed `read_note` and `prepare_changes`; candidate remained unapplied; both captured comments remained pending; no apply receipt or working run remained; unrelated Note stayed byte-for-byte unchanged. Ordinary CLI readback found the candidate, original Note and completed run. Reopening used `open_existing_no_upgrade` and verified Test purpose. The complete result is in `workspace-1/manifest.json`.

Existing test target (raw output in `agent-runs-existing.log`): 15 passed, 0 failed, 2 ignored (the parent and parent-only child). Strict test-target Clippy (raw output in `clippy-strict.log`) passed with `-D warnings`. Rustfmt check and `git diff --check` passed.

Guide identity read through the ordinary CLI from the persisted completed synthetic run: `brn-threads-guidance-17:b47c24e31327bcc1ef98d5ced398cb9090ca3588d7608a2a4ce2c8948e800a09`. Raw CLI JSON is in `ordinary-cli-runs.json`.

Final ordinary CLI binary: `/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target/debug/brn`, 33,130,008 bytes, SHA-256 `4001ec452dfcee939533bbd92acfc0a106d182691438205c3cf5815334b224a8`.
Final fixture test binary: `/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target/debug/deps/agent_runs-e993701530a17423`, 29,865,896 bytes, SHA-256 `771996c56e1cf7461d76c8bab6194dea706d9eb916fa6526060be30fd49ea13d`.
Manifest SHA-256: `003667a774597ee07d1cb4ae5fa2693c9e178d7d97c2888513407258e810063a`.

Builds also report `rust-objcopy` failed to strip debug info with SIGABRT; compilation and tests exit successfully. This warning is retained in the raw logs and is not counted as a test failure.

## Fresh-output refusal checks

After the successful qualification, I ran the frozen test executable directly (no Cargo/build) twice under the same source pin and confirmed its SHA-256 remained `771996c56e1cf7461d76c8bab6194dea706d9eb916fa6526060be30fd49ea13d`. Reusing `workspace-1` exited 101 at the exclusive `create_dir` with `AlreadyExists`, before the stub server or data setup. A relative output path exited 101 at the absolute-path assertion. These are expected refusal outcomes, not test failures. The raw outputs are `refusal-existing-output.log` and `refusal-relative-output.log`; exact invocations are recorded in `executed-commands.txt`.

Before and after each refusal, the complete five-file regular-file snapshot of the successful workspace matched by relative path, mode, size and SHA-256. The sentinel outside `workspace-1` remained byte-identical (`42` bytes; SHA-256 `003f4fe77aca9ad508558e91f5ab8df7505f3594438ab53dd42a1742d7c1524e`). The relative target was absent before and after. Snapshots are preserved as four JSON files; the successful workspace was not changed.

The third refusal used the existing 42-byte sentinel file itself as the requested output root. The frozen parent exited 101 with `AlreadyExists` at exclusive `create_dir`, before server/setup. The complete five-file workspace snapshot matched before and after; the sentinel exact hex bytes and SHA-256 remained unchanged. Raw output and snapshots are `refusal-sentinel-file.log`, `refusal-before-sentinel-file.json`, and `refusal-after-sentinel-file.json`. Exact command is appended to `refusal-probe-commands.txt`. No source, binary or successful workspace change occurred.
