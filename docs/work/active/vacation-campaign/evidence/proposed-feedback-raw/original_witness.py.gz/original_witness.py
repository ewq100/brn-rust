from pathlib import Path
import subprocess,hashlib,json,re,time
root=Path.cwd(); out=Path(__file__).resolve().parent; path=Path('crates/brn-threads-core/src/store.rs'); candidate=path.read_bytes(); original=subprocess.check_output(['git','show','e5a34684:crates/brn-threads-core/src/store.rs']); test=Path('crates/brn-threads-app/tests/writing.rs'); head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); assert not subprocess.check_output(['git','diff','HEAD'])
record={'kind':'original-module behavioral witness, not whole-baseline qualification','candidate_harness':head,'original_module_commit':'e5a346847231cf336cab213f6dce2b6f6e073e44','module':str(path),'original_module_sha256':hashlib.sha256(original).hexdigest(),'candidate_module_sha256':hashlib.sha256(candidate).hexdigest(),'test':str(test),'test_sha256':hashlib.sha256(test.read_bytes()).hexdigest(),'semantic_expected':'old guard accepts nonempty reports on changed text; valid replacement creation ID prevents later unrelated refusal'}
start=time.time()
try:
 path.write_bytes(original)
 record['witness_diff_sha256']=hashlib.sha256(subprocess.check_output(['git','diff','HEAD'])).hexdigest()
 (out/'original-guard-v2.patch').write_bytes(subprocess.check_output(['git','diff','HEAD']))
 code=subprocess.call(['python3',str(out/'run_check.py'),'original-guard-v2','cargo','test','-p','brn-threads-app','--test','writing','proposed_comments_reopen_checked_review_and_only_clear_on_owner_replacement','--locked','--offline','--jobs','1','--','--exact'])
 record['exit']=code
 log=(out/'original-guard-v2.log').read_text(); match=re.search(r'Running tests/writing.rs \(([^)]+)\)',log)
 if match:
  binary=Path(match.group(1));record['binary']={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()};dep=binary.with_suffix('.d');record['dep_info']={'path':str(dep),'sha256':hashlib.sha256(dep.read_bytes()).hexdigest()};(out/'original-guard-v2-test-dep-info.txt').write_bytes(dep.read_bytes())
  artifacts=[]
  for artifact in binary.parent.glob('libbrn_threads_core-*.rlib'):
   if artifact.stat().st_mtime>=start: artifacts.append({'path':str(artifact),'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest()})
  record['rebuilt_core_artifacts']=artifacts
finally:
 path.write_bytes(candidate)
 record['candidate_restored_byteexact']=path.read_bytes()==candidate
 record['restored_source_diff_sha256']=hashlib.sha256(subprocess.check_output(['git','diff','HEAD'])).hexdigest()
 (out/'original-guard-v2-linkage.json').write_text(json.dumps(record,indent=2))
