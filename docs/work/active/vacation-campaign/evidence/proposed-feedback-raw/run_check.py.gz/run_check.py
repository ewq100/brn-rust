import os,sys,subprocess,time,json,shutil,signal,threading,hashlib,tempfile
from pathlib import Path
root=Path.cwd(); evidence=Path(__file__).resolve().parent
name=sys.argv[1]; command=sys.argv[2:]
env=os.environ.copy(); env.update({
"TMPDIR":str(Path(tempfile.gettempdir()).resolve()),
"PATH":"/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:"+env.get("PATH",""),
"RUSTUP_TOOLCHAIN":"1.98.1", "CARGO_TARGET_DIR":"/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target",
"CARGO_INCREMENTAL":"0", "CARGO_PROFILE_DEV_DEBUG":"0", "CARGO_PROFILE_TEST_DEBUG":"0", "RUST_TEST_THREADS":"1",
"DYLD_LIBRARY_PATH":"/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib",
"BRN_XBERG_HELPER":"/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper",
"BRN_XBERG_HELPER_BRN":"/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper-brn"})
record={"command":command,"cwd":str(root),"head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"tree":subprocess.check_output(["git","rev-parse","HEAD^{tree}"],text=True).strip(),"diff_sha256":hashlib.sha256(subprocess.check_output(["git","diff","HEAD"])).hexdigest(),"status":subprocess.check_output(["git","status","--short"],text=True),"environment":{key:env[key] for key in ["PATH","RUSTUP_TOOLCHAIN","CARGO_TARGET_DIR","CARGO_INCREMENTAL","CARGO_PROFILE_DEV_DEBUG","CARGO_PROFILE_TEST_DEBUG","RUST_TEST_THREADS","TMPDIR","DYLD_LIBRARY_PATH","BRN_XBERG_HELPER","BRN_XBERG_HELPER_BRN"]},"disk_before":shutil.disk_usage(root).free}
if record["disk_before"]<1024**3: raise SystemExit("Disk below1GiB; check not started")
(evidence/(name+".json")).write_text(json.dumps(record,indent=2))
start=time.monotonic(); log=open(evidence/(name+".log"),"w"); proc=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
def monitor():
 while proc.poll() is None:
  if shutil.disk_usage(root).free<1024**3:
   record["disk_stop"]=True;os.killpg(proc.pid,signal.SIGTERM);return
  time.sleep(1)
threading.Thread(target=monitor,daemon=True).start()
code=proc.wait();log.close();record.update({"exit":code,"elapsed_seconds":time.monotonic()-start,"disk_after":shutil.disk_usage(root).free})
(evidence/(name+".json")).write_text(json.dumps(record,indent=2));print(name,"exit",code,"seconds",round(record["elapsed_seconds"],1),"disk_GiB",round(record["disk_after"]/1024**3,2));print((evidence/(name+".log")).read_text()[-14000:]);sys.exit(code)
