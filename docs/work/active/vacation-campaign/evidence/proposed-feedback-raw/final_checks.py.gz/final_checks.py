import subprocess,sys
from pathlib import Path
checks=[
('final-core-canonical', ['cargo','test','-p','brn-threads-core','--locked','--offline','--jobs','1']),
('final-runtime', ['cargo','test','-p','brn-ai','--lib','--features','scripted-runs','--locked','--offline','--jobs','1']),
('final-app', ['cargo','test','-p','brn-threads-app','--lib','--test','writing','--test','product','--test','cw2_review','--test','writing_context','--test','writing_setup','--locked','--offline','--jobs','1']),
('final-native-writing', ['cargo','test','-p','brn-desktop','--features','native-ui,native-test-support','writing_tests','--locked','--offline','--jobs','1']),
('final-native', ['cargo','test','-p','brn-desktop','--features','native-ui,native-test-support','--locked','--offline','--jobs','1']),
('final-writing-ui', ['cargo','test','-p','brn-writing-ui','--features','native-ui,native-test-support','--locked','--offline','--jobs','1']),
('final-strict-lint', ['cargo','clippy','-p','brn-threads-core','-p','brn-ai','-p','brn-threads-app','-p','brn-writing-ui','-p','brn-desktop','-p','brn','--features','brn-ai/scripted-runs,brn-desktop/native-ui,brn-desktop/native-test-support','--all-targets','--locked','--offline','--jobs','1','--','-D','warnings']),
('final-cli', ['cargo','test','-p','brn','--test','agent_contract','--test','agent_authority','--test','agent_runs','--locked','--offline','--jobs','1']),
('final-production', ['cargo','build','-p','brn-desktop','--features','native-ui','--locked','--offline','--jobs','1']),
('final-fmt', ['cargo','fmt','--all','--','--check'])]
for name,command in checks:
 code=subprocess.call([sys.executable,str(Path(__file__).with_name('run_check.py')),name,*command])
 if code:sys.exit(code)
