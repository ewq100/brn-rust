# M1 pre-effect argument correction handoff

Source: `7b3cf356bea846a3f9771186a26663968e0a2e5f`, branch `codex/pre-effect-tool-correction`, base M0 `527d47679adef0c1cf2dfe83869eb14d590b1c39`. Worktree is clean. Four local commits retain the original candidate, revised schema witnesses, independent-review boundary fixes and the test lock-lifetime fix. Source, commands, compiler/environment and raw-log hashes are recorded in each JSON receipt; `summary.json` binds the final gates.

The host retains one owner for pre-dispatch validation. Known offered tools with eligible well-formed JSON argument mistakes get an ordinary skipped result through Rig's existing dispatch hook. Every sibling is skipped before dispatch traces/activity/capture or external grant spending. Two feedback batches are allowed per invocation within existing model/tool/context/time/Stop limits, and successful turns never replenish the allowance. No provider retry settings or dependencies change. Typed policy validation dominates shape mistakes, including independently recognizable forbidden record data, unavailable skill access components and any refresh writing field. Receipt/replay handling and helper semantics remain in their original owners. The guide is bundle15; base-guide content and summary invalidation stay bound to the new identity.

Final gates at the exact source above:

- `final-scripted-lib-04`: locked/offline scripted brn-ai library, 505 passed / 0 failed / 2 ignored, exit0. The ignored entries are the parent-launched isolated synthetic stderr child and the explicitly gated manual principal diagnostic. No live activation is claimed.
- `final-clippy-02`: locked/offline scripted brn-ai all-target strict Clippy, exit0.
- `final-fmt`: all-workspace formatting check, exit0.
- `final-diff-check`: M0-base-to-head whitespace check, exit0.

Focused witnesses (11/11 before the last test-only lifetime block) cover both mixed-batch orders, valid correction, invocation-total allowance across an intervening valid turn, lower rounds/context admission, cancellation/current scope, candidate/apply replay and conflicting changed-content reuse of a request key, actual Responses/Chat second-request call/result pairing, real loopback MCP unspent grant/one subsequent call, and combined shape/policy faults. Final full suite includes every focused witness, existing helpers, scope/protection/writing/grant/read/replay/Undo boundaries and prior-summary invalidation.

Retained non-final results:

- `focused-01`: compiler error from the existing core Result alias shadowing the new validation result; signatures now use std::result::Result.
- `focused-02`: compile succeeded with the raw rust-objcopy/libLLVM warning, then4/2 tests; witness assumptions about direct scope terminal mapping and response/safety reserve were corrected. The scope guard still blocks another completion/effect.
- `focused-03`:7/7 passed before independent review exposed additional combined-fault gaps. This result is not a substitute for final qualification.
- `final-scripted-lib`: original cf238 full result498/3/2. Two cases retained obsolete schema-abort assumptions; the refresh-writing case exposed a genuine hard-refusal classification defect, now fixed with its original refusal witness restored.
- `final-scripted-lib-02`: a5 source compiled, then test execution was intentionally interrupted with SIGINT at the lead's request after independent review. No suite result is claimed.
- `review-correction-focused`:11/11 passed after all three independent source findings were fixed.
- `final-scripted-lib-03`: ff8f505/0/2 passed; the following strict Clippy caught an explicit-drop test guard lifetime.
- `final-clippy`: failed on the new MCP test's lock-before-await lint. A lexical block now releases it; no suppression or production semantic change.

The warning fix uses only invocation-local DYLD_LIBRARY_PATH pointing to the already-installed pinned toolchain lib directory. No global toolchain/configuration/install was changed. Final runs use Rust1.98.1, one job/thread, zero incremental/debug, the shared target and the already-qualified stock/adapted helpers. Disk stayed above3GiB; no new target or helper build was created.

Independent final review remains the lead/reviewer's gate. No live model usefulness, native observation, owner acceptance, merge, release or adoption result is claimed. The CLI guide-prefix assertion was updated but its CLI suite was not run here; capability-spike was not separately qualified. Shared architecture/behavior/campaign documentation and M2 files remain the lead/M2 owners' work.
