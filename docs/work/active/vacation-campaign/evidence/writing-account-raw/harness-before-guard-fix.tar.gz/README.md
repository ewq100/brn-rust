# Synthetic Codex writing smoke harness

This is a standalone consumer of the production BRN runtime. It provides three modes: `prepare` creates an isolated synthetic workspace and frozen v2 writing request; `run` requires the exact reserved ledger entry and dispatches one production `RewriteNote` run; `verify` checks source preservation, pending feedback, and one useful unapplied proposal. It cannot Apply or Undo a proposal. The lead owns any invocation and must independently review this source before use.

## Compile and feature boundary

The checked source is pinned to Rust 1.98.1. The consumer uses only ordinary dependencies on `brn-threads-app`, `brn-threads-core`, and `brn-ai`, plus serde/JSON, SHA-256, Tokio and tokio-util already present in the root lock. No features are enabled in this consumer manifest. `brn-ai` has no default features; its `scripted-runs` and `capability-spike` features are absent. `brn-threads-app`'s `brn-ai/scripted-runs` entry is a dev-dependency and does not propagate into a normal downstream consumer. See `feature-tree.log` and the package feature declarations in the BRN source tree.

The copied lock initially lacked this consumer's package entry. `cargo metadata --offline` added the consumer root package and pruned unrelated workspace packages from the copied lock; every retained third-party package version remains one already present in the root lock. No dependency download or version update was made. `Cargo.lock` is independent of the repository root lock.

Compilation commands used from this directory:

```sh
PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:$PATH \
CARGO_TARGET_DIR=/Users/evokessler/.codex/worktrees/vacation-hardening/codex-writing-evidence/harness/target \
cargo check --locked --offline --jobs=1

PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:$PATH \
CARGO_TARGET_DIR=/Users/evokessler/.codex/worktrees/vacation-hardening/codex-writing-evidence/harness/target \
cargo build --locked --offline --jobs=1
```

The full command history and compiler diagnostics are in `compile.log`. `build-binding.json` records the final source hash, linked executable hash, and toolchain. Compilation produced the executable under `target/debug/brn-writing-smoke-harness`; it has not been run. No tests, fixtures, provider setup, credential operations, or runtime modes were invoked in this task.

## Guarded execution contract

`prepare ABSOLUTE_FRESH_DATA` requires an existing canonical parent and an absent leaf. It atomically claims the fresh root with `create_dir` before opening a workspace. It creates one short Note containing `cobalt boats`, one exact-range captured comment requesting only `teal boats`, and a separate sentinel Note. It configures only this synthetic workspace for Codex `gpt-6-luna`, low effort. `Workspace::open` derives the account file location from `CODEX_HOME/auth.json` or `HOME/.codex/auth.json`; preparation does not open, stat, print, copy, or edit credentials. It records a source/binary-bound `manifest.json` inside DATA, including source record IDs, versions, hashes, exact expected Markdown, and the frozen request hash.

`run ABSOLUTE_DATA --attempt-id ID --ledger ABSOLUTE_LEDGER` requires one reserved attempt dated 20 October 2026, a 20 October session, the existing Codex account, Luna/low, four rounds, 180 seconds, and a matching binary SHA-256. The attempt must bind DATA directly via `data_directory`, or bind an evidence directory containing DATA. The binary hash in the manifest is checked against the ledger; the manifest also checks the harness source hash before dispatch. The durable `dispatch.json` marker is written before spawning the production run and permanently prevents retry from this DATA root, including after uncertain outcomes. The runtime event sink drops all event payloads. A deadline cancels the client token, waits up to five seconds for the local run to settle, records any visible terminal state, and never claims upstream cancellation.

The pass condition requires one candidate for the frozen request, one whole-note proposal whose only text change is `cobalt boats` to `teal boats`, the captured comment as a current input, unchanged original and sentinel records, the comment still pending, and no Apply/Undo receipt. Failure and uncertain outcomes are retained as sanitized JSON; provider messages and raw responses are never printed. Live allowance checks, ledger reservation, and any account dispatch remain the lead's responsibility.
