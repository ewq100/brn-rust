use brn_ai::{AiEvent, AiTerminal, threads};
use brn_threads_app::{OwnerRequest, ThreadRunStart, TraceLevel, Workspace, WritingCommentInput};
use brn_threads_core::{
    Record, RecordData, RunState, WRITING_EVIDENCE_ROLE, WritingCandidateEvidence,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    env,
    fs::{self, OpenOptions},
    io::Write,
    path::{Component, Path, PathBuf},
    process,
    sync::Arc,
    time::Duration,
};
use tokio_util::sync::CancellationToken;

const NOTE_TITLE: &str = "Synthetic cobalt boats rewrite";
const NOTE_TEXT: &str = "The harbor draft describes cobalt boats crossing the bay at dawn.";
const COMMENT_BODY: &str =
    "Replace only ‘cobalt boats’ with ‘teal boats’; preserve every other character.";
const SENTINEL_TITLE: &str = "Synthetic unrelated sentinel";
const SENTINEL_TEXT: &str = "Unrelated synthetic record: amber lantern remains unchanged.";
const PROMPT: &str = "Rewrite the saved document using the captured feedback and selected chat; prepare a whole-note proposal for review.";
const DEADLINE: Duration = Duration::from_secs(180);
const CANCELLATION_GRACE: Duration = Duration::from_secs(5);
const ATTEMPT_DATE: &str = "2026-10-20";

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Manifest {
    format: u8,
    data_directory: String,
    note_id: String,
    note_version: u64,
    note_markdown: String,
    note_record_sha256: String,
    sentinel_id: String,
    sentinel_version: u64,
    sentinel_markdown: String,
    sentinel_record_sha256: String,
    writing_thread: String,
    comment_id: String,
    comment_version: u64,
    comment_record_sha256: String,
    request_message: String,
    request_sha256: String,
    phrase: String,
    replacement: String,
    original_expected_candidate: String,
    binary_sha256: String,
    source_sha256: String,
    result: Option<SanitizedResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct SanitizedResult {
    attempt_id: String,
    terminal: String,
    run_id: String,
    run_state: String,
    model: String,
    tool_round_budget: u64,
    saved_outcome: String,
    candidate_operations: Vec<String>,
    candidate_note_ids: Vec<String>,
    trace: Option<TraceSummary>,
    failure_kind: Option<String>,
    deadline_fired: bool,
    upstream_cancellation_confirmed: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct TraceSummary {
    rounds: u16,
    max_rounds: u16,
    model_turns: usize,
    elapsed_ms: u64,
    usage: Option<UsageSummary>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct UsageSummary {
    input: u64,
    output: u64,
    cached_input: u64,
}

fn main() {
    if let Err(error) = entry() {
        eprintln!("harness_refused: {error}");
        process::exit(2);
    }
}

fn entry() -> Result<(), String> {
    let mut args = env::args_os().skip(1);
    let mode = args.next().ok_or_else(usage)?;
    let data_arg = args.next().ok_or_else(usage)?;
    let data = PathBuf::from(data_arg);
    match mode.to_str() {
        Some("prepare") if args.next().is_none() => prepare(&data),
        Some("verify") if args.next().is_none() => verify(&data),
        Some("run") => {
            let mut attempt = None;
            let mut ledger = None;
            while let Some(arg) = args.next() {
                match arg.to_str() {
                    Some("--attempt-id") if attempt.is_none() => {
                        attempt = Some(
                            args.next()
                                .ok_or_else(usage)?
                                .into_string()
                                .map_err(|_| usage())?,
                        )
                    }
                    Some("--ledger") if ledger.is_none() => {
                        ledger = Some(PathBuf::from(args.next().ok_or_else(usage)?))
                    }
                    _ => return Err(usage()),
                }
            }
            let runtime = tokio::runtime::Builder::new_multi_thread()
                .enable_all()
                .build()
                .map_err(|_| "Tokio runtime initialization failed")?;
            runtime.block_on(run(
                &data,
                &attempt.ok_or_else(usage)?,
                &ledger.ok_or_else(usage)?,
            ))
        }
        _ => Err(usage()),
    }
}

fn usage() -> String {
    "usage: brn-writing-smoke-harness prepare ABSOLUTE_FRESH_DATA | run ABSOLUTE_DATA --attempt-id RESERVED_ID --ledger ABSOLUTE_LEDGER | verify ABSOLUTE_DATA".into()
}

fn prepare(data: &Path) -> Result<(), String> {
    let target = validate_new_root(data)?;
    let combined_input_bytes =
        NOTE_TEXT.len() + COMMENT_BODY.len() + SENTINEL_TEXT.len() + PROMPT.len();
    if combined_input_bytes > 8192 {
        return Err("synthetic initial input exceeds the campaign byte limit".into());
    }
    fs::create_dir(&target).map_err(|_| "data directory already exists or cannot be created")?;
    let mut workspace =
        Workspace::open(&target).map_err(|_| "fresh workspace initialization failed")?;
    configure_synthetic_codex(&mut workspace)?;

    let note = workspace
        .new_note_with_key("cobalt-boats-note", NOTE_TITLE, NOTE_TEXT)
        .map_err(|_| "synthetic Note creation failed")?
        .writes
        .into_iter()
        .next()
        .ok_or("synthetic Note receipt was empty")?
        .after;
    let sentinel = workspace
        .new_note_with_key("cobalt-boats-sentinel", SENTINEL_TITLE, SENTINEL_TEXT)
        .map_err(|_| "synthetic sentinel creation failed")?
        .writes
        .into_iter()
        .next()
        .ok_or("sentinel receipt was empty")?
        .after;
    let context = workspace
        .ensure_writing_context("cobalt-boats-context", &note.id, None)
        .map_err(|_| "writing context creation failed")?;
    let thread = context
        .conversation
        .ok_or("writing context has no conversation")?;
    let phrase = "cobalt boats";
    let start = NOTE_TEXT.find(phrase).ok_or("synthetic phrase missing")?;
    let end = start + phrase.len();
    let comment = workspace
        .add_writing_comment(
            "cobalt-boats-comment",
            &WritingCommentInput {
                note: note.id.clone(),
                version: note.version,
                thread: thread.clone(),
                range: (start, end),
                quote: phrase.into(),
                body: COMMENT_BODY.into(),
            },
        )
        .map_err(|_| "synthetic captured comment creation failed")?;
    let snapshot = workspace
        .snapshot_writing_request_with_feedback(
            "cobalt-boats-request",
            &note.id,
            note.version,
            &thread,
            std::slice::from_ref(&comment.id),
            "",
        )
        .map_err(|_| "frozen writing request capture failed")?;
    let frozen = workspace
        .writing_request_in_context(&snapshot.request_message, &note.id, Some(&thread))
        .map_err(|_| "frozen writing request failed validation")?;
    if frozen.setup.is_none()
        || frozen.comments.len() != 1
        || frozen.comments[0].id != comment.id
        || frozen.note != note
        || frozen
            .message_text()
            .map_err(|_| "frozen request serialization failed")?
            != snapshot
                .message_text()
                .map_err(|_| "frozen request serialization failed")?
    {
        return Err("frozen request did not bind exactly the expected Note and comment".into());
    }
    let current_note = workspace
        .store
        .record(&note.id)
        .map_err(|_| "Note read failed")?
        .ok_or("Note disappeared")?;
    let current_sentinel = workspace
        .store
        .record(&sentinel.id)
        .map_err(|_| "sentinel read failed")?
        .ok_or("sentinel disappeared")?;
    let current_comment = workspace
        .store
        .record(&comment.id)
        .map_err(|_| "comment read failed")?
        .ok_or("comment disappeared")?;
    let configured = workspace
        .settings()
        .map_err(|_| "workspace settings read failed")?;
    let auth_location_configured = configured.auth_file.is_some();
    let manifest = Manifest {
        format: 1,
        data_directory: target.to_string_lossy().into_owned(),
        note_id: note.id.clone(),
        note_version: note.version,
        note_markdown: NOTE_TEXT.into(),
        note_record_sha256: digest_record(&current_note)?,
        sentinel_id: sentinel.id.clone(),
        sentinel_version: sentinel.version,
        sentinel_markdown: SENTINEL_TEXT.into(),
        sentinel_record_sha256: digest_record(&current_sentinel)?,
        writing_thread: thread,
        comment_id: comment.id,
        comment_version: comment.version,
        comment_record_sha256: digest_record(&current_comment)?,
        request_message: snapshot.request_message.clone(),
        request_sha256: digest(
            snapshot
                .message_text()
                .map_err(|_| "frozen request serialization failed")?
                .as_bytes(),
        ),
        phrase: phrase.into(),
        replacement: "teal boats".into(),
        original_expected_candidate: NOTE_TEXT.replace(phrase, "teal boats"),
        binary_sha256: digest(
            &fs::read(env::current_exe().map_err(|_| "current executable path unavailable")?)
                .map_err(|_| "current executable hash unavailable")?,
        ),
        source_sha256: source_digest(),
        result: None,
    };
    write_json_atomic(&target.join("manifest.json"), &manifest)?;
    println!(
        "prepared synthetic writing request; auth_location_configured={auth_location_configured}; no credential file was opened"
    );
    println!(
        "note_id={} comment_id={} request_id={} sentinel_id={}",
        manifest.note_id, manifest.comment_id, manifest.request_message, manifest.sentinel_id
    );
    Ok(())
}

async fn run(data: &Path, attempt_id: &str, ledger: &Path) -> Result<(), String> {
    let target = validate_existing_root(data)?;
    let mut manifest = read_manifest(&target)?;
    if manifest.format != 1
        || manifest.data_directory != target.to_string_lossy()
        || manifest.note_markdown != NOTE_TEXT
        || manifest.sentinel_markdown != SENTINEL_TEXT
        || manifest.phrase != "cobalt boats"
        || manifest.replacement != "teal boats"
        || manifest.original_expected_candidate != NOTE_TEXT.replace("cobalt boats", "teal boats")
    {
        return Err("manifest does not match this source-bound synthetic fixture".into());
    }
    if manifest.result.is_some() || target.join("dispatch.json").exists() {
        return Err(
            "this synthetic workspace already has a dispatch/result marker; no retry is allowed"
                .into(),
        );
    }
    let executable = env::current_exe().map_err(|_| "current executable path unavailable")?;
    let binary_hash =
        digest(&fs::read(executable).map_err(|_| "current executable hash unavailable")?);
    if binary_hash != manifest.binary_sha256 || source_digest() != manifest.source_sha256 {
        return Err("harness binary or source differs from the prepared manifest".into());
    }
    validate_reserved_attempt(ledger, attempt_id, &target, &binary_hash)?;
    let mut workspace = Workspace::open_existing_no_upgrade(&target)
        .map_err(|_| "synthetic workspace could not be opened safely")?;
    let before = validate_fixture(&workspace, &manifest)?;
    if !before {
        return Err("synthetic source bytes or pending feedback changed before dispatch".into());
    }
    if !workspace
        .candidates()
        .map_err(|_| "candidate preflight failed")?
        .is_empty()
    {
        return Err("fresh synthetic workspace already has a proposal; dispatch refused".into());
    }
    let snapshot = workspace
        .writing_request_in_context(
            &manifest.request_message,
            &manifest.note_id,
            Some(&manifest.writing_thread),
        )
        .map_err(|_| "frozen request validation failed before dispatch")?;
    if snapshot.setup.is_none()
        || snapshot.comments.len() != 1
        || snapshot.comments[0].id != manifest.comment_id
        || snapshot.comments[0].version != manifest.comment_version
    {
        return Err("frozen request is not the exact v2 single-comment fixture".into());
    }
    if digest(
        snapshot
            .message_text()
            .map_err(|_| "frozen request serialization failed")?
            .as_bytes(),
    ) != manifest.request_sha256
    {
        return Err("frozen request differs from source-bound manifest".into());
    }
    let settings = workspace
        .settings()
        .map_err(|_| "workspace settings unavailable")?;
    if settings.provider != "Codex" || settings.model != "gpt-6-luna" || settings.effort != "low" {
        return Err(
            "workspace is not configured for the authorized Codex Luna low selection".into(),
        );
    }
    let prepared = workspace
        .prepare_thread_run(ThreadRunStart {
            thread: manifest.writing_thread.clone(),
            prompt: PROMPT.into(),
            request_message: None,
            queue_claim: None,
            owner_request: Some(OwnerRequest::RewriteNote {
                request_message: manifest.request_message.clone(),
            }),
            sources: vec![],
            max_tool_rounds: Some(4),
            trace: TraceLevel::Summary,
            offered_copilot_models: None,
        })
        .map_err(|_| "normal production run preparation refused; no provider outcome assumed")?;
    let run_id = prepared.prepared.run_id().to_owned();
    write_json_atomic(
        &target.join("dispatch.json"),
        &serde_json::json!({"attempt_id": attempt_id, "run_id": run_id, "binary_sha256": binary_hash, "source_sha256": manifest.source_sha256}),
    )?;
    let cancel = CancellationToken::new();
    let worker_cancel = cancel.clone();
    let handle = tokio::spawn(async move {
        threads::run_prepared(
            prepared.prepared,
            worker_cancel,
            Arc::new(|_event: AiEvent| {}),
        )
        .await
    });
    let outcome = execute_deadlined(handle, cancel).await;
    let deadline_hit = matches!(
        &outcome,
        Execution::DeadlineUnknown | Execution::DeadlineObserved(_)
    );
    let after_workspace = match Workspace::open_existing_no_upgrade(&target) {
        Ok(workspace) => workspace,
        Err(_) => {
            persist_unknown(&target, &mut manifest, attempt_id, &run_id, deadline_hit)?;
            return Err("run completion was recorded as unknown because workspace persistence could not be read".into());
        }
    };
    let run_record = after_workspace.store.record(&run_id).ok().flatten();
    let (terminal, failure_kind, trace, deadline_fired) = match outcome {
        Execution::Finished(Ok(result)) => {
            let (terminal, failure_kind) = match result.answer.terminal {
                AiTerminal::Completed => ("Completed".to_string(), None),
                AiTerminal::Interrupted => ("Interrupted".to_string(), None),
                AiTerminal::Failed(error) => {
                    ("Failed".to_string(), Some(format!("{:?}", error.kind)))
                }
            };
            let trace = result.trace.map(|trace| TraceSummary {
                rounds: trace.rounds,
                max_rounds: trace.max_rounds,
                model_turns: trace.model_turns,
                elapsed_ms: trace.elapsed_ms,
                usage: trace.usage.map(|usage| UsageSummary {
                    input: usage.input,
                    output: usage.output,
                    cached_input: usage.cached_input,
                }),
            });
            (terminal, failure_kind, trace, false)
        }
        Execution::Finished(Err(error)) => (
            "Failed".into(),
            Some(format!("{:?}", error.kind)),
            None,
            false,
        ),
        Execution::JoinFailed => ("Unknown".into(), Some("JoinFailed".into()), None, false),
        Execution::DeadlineUnknown => ("Unknown".into(), Some("ClientDeadline".into()), None, true),
        Execution::DeadlineObserved(state) => (state, Some("ClientDeadline".into()), None, true),
    };
    let (run_state, model, budget) = run_record
        .as_ref()
        .and_then(|record| match &record.data {
            RecordData::Run(run) => {
                Some((format!("{:?}", run.state), run.model.clone(), run.budget))
            }
            _ => None,
        })
        .unwrap_or_else(|| ("Missing".into(), "gpt-6-luna".into(), 4));
    let after = validate_fixture(&after_workspace, &manifest).unwrap_or(false);
    let (candidate_operations, candidate_note_ids) =
        match summarize_candidates(&after_workspace, &manifest) {
            Ok((operations, note_ids, _)) => (operations, note_ids),
            Err(_) => (Vec::new(), Vec::new()),
        };
    let useful = terminal == "Completed"
        && !deadline_fired
        && candidate_operations.len() == 1
        && candidate_note_ids.len() == 1;
    let result = SanitizedResult {
        attempt_id: attempt_id.into(),
        terminal,
        run_id,
        run_state,
        model,
        tool_round_budget: budget,
        saved_outcome: if useful {
            "one useful frozen-request whole-note proposal"
        } else {
            "qualification failed; inspect sanitized evidence"
        }
        .into(),
        candidate_operations,
        candidate_note_ids,
        trace,
        failure_kind,
        deadline_fired,
        upstream_cancellation_confirmed: false,
    };
    if !after || !useful || !before {
        manifest.result = Some(result.clone());
        write_json_atomic(&target.join("manifest.json"), &manifest)?;
        write_json_atomic(&target.join("result.json"), &result)?;
        return Err(
            "live result was recorded but exact no-change/proposal assertions failed".into(),
        );
    }
    manifest.result = Some(result.clone());
    write_json_atomic(&target.join("manifest.json"), &manifest)?;
    write_json_atomic(&target.join("result.json"), &result)?;
    println!(
        "{}",
        serde_json::to_string_pretty(&result).map_err(|_| "result serialization failed")?
    );
    Ok(())
}

fn verify(data: &Path) -> Result<(), String> {
    let target = validate_existing_root(data)?;
    let manifest = read_manifest(&target)?;
    if manifest.format != 1
        || manifest.data_directory != target.to_string_lossy()
        || manifest.note_markdown != NOTE_TEXT
        || manifest.sentinel_markdown != SENTINEL_TEXT
        || manifest.phrase != "cobalt boats"
        || manifest.replacement != "teal boats"
        || manifest.original_expected_candidate != NOTE_TEXT.replace("cobalt boats", "teal boats")
    {
        return Err("manifest does not match this source-bound synthetic fixture".into());
    }
    if manifest.source_sha256 != source_digest()
        || manifest.binary_sha256
            != digest(
                &fs::read(env::current_exe().map_err(|_| "current executable path unavailable")?)
                    .map_err(|_| "current executable hash unavailable")?,
            )
    {
        return Err("harness source/binary no longer matches prepared manifest".into());
    }
    let workspace = Workspace::open_existing_no_upgrade(&target)
        .map_err(|_| "synthetic workspace open failed")?;
    let exact = validate_fixture(&workspace, &manifest)?;
    let (candidate_operations, candidate_note_ids, outcome) =
        summarize_candidates(&workspace, &manifest)?;
    let result = manifest.result.ok_or("no run result is recorded")?;
    let run_record = workspace
        .store
        .record(&result.run_id)
        .map_err(|_| "saved run record is unavailable")?
        .ok_or("saved run record is missing")?;
    let run_provenance = matches!(
        &run_record.data,
        RecordData::Run(run)
            if run.thread == manifest.writing_thread
                && run.provider == "Codex"
                && run.model == "gpt-6-luna"
                && run.budget == 4
                && run.state == RunState::Completed
                && result.candidate_operations.len() == 1
                && run.operations.iter().any(|operation| operation.as_str() == result.candidate_operations[0])
    );
    if !exact
        || !run_provenance
        || result.terminal != "Completed"
        || result.run_state != "Completed"
        || result.deadline_fired
        || result.saved_outcome != "one useful frozen-request whole-note proposal"
        || result.candidate_operations != candidate_operations
        || result.candidate_note_ids != candidate_note_ids
        || candidate_operations.len() != 1
        || candidate_note_ids.len() != 1
        || outcome != "one useful frozen-request whole-note proposal"
    {
        return Err("saved qualification assertions did not pass".into());
    }
    println!(
        "verified synthetic source preservation, pending feedback, and one useful proposal; Apply/Undo not performed"
    );
    Ok(())
}

fn persist_unknown(
    data: &Path,
    manifest: &mut Manifest,
    attempt_id: &str,
    run_id: &str,
    deadline_fired: bool,
) -> Result<(), String> {
    let result = SanitizedResult {
        attempt_id: attempt_id.into(),
        terminal: "Unknown".into(),
        run_id: run_id.into(),
        run_state: "Unreadable".into(),
        model: "gpt-6-luna".into(),
        tool_round_budget: 4,
        saved_outcome: "qualification outcome unknown; persistence could not be read".into(),
        candidate_operations: Vec::new(),
        candidate_note_ids: Vec::new(),
        trace: None,
        failure_kind: Some(
            if deadline_fired {
                "ClientDeadline"
            } else {
                "PersistenceRead"
            }
            .into(),
        ),
        deadline_fired,
        upstream_cancellation_confirmed: false,
    };
    manifest.result = Some(result.clone());
    write_json_atomic(&data.join("manifest.json"), manifest)?;
    write_json_atomic(&data.join("result.json"), &result)
}

fn configure_synthetic_codex(workspace: &mut Workspace) -> Result<(), String> {
    let mut settings = workspace
        .settings()
        .map_err(|_| "synthetic workspace settings unavailable")?;
    settings.provider = "Codex".into();
    settings.model = "gpt-6-luna".into();
    settings.effort = "low".into();
    settings.credentials_dir = None;
    workspace
        .configure(settings)
        .map_err(|_| "synthetic workspace Codex selection failed")?;
    Ok(())
}

fn validate_fixture(workspace: &Workspace, manifest: &Manifest) -> Result<bool, String> {
    let note = workspace
        .store
        .record(&manifest.note_id)
        .map_err(|_| "original Note read failed")?
        .ok_or("original Note missing")?;
    let sentinel = workspace
        .store
        .record(&manifest.sentinel_id)
        .map_err(|_| "sentinel read failed")?
        .ok_or("sentinel missing")?;
    let comment = workspace
        .store
        .record(&manifest.comment_id)
        .map_err(|_| "captured comment read failed")?
        .ok_or("captured comment missing")?;
    let comments = workspace
        .writing_comments(&manifest.note_id)
        .map_err(|_| "pending comment state read failed")?;
    let comment_pending = comments
        .iter()
        .any(|entry| entry.record.id == manifest.comment_id && !entry.addressed);
    let receipts = workspace.history().map_err(|_| "receipt listing failed")?;
    let no_apply = receipts.iter().all(|receipt| {
        receipt.undo_of.is_none()
            && !receipt.writes.iter().any(|write| {
                write.after.id == manifest.note_id
                    && matches!(write.after.data, RecordData::Note(_))
                    && write
                        .before
                        .as_ref()
                        .is_some_and(|before| before.id == manifest.note_id)
            })
    });
    Ok(note.version == manifest.note_version
        && digest_record(&note)? == manifest.note_record_sha256
        && sentinel.version == manifest.sentinel_version
        && digest_record(&sentinel)? == manifest.sentinel_record_sha256
        && matches!(&note.data, RecordData::Note(data) if data.title == NOTE_TITLE && data.markdown == NOTE_TEXT && data.markdown == manifest.note_markdown)
        && matches!(&sentinel.data, RecordData::Note(data) if data.title == SENTINEL_TITLE && data.markdown == SENTINEL_TEXT && data.markdown == manifest.sentinel_markdown)
        && comment.version == manifest.comment_version
        && manifest.phrase == "cobalt boats"
        && manifest.replacement == "teal boats"
        && digest_record(&comment)? == manifest.comment_record_sha256
        && matches!(&comment.data, RecordData::Comment(data) if data.note == manifest.note_id && data.base_version == manifest.note_version && data.body == COMMENT_BODY && data.quote == "cobalt boats" && data.range == Some((NOTE_TEXT.find("cobalt boats").unwrap_or(usize::MAX), NOTE_TEXT.find("cobalt boats").unwrap_or(usize::MAX) + "cobalt boats".len())))
        && comment_pending
        && no_apply)
}

fn summarize_candidates(
    workspace: &Workspace,
    manifest: &Manifest,
) -> Result<(Vec<String>, Vec<String>, String), String> {
    let candidates = workspace
        .candidates()
        .map_err(|_| "candidate listing failed")?;
    let mut matched = Vec::new();
    for candidate in candidates {
        let evidence = candidate
            .request
            .writes
            .iter()
            .find_map(|write| match &write.data {
                RecordData::Message(message) if message.role == WRITING_EVIDENCE_ROLE => {
                    serde_json::from_str::<WritingCandidateEvidence>(&message.text).ok()
                }
                _ => None,
            });
        let Some(evidence) = evidence else { continue };
        if evidence.request_message != manifest.request_message
            || evidence.thread != manifest.writing_thread
        {
            continue;
        }
        let proposed = candidate
            .request
            .writes
            .iter()
            .filter_map(|write| match &write.data {
                RecordData::Note(note) => Some((write.id.clone(), note.markdown.clone())),
                _ => None,
            })
            .collect::<Vec<_>>();
        if proposed.len() != 1 {
            continue;
        }
        let (candidate_note_id, markdown) = &proposed[0];
        let changed_only_phrase = manifest
            .note_markdown
            .replace(&manifest.phrase, &manifest.replacement)
            == manifest.original_expected_candidate
            && *markdown == manifest.original_expected_candidate
            && manifest.note_markdown.matches(&manifest.phrase).count() == 1
            && markdown.matches(&manifest.replacement).count() == 1;
        let captured_exactly = evidence.proposed_addressed_comment_ids.is_empty()
            || evidence.proposed_addressed_comment_ids == vec![manifest.comment_id.clone()];
        let comment_in_frozen_inputs = candidate.request.inputs.iter().any(|input| {
            input.record == manifest.comment_id && input.version == manifest.comment_version
        });
        if changed_only_phrase && captured_exactly && comment_in_frozen_inputs {
            matched.push((
                candidate.operation.as_str().to_string(),
                candidate_note_id.clone(),
            ));
        }
    }
    let ops = matched
        .iter()
        .map(|(operation, _)| operation.clone())
        .collect::<Vec<_>>();
    let note_ids = matched
        .iter()
        .map(|(_, note)| note.clone())
        .collect::<Vec<_>>();
    let status = if matched.len() == 1 {
        "one useful frozen-request whole-note proposal"
    } else {
        "no unique useful matching proposal"
    }
    .to_string();
    Ok((ops, note_ids, status))
}

fn validate_reserved_attempt(
    ledger: &Path,
    attempt_id: &str,
    data: &Path,
    binary_hash: &str,
) -> Result<(), String> {
    if !ledger.is_absolute() || !ledger.exists() {
        return Err("attempt ledger path must be an existing absolute file".into());
    }
    let bytes = fs::read(ledger).map_err(|_| "attempt ledger unavailable")?;
    let root: serde_json::Value =
        serde_json::from_slice(&bytes).map_err(|_| "attempt ledger is invalid JSON")?;
    let attempts = root
        .get("attempts")
        .and_then(serde_json::Value::as_array)
        .ok_or("attempt ledger has no attempts array")?;
    let matches = attempts
        .iter()
        .filter(|entry| entry.get("id").and_then(serde_json::Value::as_str) == Some(attempt_id))
        .collect::<Vec<_>>();
    if matches.len() != 1 {
        return Err("attempt ID is missing or duplicated".into());
    }
    let entry = matches[0];
    let session = entry
        .get("session")
        .and_then(serde_json::Value::as_str)
        .ok_or("reserved attempt has no session identity")?;
    let session_attempts = attempts
        .iter()
        .filter(|row| row.get("session").and_then(serde_json::Value::as_str) == Some(session))
        .count();
    let day_attempts = attempts
        .iter()
        .filter(|row| {
            row.get("tallinn_date").and_then(serde_json::Value::as_str) == Some(ATTEMPT_DATE)
        })
        .count();
    if session_attempts > 3
        || day_attempts > 6
        || entry.get("status").and_then(serde_json::Value::as_str) != Some("reserved")
        || entry
            .get("tallinn_date")
            .and_then(serde_json::Value::as_str)
            != Some(ATTEMPT_DATE)
        || !session.starts_with("2026-10-20-")
        || entry.get("provider").and_then(serde_json::Value::as_str)
            != Some("Codex existing account")
        || entry.get("model").and_then(serde_json::Value::as_str) != Some("gpt-6-luna")
        || entry.get("effort").and_then(serde_json::Value::as_str) != Some("low")
        || entry
            .get("tool_round_budget")
            .and_then(serde_json::Value::as_u64)
            != Some(4)
        || entry
            .get("client_deadline_seconds")
            .and_then(serde_json::Value::as_u64)
            != Some(180)
        || entry
            .get("binary_sha256")
            .and_then(serde_json::Value::as_str)
            != Some(binary_hash)
    {
        return Err("attempt is not an exact reserved 20 October Luna/low four-round 180-second harness run".into());
    }
    let bound_data = entry
        .get("data_directory")
        .and_then(serde_json::Value::as_str)
        .ok_or("reserved attempt must bind an exact data_directory")?;
    let bound_path = PathBuf::from(bound_data);
    if !bound_path.is_absolute() {
        return Err("reserved attempt data_directory must be absolute".into());
    }
    let canonical_bound = bound_path
        .canonicalize()
        .map_err(|_| "reserved attempt data_directory cannot be canonicalized")?;
    if canonical_bound != bound_path || canonical_bound != data {
        return Err("reserved attempt data_directory must exactly match DATA".into());
    }
    Ok(())
}

async fn execute_deadlined(
    handle: tokio::task::JoinHandle<brn_ai::AiResult<threads::ThreadResult>>,
    cancel: CancellationToken,
) -> Execution {
    // Keep the async task and its future alive until the hard deadline is reached.
    {
        tokio::pin!(handle);
        match tokio::time::timeout(DEADLINE, &mut handle).await {
            Ok(Ok(Ok(result))) => Execution::Finished(Ok(result)),
            Ok(Ok(Err(error))) => Execution::Finished(Err(error)),
            Ok(Err(_)) => Execution::JoinFailed,
            Err(_) => {
                cancel.cancel();
                match tokio::time::timeout(CANCELLATION_GRACE, &mut handle).await {
                    Ok(Ok(Ok(result))) => {
                        Execution::DeadlineObserved(match result.answer.terminal {
                            AiTerminal::Completed => "Completed".into(),
                            AiTerminal::Interrupted => "Interrupted".into(),
                            AiTerminal::Failed(_) => "Failed".into(),
                        })
                    }
                    Ok(Ok(Err(_))) | Ok(Err(_)) => {
                        Execution::DeadlineObserved("FailedOrInterrupted".into())
                    }
                    Err(_) => Execution::DeadlineUnknown,
                }
            }
        }
    }
}

enum Execution {
    Finished(brn_ai::AiResult<threads::ThreadResult>),
    JoinFailed,
    DeadlineObserved(String),
    DeadlineUnknown,
}

fn validate_new_root(path: &Path) -> Result<PathBuf, String> {
    validate_absolute_shape(path)?;
    let parent = path
        .parent()
        .ok_or("data path must have an existing canonical parent")?;
    let canonical_parent = parent
        .canonicalize()
        .map_err(|_| "data path parent must exist")?;
    if canonical_parent != parent {
        return Err("data path parent must already be canonical".into());
    }
    Ok(path.to_path_buf())
}

fn validate_existing_root(path: &Path) -> Result<PathBuf, String> {
    validate_absolute_shape(path)?;
    let canonical = path
        .canonicalize()
        .map_err(|_| "data directory must already exist")?;
    if canonical != path || !canonical.is_dir() {
        return Err("data directory must be a canonical directory".into());
    }
    Ok(canonical)
}

fn validate_absolute_shape(path: &Path) -> Result<(), String> {
    if !path.is_absolute()
        || path
            .components()
            .any(|component| matches!(component, Component::ParentDir | Component::CurDir))
    {
        return Err("path must be absolute and contain no . or .. components".into());
    }
    Ok(())
}

fn read_manifest(data: &Path) -> Result<Manifest, String> {
    let manifest_path = data.join("manifest.json");
    let metadata =
        fs::symlink_metadata(&manifest_path).map_err(|_| "source-bound manifest unavailable")?;
    if !metadata.file_type().is_file() {
        return Err("source-bound manifest must be a regular file".into());
    }
    let bytes = fs::read(manifest_path).map_err(|_| "source-bound manifest unavailable")?;
    serde_json::from_slice(&bytes).map_err(|_| "source-bound manifest is invalid".to_string())
}

fn write_json_atomic<T: Serialize>(path: &Path, value: &T) -> Result<(), String> {
    let mut temporary = path.to_path_buf();
    temporary.set_extension("json.tmp");
    let bytes = serde_json::to_vec_pretty(value).map_err(|_| "manifest serialization failed")?;
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&temporary)
        .map_err(|_| "temporary evidence file already exists or cannot be created")?;
    file.write_all(&bytes)
        .map_err(|_| "evidence write failed")?;
    file.sync_all().map_err(|_| "evidence sync failed")?;
    fs::rename(&temporary, path).map_err(|_| "atomic evidence publication failed")?;
    Ok(())
}

fn digest_record(record: &Record) -> Result<String, String> {
    let encoded = serde_json::to_vec(record).map_err(|_| "record hash serialization failed")?;
    Ok(digest(&encoded))
}

fn digest(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

fn source_digest() -> String {
    let mut hash = Sha256::new();
    hash.update(include_bytes!("../Cargo.toml"));
    hash.update(include_bytes!("../Cargo.lock"));
    hash.update(include_bytes!("main.rs"));
    format!("{:x}", hash.finalize())
}
