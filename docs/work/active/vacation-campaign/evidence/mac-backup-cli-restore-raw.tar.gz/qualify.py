import pathlib,sqlite3,hashlib,json,subprocess,datetime,base64,os
base=pathlib.Path('/tmp/brn-mac-backup-cli-restore');backup=pathlib.Path('/private/tmp/brn-native-20261020T134854Z/backups/BRN-backup-1439755c-c9ec-4250-87a1-03978b70c875');primary=pathlib.Path('/private/tmp/brn-native-20261020T134854Z/data');dest=pathlib.Path('/private/tmp/brn-native-20261020T134854Z/cli-restored');binary=pathlib.Path('/Users/evokessler/.codex/artifacts/brn-backup-restore/20261020T1546Z/brn')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert backup.is_file() and not backup.is_symlink() and sha(backup)=='111f1d1f904461ff9ee6ea09ab21118de6de60ac8bddae2ec84220c1755d4211';assert not dest.exists()
def snapshot(db):
 c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True);c.execute('PRAGMA query_only=ON');c.execute('BEGIN');assert c.execute('PRAGMA quick_check').fetchall()==[('ok',)]
 def cell(v):return {'blob_b64':base64.b64encode(v).decode()} if isinstance(v,bytes) else v
 rows={}
 for (table,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
  quoted='"'+table.replace('"','""')+'"';rows[table]=sorted([[cell(v) for v in row] for row in c.execute('SELECT * FROM '+quoted)],key=lambda row:json.dumps(row,sort_keys=True))
 result={'user_version':c.execute('PRAGMA user_version').fetchone()[0],'rows':rows};c.rollback();c.close();return result
files=sorted(p for p in primary.iterdir() if p.is_file());original_hashes={str(p):sha(p) for p in files};dbs=[p for p in files if p.suffix=='.sqlite3'];assert len(dbs)==1
before=snapshot(dbs[0]);source=snapshot(backup)
cmd=[str(binary),'--json','--data-dir',str(dest),'restore','--source',str(backup)];r=subprocess.run(cmd,capture_output=True,text=True,timeout=30);(base/'restore.stdout').write_text(r.stdout);(base/'restore.stderr').write_text(r.stderr);assert r.returncode==0,(r.returncode,r.stdout,r.stderr)
restored_db=dest/dbs[0].name;restored=snapshot(restored_db);assert source['user_version']==restored['user_version']==10
assert source['rows'].keys()==restored['rows'].keys();diff={t:{'source':source['rows'][t],'restored':restored['rows'][t]} for t in source['rows'] if source['rows'][t]!=restored['rows'][t]};assert set(diff)<= {'workspace_profile','edit_session_bindings'},diff
assert restored['rows']['workspace_profile']==[[1,'owner',None]];assert not restored['rows']['edit_session_bindings'];assert before==snapshot(dbs[0]);assert original_hashes=={str(p):sha(p) for p in files};assert sha(backup)=='111f1d1f904461ff9ee6ea09ab21118de6de60ac8bddae2ec84220c1755d4211'
for name,value in [('source-snapshot',source),('restored-snapshot',restored),('primary-before',before)]: (base/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exit_code':r.returncode,'source_backup':str(backup),'backup_sha256':sha(backup),'destination':str(dest),'binary':str(binary),'binary_sha256':sha(binary),'binary_mode':oct(binary.stat().st_mode&0o777),'schema':10,'tables':len(source['rows']),'all_table_rows_exact':not diff,'contract_permitted_differences':diff,'primary_all_table_rows_unchanged':True,'primary_file_hashes_unchanged':original_hashes,'source_backup_unchanged':True,'restore_response':json.loads(r.stdout),'limits':'Actual supported CLI restore of Mac-created synthetic backup, not Mac Restore controls, assets absent from this fixture, crash/power-loss, broad backup fidelity or owner acceptance. No account/provider/model action or SQL repair.'};(base/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='primary_file_hashes_unchanged'},indent=2))
