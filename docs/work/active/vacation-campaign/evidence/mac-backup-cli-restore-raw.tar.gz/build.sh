#!/bin/bash
set -euo pipefail
export PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:$PATH
export CARGO_TARGET_DIR=/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export DYLD_LIBRARY_PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib
export BRN_XBERG_HELPER=/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper
export BRN_XBERG_HELPER_BRN=/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper-brn
free=$(df -k "$CARGO_TARGET_DIR" | awk 'NR==2 {print $4}')
((free > 3*1024*1024)) || exit 77
# Rebuild CLI entrypoint/modules from this checkout; unchanged app dependencies were qualified by the matching ordinary desktop builds.
cargo clean -p brn
cargo build -p brn --bin brn --locked --offline --jobs 1
