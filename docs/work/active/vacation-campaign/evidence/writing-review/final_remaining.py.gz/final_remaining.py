import subprocess,sys
checks=[
("qualified-native-clippy",["cargo","clippy","-p","brn-desktop","--features","native-ui,native-test-support","--all-targets","--locked","--offline","--jobs","1","--","-D","warnings"]),
("qualified-writing-ui-clippy",["cargo","clippy","-p","brn-writing-ui","--features","native-ui,native-test-support","--all-targets","--locked","--offline","--jobs","1","--","-D","warnings"]),
("qualified-writing-ui-tests",["cargo","test","-p","brn-writing-ui","--features","native-ui,native-test-support","--locked","--offline","--jobs","1"]),
("qualified-cli-contract",["cargo","test","-p","brn","--test","agent_runs","--test","agent_authority","--test","agent_contract","--locked","--offline","--jobs","1"]),
("qualified-fmt",["cargo","fmt","--all","--","--check"]),
]
for name,command in checks:
 code=subprocess.call([sys.executable,"../writing-review-evidence/run_check.py",name,*command])
 if code: sys.exit(code)
