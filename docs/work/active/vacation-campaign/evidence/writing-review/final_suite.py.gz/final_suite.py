import subprocess,sys
checks=[
("final-app-status",["cargo","test","-p","brn-threads-app","--lib","apply_status_tests","--locked","--offline","--jobs","1"]),
("final-native-clippy",["cargo","clippy","-p","brn-desktop","--features","native-ui,native-test-support","--all-targets","--locked","--offline","--jobs","1","--","-D","warnings"]),
("final-writing-ui-clippy",["cargo","clippy","-p","brn-writing-ui","--features","native-ui,native-test-support","--all-targets","--locked","--offline","--jobs","1","--","-D","warnings"]),
("final-cli-clippy",["cargo","clippy","-p","brn","--all-targets","--locked","--offline","--jobs","1","--","-D","warnings"]),
("final-writing-ui-tests",["cargo","test","-p","brn-writing-ui","--features","native-ui,native-test-support","--locked","--offline","--jobs","1"]),
("final-native-full",["cargo","test","-p","brn-desktop","--features","native-ui,native-test-support","--locked","--offline","--jobs","1"]),
("final-cli-contract",["cargo","test","-p","brn","--test","agent_runs","--test","agent_authority","--test","agent_contract","--locked","--offline","--jobs","1"]),
("final-fmt",["cargo","fmt","--all","--","--check"]),
]
for name,command in checks:
 code=subprocess.call([sys.executable,"../writing-review-evidence/run_check.py",name,*command])
 if code: sys.exit(code)
