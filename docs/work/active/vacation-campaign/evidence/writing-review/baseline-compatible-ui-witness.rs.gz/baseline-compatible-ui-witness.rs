#[gpui_kit::test]
fn review_feedback_selector_and_apply_click_commit_exact_subset_with_undo(cx: &mut TestAppContext) {
    let f = fixture(cx);
    let mut ids = Vec::new();
    let mut operation = String::new();
    cx.update_window(f.window, |_, window, cx| {
        f.view.update(cx, |view, cx| {
            view.open_note(&f.a.id, None, window, cx);
            view.select_writing_thread(f.a.id.clone(), f.chat_a.clone(), window, cx);
            feedback(view, &f.a, "tere", 0..4, "Clarify greeting", window, cx);
            feedback(view, &f.a, "õun", 10..14, "Keep the fruit", window, cx);
            ids = view
                .workspace
                .writing_comments(&f.a.id)
                .unwrap()
                .into_iter()
                .map(|entry| entry.record.id)
                .collect();
            let (_, candidate) = proposal(
                view,
                &f.a,
                &f.chat_a,
                &ids,
                "Exact UI accepted revision",
                "selected-ui",
            );
            operation = candidate.operation.as_str().into();
            view.open_review(candidate, window, cx);
        });
    })
    .unwrap();
    cx.run_until_parked();
    cx.update_window(f.window, |_, window, cx| {
        assert!(window.find("review-feedback").visible());
        assert!(
            window
                .find("note-bar")
                .label()
                .unwrap()
                .contains("stay open")
        );
        window.click(format!("review-address-comment-{}", ids[0]), cx);
    })
    .unwrap();
    cx.run_until_parked();
    cx.update_window(f.window, |_, window, cx| {
        f.view.update(cx, |view, _| {
            assert!(
                view.workspace
                    .store
                    .receipt(&view.workspace.store.operation(&operation).unwrap())
                    .unwrap()
                    .is_none()
            );
        });
        assert!(
            window
                .find("note-bar")
                .label()
                .unwrap()
                .contains("1 captured comment addressed")
        );
        window.click("apply-final", cx);
    })
    .unwrap();
    cx.run_until_parked();
    cx.update_window(f.window, |_, window, cx| {
        f.view.update(cx, |view, cx| {
            assert!(view.writing.review.is_none());
            assert_eq!(view.writing.note_editor.read(cx).value().as_ref(), "Exact UI accepted revision");
            assert!(matches!(view.workspace.store.note(&f.a.id).unwrap().unwrap().data, RecordData::Note(n) if n.markdown == "Exact UI accepted revision"));
            let comments = view.workspace.writing_comments(&f.a.id).unwrap();
            assert!(comments.iter().find(|entry| entry.record.id == ids[0]).unwrap().addressed);
            assert!(!comments.iter().find(|entry| entry.record.id == ids[1]).unwrap().addressed);
            assert_eq!(view.writing.applied_rewrite.get(&f.a.id).unwrap().1, operation);
            assert!(view.workspace.store.note(&f.b.id).unwrap().as_ref() == Some(&f.b));
        });
        window.click("undo-writing-apply", cx);
    }).unwrap();
    cx.run_until_parked();
    cx.update_window(f.window, |_, _, cx| {
        f.view.update(cx, |view, _| {
            assert!(view.workspace.writing_comments(&f.a.id).unwrap().iter().all(|comment| !comment.addressed));
            assert!(matches!(view.workspace.store.note(&f.a.id).unwrap().unwrap().data, RecordData::Note(n) if n.markdown == "tere tere õun"));
        });
    }).unwrap();
}

