import pathlib,sqlite3,hashlib,json,subprocess,datetime,base64
out=pathlib.Path('/tmp/brn-saved-proposal-stale-cli');p=json.loads((out/'preflight.json').read_text());dest=pathlib.Path(p['destination']);db=dest/'threads.sqlite3';note='88d24b7f-a249-4e7d-ab9d-0b5bc1bfe4f6:0';op='7571d9e7-71f7-432f-9d9c-d3fad71589a0';token=dest.parent/'stale-proposal-edit.token';textfile=out/'later-edit.txt';later='Later owner edit · õun\nKeep cobalt boats and this new sentence.';textfile.write_bytes(later.encode());assert not token.exists()
initial=json.loads((out/'operation-before.json').read_text())['result'];assert initial['state']=='prepared' and initial['receipt'] is None
assert json.loads((out/'note-before.json').read_text())['result']['version']==1
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
def call(phase,args,expected=0):
 r=subprocess.run([p['binary'],'--json','--data-dir',str(dest),*args],capture_output=True,text=True,timeout=30);v=json.loads(r.stdout)
 # Token-out must keep authority bytes out of stdout/artifacts.
 if args[0]=='begin-edit':assert v.get('result',{}).get('token') is None
 (out/(phase+'.json')).write_text(json.dumps({'exit_code':r.returncode,'response':v},indent=2)+'\n');assert r.returncode==expected,(phase,r.returncode,v);return v
begin=call('begin',['begin-edit','--note',note,'--base','1','--token-out',str(token)]);session=begin['result']['id'];assert token.stat().st_mode&0o777==0o600
call('update',['update-buffer','--session',session,'--generation','1','--text-file',str(textfile),'--token-file',str(token)])
call('save',['save','--session',session,'--generation','1','--token-file',str(token)])
newnote=call('note-after-save',['read','--id',note])['result'];assert newnote['version']==2 and newnote['data']['Note']['markdown']==later
recovery=call('recovery-after-save',['recovery'])['result'];assert not recovery,recovery

def snapshot():
 c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True);c.execute('PRAGMA query_only=ON');c.execute('BEGIN');assert c.execute('PRAGMA quick_check').fetchall()==[('ok',)];tables={}
 for (name,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
  vals=sorted([json.dumps([{'blob':base64.b64encode(x).decode()} if isinstance(x,bytes) else x for x in row],sort_keys=True) for row in c.execute('SELECT * FROM "'+name.replace('"','""')+'"')]);tables[name]={'rows':len(vals),'sha256':hashlib.sha256('\n'.join(vals).encode()).hexdigest()}
 records=[json.loads(v) for(v,) in c.execute('SELECT body FROM records')];runs=[v for v in records if 'Run' in v.get('data',{})];assert len(runs)==1,(len(runs),list(records[0]));state=runs[0]['data']['Run']['state'];assert state!='Working',state;c.rollback();c.close();return {'tables':tables,'runs':len(runs),'run_state':state}
before=snapshot();result=call('stale-apply',['apply','--operation',op],expected=3);assert result['status']=='stale' and result['outcome']=='Stale',result
after=snapshot();assert before==after
post=call('operation-after',['operation','--id',op])['result'];assert post==initial
final=call('note-final',['read','--id',note])['result'];assert final==newnote
assert p['source_original_hashes']=={s:sha(pathlib.Path(s)) for s in p['source_original_hashes']};assert p['snapshot_sha256']==sha(pathlib.Path(p['snapshot']))
r={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary':p['binary'],'binary_sha256':p['binary_sha256'],'fresh_workspace':str(dest),'operation':op,'prepared_request_hash':initial['request_hash'],'later_note_version':2,'later_note_exact_utf8':later,'later_note_sha256':hashlib.sha256(later.encode()).hexdigest(),'stale_apply_exit':3,'stale_apply_status':result['status'],'conflict':result['conflict'],'all_table_rows_unchanged_after_stale_apply':before,'candidate_operation_unchanged':True,'original_fixture_and_snapshot_unchanged':True,'token_file_mode':'0600; authority bytes never read/logged/archived','no_new_run':True,'limits':'Supported production CLI edit/Save/stale Apply on fresh restored synthetic saved proposal. No fresh AI generation. Does not establish actual Mac conflict controls, live provider cancellation, owner acceptance or unexamined candidate boundaries.'};(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
