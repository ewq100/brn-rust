import json,subprocess,datetime,pathlib,sys
repo='ewq100/brn-rust';pr=int(sys.argv[1]);candidate=sys.argv[2];expected_base=sys.argv[3];output=pathlib.Path(sys.argv[4])
def api(path):return json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/{path}']))
p=api(f'pulls/{pr}');protection=api('branches/main/protection');main=api('commits/main')['sha']
required={'Core and CLI (ubuntu-24.04)','Core and CLI (macos-15)','Native UI build and state (macos-15)','Native retrieval and combined build (macos-15)'}
assert p['state']=='open' and not p['draft'],p['state']
assert p['head']['sha']==candidate,(p['head']['sha'],candidate)
assert p['base']['sha']==main==expected_base,(p['base']['sha'],main,expected_base)
assert protection['enforce_admins']['enabled'] is True
assert protection['required_status_checks']['strict'] is True
assert set(protection['required_status_checks']['contexts'])==required
assert all(c['app_id']==15368 for c in protection['required_status_checks']['checks'])
sets={}
for label,sha in [('head',candidate),('preceding_main',main)]:
 checks=api(f'commits/{sha}/check-runs?per_page=100')['check_runs'];selected={}
 for name in required:
  matches=[c for c in checks if c['name']==name and c['app']['id']==15368]
  assert matches,('missing',label,name)
  c=max(matches,key=lambda c:c['id']);assert c['head_sha']==sha
  selected[name]={k:c[k] for k in ['id','name','head_sha','status','conclusion','started_at','completed_at','html_url']}
  assert c['status']=='completed' and c['conclusion']=='success',(label,name,c['status'],c['conclusion'])
 sets[label]={'sha':sha,'required':selected,'all_checks':[{k:c[k] for k in ['id','name','status','conclusion','html_url']} for c in checks]}
assert p['mergeable'] is True and p['mergeable_state'] in ['clean','unstable'],(p['mergeable'],p['mergeable_state'])
record={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':pr,'candidate':candidate,'base':main,'state':p['state'],'draft':p['draft'],'mergeable':p['mergeable'],'mergeable_state':p['mergeable_state'],'strict':True,'enforce_admins':True,'required_contexts':sorted(required),'sets':sets,'verdict':'PASS before separate normal merge; no admin/bypass/auto/force action','limits':'No resulting-main/native/owner acceptance or release proof'}
output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'verdict':'PASS','pr':pr,'candidate':candidate,'base':main,'required_head':4,'required_preceding_main':4}))
