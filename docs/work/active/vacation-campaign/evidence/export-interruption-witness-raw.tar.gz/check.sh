#!/bin/bash
set -euo pipefail
source /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-export-interruption-qualification/tmp
cd /Users/evokessler/.codex/worktrees/architecture-status-route/brn-rust
test "$(git rev-parse HEAD)" = 7b77eeb42577cce50748487b9bd77a0643c3737a
test -z "$(git status --porcelain)"
cargo test -p brn-threads-app --lib export::tests:: --locked --offline --jobs 1
cargo test -p brn-threads-app --test export_metadata --locked --offline --jobs 1
cargo clippy -p brn-threads-app --all-targets --locked --offline --jobs 1 -- -D warnings
cargo fmt -p brn-threads-app -- --check
git diff --check
