#!/bin/bash
set -euo pipefail
source /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-export-interruption-qualification/tmp
cd /Users/evokessler/.codex/worktrees/architecture-status-route/brn-rust
test "$(git rev-parse --short=8 HEAD)" = 0abb3fa7
test -z "$(git status --porcelain)"
cargo test -p brn-threads-app --lib --locked --offline --jobs 1
cargo test -p brn-threads-app --test export_metadata --locked --offline --jobs 1
cargo clippy -p brn-threads-app --all-targets --locked --offline --jobs 1 -- -D warnings
cargo fmt -p brn-threads-app -- --check
git diff --check
