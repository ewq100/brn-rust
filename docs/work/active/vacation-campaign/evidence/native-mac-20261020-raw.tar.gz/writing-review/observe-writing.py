import datetime,hashlib,json,pathlib,re,sqlite3,sys
ROOT=pathlib.Path('/Users/evokessler/.codex/artifacts/brn-native-session/20261020T134854Z/writing-review');f=json.loads((ROOT/'fixture.json').read_text());phase=sys.argv[1];assert re.fullmatch(r'[a-z0-9-]+',phase)
c=sqlite3.connect((pathlib.Path(f['data_dir'])/'threads.sqlite3').as_uri()+'?mode=ro',uri=True)
try:
 c.execute('PRAGMA query_only=ON');c.execute('BEGIN');records={}
 for name in ['note','sentinel','comment']:
  id=f[name];v,b=c.execute('SELECT version,body FROM records WHERE id=?',(id,)).fetchone();records[name]={'id':id,'version':v,'body_sha256':hashlib.sha256(b.encode()).hexdigest(),'record':json.loads(b)}
 result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':'SQLite mode=ro/query_only/short transaction; no bootstrap/repair','phase':phase,'records':records,'receipt_operations':[x[0] for x in c.execute('SELECT operation FROM receipts ORDER BY operation')],'compensations':[{'id':x[0],'undo_of':x[1]} for x in c.execute('SELECT id,undo_of FROM operations WHERE undo_of IS NOT NULL ORDER BY id')],'run_count':c.execute("SELECT count(*) FROM records WHERE json_type(body,'$.data.Run') IS NOT NULL").fetchone()[0]}
 c.rollback()
finally:c.close()
out=ROOT/(phase+'.json');assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'phase':phase,'records':{k:{'id':v['id'],'version':v['version'],'sha256':v['body_sha256']} for k,v in records.items()},'receipt_count':len(result['receipt_operations']),'compensations':result['compensations'],'run_count':result['run_count']}))
