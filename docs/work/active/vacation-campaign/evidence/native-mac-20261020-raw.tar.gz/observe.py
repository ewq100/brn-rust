"""Task-specific read-only observation; no BRN bootstrap or canonical writes."""
import datetime, hashlib, json, pathlib, re, sqlite3, sys
ROOT = pathlib.Path('/Users/evokessler/.codex/artifacts/brn-native-session/20261020T134854Z')
DATA = pathlib.Path('/private/tmp/brn-native-20261020T134854Z/data')
phase = sys.argv[1]
assert re.fullmatch(r'[a-z0-9-]+', phase)
baseline = json.loads((ROOT/'observations/mac01-preclose.json').read_text())
ids = [n['id'] for n in baseline['notes']]
note_id = next(n['id'] for n in baseline['notes'] if n['version'] == 3)
c = sqlite3.connect((DATA/'threads.sqlite3').as_uri()+'?mode=ro', uri=True)
try:
 c.execute('PRAGMA query_only=ON'); c.execute('BEGIN'); notes=[]
 for id in ids:
  version,body = c.execute('SELECT version,body FROM records WHERE id=?',(id,)).fetchone()
  markdown = json.loads(body)['data']['Note']['markdown']
  sessions=[dict(zip(['id','note','base','generation','markdown','closed'],r)) for r in c.execute('SELECT id,note,base,generation,markdown,closed FROM edit_sessions WHERE note=? AND closed=0 ORDER BY id',(id,))]
  notes.append({'id':id,'version':version,'markdown':markdown,'sha256':hashlib.sha256(markdown.encode()).hexdigest(),'open_sessions':sessions})
 links=[]; threads=[]
 for id,body in c.execute("SELECT id,body FROM records WHERE json_type(body,'$.data.Link') IS NOT NULL AND (json_extract(body,'$.data.Link.from')=? OR json_extract(body,'$.data.Link.to')=?)",(note_id,note_id)):
  record=json.loads(body)
  if record['archived']: continue
  link=record['data']['Link']; other=link['to'] if link['from']==note_id else link['from']; row=c.execute('SELECT body FROM records WHERE id=?',(other,)).fetchone()
  if row and 'Thread' in json.loads(row[0])['data']:
   links.append({'id':id,'from':link['from'],'to':link['to']}); threads.append(other)
 drafts=[]
 for destination,generation,text in c.execute('SELECT destination,generation,text FROM chat_drafts ORDER BY destination'):
  key=json.loads(destination)
  if (isinstance(key,dict) and (key.get('Note',[None])[0]==note_id or key.get('Thread') in threads)):
   drafts.append({'destination':key,'generation':generation,'text':text,'sha256':hashlib.sha256(text.encode()).hexdigest()})
 result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase,'mode':'SQLite URI mode=ro; query_only; one short transaction; no bootstrap/repair','note_id':note_id,'notes':notes,'writing_links':links,'writing_thread_ids':sorted(set(threads)),'chat_drafts':drafts,'canonical_unchanged_from_mac01':all(n['version']==b['version'] and n['markdown']==b['markdown'] for n,b in zip(notes,baseline['notes']))}
 c.rollback()
finally: c.close()
out=ROOT/'observations'/(phase+'.json'); assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
