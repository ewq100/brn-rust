#!/bin/bash
set -euo pipefail
source /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-preview-cancellation-qualification/tmp
mkdir -p "$TMPDIR"
cd /Users/evokessler/.codex/worktrees/export-durability/brn-rust
test "$(git rev-parse HEAD)" = 9e2a81c0e3d5fbc1b617fe54bdb4b103f607b822
test -z "$(git status --porcelain)"
cargo build -p brn --bin brn --locked --offline --jobs 1
