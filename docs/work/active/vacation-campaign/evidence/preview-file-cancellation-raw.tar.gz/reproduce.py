import pathlib,os,subprocess,json,time,sqlite3,hashlib
root=pathlib.Path('/private/tmp/brn-preview-cancellation-qualification/observed-baseline');root.mkdir(mode=0o700)
for name in ['home','tmp']:(root/name).mkdir()
binary='/Users/evokessler/.codex/artifacts/brn-preview-file-cancellation/9e2a81c0/brn';data=root/'data'
env={k:v for k,v in os.environ.items() if not k.startswith('BRN_') and k not in ['CODEX_HOME','HOME']};env.update(HOME=str(root/'home'),CODEX_HOME=str(root/'home'),TMPDIR=str(root/'tmp'))
def call(args,timeout=7):
 t=time.monotonic();r=subprocess.run([binary,'--json','--data-dir',str(data),*args],env=env,text=True,capture_output=True,timeout=timeout);return dict(args=args,exit=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.monotonic()-t)
for args in [['init','--purpose','test'],['note-create','--title','Synthetic cancellation sentinel','--text','Exact Unicode sentinel: café\nsecond line.']]:
 r=call(args);assert r['exit']==0,r

def snapshot():
 with sqlite3.connect('file:'+str(data/'threads.sqlite3')+'?mode=ro',uri=True) as c:
  c.execute('PRAGMA query_only=ON');c.execute('BEGIN');out={}
  for (n,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall():
   rows=c.execute('SELECT * FROM "'+n.replace('"','""')+'"').fetchall();encoded=sorted(repr(row) for row in rows);out[n]={'rows':len(rows),'sha256':hashlib.sha256('\n'.join(encoded).encode()).hexdigest()}
  return out
before=snapshot();fifo=root/'preview.fifo';os.mkfifo(fifo,0o600)
r=call(['--timeout','1','project-delete','--preview-file',str(fifo),'--actions','{}','--key','synthetic-cancel']);after=snapshot();assert before==after,'canonical database mutated'
envelope=json.loads(r['stdout']);assert envelope['error']['code']=='timeout',envelope
record={'source':'9e2a81c0e3d5fbc1b617fe54bdb4b103f607b822','binary_sha256':hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(),'run':r,'all_tables_before':before,'all_tables_after':after,'same_logical_data':before==after,'expected':'soft timeout hard=false at pre-effect input wait','actual':'watchdog hard timeout, state unknown','observed_hard':envelope['error']['details']['hard'],'limits':'FIFO is not assumed invalid; no numeric size policy selected; one synthetic child, no accounts/providers/native.'}
assert record['observed_hard'] is True,'baseline did not reproduce hypothesized hard stop'
pathlib.Path('/tmp/brn-preview-cancellation-qualification/baseline-reproduction.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['all_tables_before','all_tables_after']},indent=2))
