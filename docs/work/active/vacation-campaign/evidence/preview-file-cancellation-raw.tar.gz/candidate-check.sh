#!/bin/bash
set -euo pipefail
source /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-preview-cancellation-qualification/tmp
cd /Users/evokessler/.codex/worktrees/export-durability/brn-rust
test "$(git rev-parse HEAD)" = a054232c8fa5ddf019263823f83753b9a67013f9
test -z "$(git status --porcelain)"
set +e
AGENT_CONTRACT_BASELINE_BIN=/Users/evokessler/.codex/artifacts/brn-preview-file-cancellation/9e2a81c0/brn cargo test -p brn --test agent_bounds timeout_during_preview_fifo_wait_is_a_soft_deadline_without_changes --locked --offline --jobs 1 -- --exact > /tmp/brn-preview-cancellation-qualification/baseline-regression.log 2>&1
red_status=$?
set -e
test "$red_status" -eq 101
python3 - <<'ASSERT'
from pathlib import Path
s=Path('/tmp/brn-preview-cancellation-qualification/baseline-regression.log').read_text()
assert 'test timeout_during_preview_fifo_wait_is_a_soft_deadline_without_changes ... FAILED' in s
assert 'left: Bool(true)' in s and 'right: false' in s
ASSERT
unset AGENT_CONTRACT_BASELINE_BIN
cargo test -p brn --test agent_bounds --locked --offline --jobs 1
cargo test -p brn --test agent_contract --locked --offline --jobs 1
cargo test -p brn --bin brn input::tests:: --locked --offline --jobs 1
cargo clippy -p brn --all-targets --locked --offline --jobs 1 -- -D warnings
cargo fmt -p brn -- --check
git diff --check
