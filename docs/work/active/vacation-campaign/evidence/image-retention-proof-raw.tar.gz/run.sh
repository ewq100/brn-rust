#!/bin/bash
set -euo pipefail
cd /Users/evokessler/.codex/worktrees/export-durability/brn-rust
export PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:$PATH
export DYLD_LIBRARY_PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib
export CARGO_TARGET_DIR=/Users/evokessler/.codex/worktrees/export-durability/brn-rust/tools/xberg-intake-helper/target
export CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_INCREMENTAL=0
export ORT_SKIP_DOWNLOAD=1
export TMPDIR=/private/tmp/brn-image-retention-proof-20261020/tmp
export BRN_TASK1_CAPTURES=/private/tmp/brn-image-retention-proof-20261020/captures
printf 'SOURCE '; git rev-parse HEAD
shasum -a 256 tools/xberg-intake-helper/tests/eight_kinds.rs
cargo test --manifest-path tools/xberg-intake-helper/Cargo.toml --test eight_kinds footnotes_docx_retains_the_inventory_png_when_explicitly_enabled --locked --offline --jobs 1 -- --exact --nocapture
