from __future__ import annotations
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import sys
import tarfile
import threading
import time
import uuid

ROOT = Path('/private/tmp/brn-advisory-audit-20261022')
EXPECTED_ARCHIVE_SHA = 'ec7ca4263769593df4d909be85b94a6b79efa2897be5d2bb8ebd516e823175af'
EXPECTED_HELPER_SHA = 'cd272ff3734a2a46c2a83ff944a9d2f15d768e6bef45de03df49378009854813'
HELPER = Path('/tmp/brn-mac13-preparation/prepare.py')
ARCHIVE = ROOT / 'archive/cargo-audit.tgz'
BINARY = ROOT / 'bin/cargo-audit'
DB = ROOT / 'db/advisory-db'
PKT = ROOT / 'packet'
LOCKS = [
    ('main213-root-lock', Path('/tmp/brn-tls-resolution/Cargo.lock.before')),
    ('worker-export-lock', Path('/Users/evokessler/.codex/worktrees/export-durability/brn-rust/Cargo.lock')),
    ('stock-helper-lock', Path('/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/tools/xberg-intake-helper/Cargo.lock')),
    ('adapted-helper-lock', Path('/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/tools/xberg-intake-helper/adapted.Cargo.lock')),
]
MAX_OUTPUT = 1024 * 1024
OVERALL = 300.0
CLEANUP_RESERVE = 30.0
START_FREE = 2 * 1024**3
LIVE_FREE = 1024**3


def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def sha_file(path):
    h=hashlib.sha256(); n=0
    with path.open('rb') as f:
        while c:=f.read(1024*1024): h.update(c); n+=len(c)
    return h.hexdigest(),n

if sha_file(HELPER)[0] != EXPECTED_HELPER_SHA:
    raise SystemExit('approved process cleanup helper hash mismatch; stopped')
spec=importlib.util.spec_from_file_location('approved_cleanup', HELPER)
helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
stop_and_reap=helper.stop_and_reap

if platform.machine() != 'arm64':
    raise SystemExit(f'expected Apple Silicon arm64 host, observed {platform.machine()!r}')
if not ROOT.is_dir() or not ARCHIVE.is_file() or not BINARY.parent.is_dir():
    raise SystemExit('task-owned workspace not in expected initialized state')
if shutil.disk_usage('/private/tmp').free < START_FREE:
    raise SystemExit('less than 2 GiB free before audit packet')

started=time.monotonic(); deadline=started+OVERALL
manifest={
    'schema':'brn.full-advisory-scan.v1','status':'running','started_at':now(),
    'official_tool':{'release':'rustsec/rustsec cargo-audit/v0.22.2',
      'asset':'cargo-audit-aarch64-apple-darwin-v0.22.2.tgz',
      'asset_sha256_expected':EXPECTED_ARCHIVE_SHA},
    'host_arch':platform.machine(),'task_root':str(ROOT),'commands':[],
    'inputs':[],'database':{},'limits':{'overall_seconds':OVERALL,
      'cleanup_reserve_seconds':CLEANUP_RESERVE,'max_output_bytes_per_command':MAX_OUTPUT,
      'start_free_bytes_min':START_FREE,'live_free_bytes_min':LIVE_FREE,
      'audit_flags':['--no-fetch','--no-yanked','--format','json'],
      'no_ignores':True,'no_target_filter':True,'no_fix_or_suppression':True},
    'notes':['No source/build/global install/provider/account/native action.',
      'Advisory matches are lockfile name/version reports, not reachability/exposure proof.',
      'Yanked status was not checked because --no-yanked avoids registry access.']}
receipt=PKT/'scan-receipt.json'

def persist():
    manifest['elapsed_seconds']=round(time.monotonic()-started,3)
    manifest['free_bytes']=shutil.disk_usage('/private/tmp').free
    tmp=receipt.with_name(receipt.name+'.tmp-'+uuid.uuid4().hex)
    with tmp.open('x',encoding='utf-8') as f:
        json.dump(manifest,f,ensure_ascii=False,indent=2,sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,receipt)


def run(name, argv, cwd, timeout, env, acceptable=(0,)):
    remaining=deadline-time.monotonic()-CLEANUP_RESERVE
    if remaining <= 0 or shutil.disk_usage('/private/tmp').free < LIVE_FREE:
        raise RuntimeError('overall cleanup reserve or live free-space floor reached')
    timeout=min(timeout,remaining)
    outp=PKT/'commands'/f'{len(manifest["commands"])+1:02d}-{name}.stdout'
    errp=PKT/'commands'/f'{len(manifest["commands"])+1:02d}-{name}.stderr'
    outp.parent.mkdir(mode=0o700,exist_ok=True)
    rec={'name':name,'argv':argv,'cwd':str(cwd),'timeout_seconds':round(timeout,3),
         'stdout_path':str(outp),'stderr_path':str(errp),'started_at':now(),
         'max_combined_output_bytes':MAX_OUTPUT}
    manifest['commands'].append(rec); persist()
    proc=None; state={'used':0,'overflow':False,'reader_errors':[]}; lock=threading.Lock(); overflow=threading.Event(); threads=[]; errors=[]; signals=[]; stop_reason=None
    def drain(pipe,path):
        try:
            with path.open('xb') as dest:
                while True:
                    chunk=pipe.read(65536)
                    if not chunk: break
                    with lock:
                        remain=MAX_OUTPUT-state['used']
                        if remain<=0:
                            state['overflow']=True; overflow.set(); break
                        kept=chunk[:remain]; dest.write(kept); state['used']+=len(kept)
                        if len(kept)!=len(chunk):
                            state['overflow']=True; overflow.set(); break
                dest.flush(); os.fsync(dest.fileno())
        except BaseException as exc:
            state['reader_errors'].append(f'{type(exc).__name__}: {exc}'); overflow.set()
        finally:
            try: pipe.close()
            except OSError: pass
    try:
        proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            cwd=str(cwd),env=env,start_new_session=True,close_fds=True)
        threads=[threading.Thread(target=drain,args=(proc.stdout,outp),daemon=True),threading.Thread(target=drain,args=(proc.stderr,errp),daemon=True)]
        for t in threads:t.start()
        cmd_deadline=time.monotonic()+timeout
        while proc.poll() is None:
            if overflow.is_set(): stop_reason='output cap/capture error'; break
            if time.monotonic()>=cmd_deadline: stop_reason='command deadline'; break
            if time.monotonic()>=deadline-CLEANUP_RESERVE: stop_reason='overall cleanup reserve'; break
            if shutil.disk_usage('/private/tmp').free<LIVE_FREE: stop_reason='free disk below 1 GiB'; break
            time.sleep(.05)
        clean=stop_and_reap(proc,signals,errors)
        for t in threads:t.join(timeout=1.0)
        if any(t.is_alive() for t in threads): errors.append('output reader remains alive after child group cleanup')
        rec.update({'return_code':proc.returncode,'group_absent':clean,'leader_reaped':proc.returncode is not None,
          'signals_sent':signals,'cleanup_errors':errors,'output_bytes':state['used'],
          'output_overflow':state['overflow'],'reader_errors':state['reader_errors'],
          'finished_at':now(),'stop_reason':stop_reason})
        if outp.exists(): rec['stdout_sha256']=sha_file(outp)[0]
        if errp.exists(): rec['stderr_sha256']=sha_file(errp)[0]
        persist()
        if stop_reason or not clean or errors or state['overflow'] or state['reader_errors'] or proc.returncode not in acceptable:
            raise RuntimeError(f'{name} stopped/failed; see receipt and raw command files')
        return proc.returncode,outp.read_bytes(),errp.read_bytes()
    except BaseException:
        if proc is not None:
            clean=stop_and_reap(proc,signals,errors)
            rec.update({'return_code':proc.returncode,'group_absent':clean,'leader_reaped':proc.returncode is not None,
              'signals_sent':signals,'cleanup_errors':errors,'finished_at':now()})
        try: persist()
        except BaseException: pass
        raise


status='failed'; failure=None
try:
    digest,size=sha_file(ARCHIVE)
    manifest['archive']={'path':str(ARCHIVE),'bytes':size,'sha256':digest,'verified':digest==EXPECTED_ARCHIVE_SHA}
    persist()
    if digest!=EXPECTED_ARCHIVE_SHA: raise RuntimeError('official archive SHA-256 mismatch; stopped before extraction')
    expected_prefix='cargo-audit-aarch64-apple-darwin-v0.22.2/'
    with tarfile.open(ARCHIVE,'r:gz') as tf:
        members=tf.getmembers()
        expected_names={expected_prefix,expected_prefix+'LICENSE-APACHE',expected_prefix+'CHANGELOG.md',expected_prefix+'README.md',expected_prefix+'cargo-audit',expected_prefix+'LICENSE-MIT'}
        if {m.name for m in members} != expected_names: raise RuntimeError('unexpected archive member set; stopped')
        if any(not (m.isdir() or m.isfile()) or m.issym() or m.islnk() for m in members): raise RuntimeError('archive link/special member rejected')
        binary_member=next(m for m in members if m.name==expected_prefix+'cargo-audit')
        if not binary_member.isfile() or binary_member.size>100*1024*1024: raise RuntimeError('unexpected binary member')
        with tf.extractfile(binary_member) as src, BINARY.open('xb') as dst:
            shutil.copyfileobj(src,dst,1024*1024); dst.flush(); os.fsync(dst.fileno())
    BINARY.chmod(0o700)
    manifest['binary']={'path':str(BINARY),'sha256':sha_file(BINARY)[0],'bytes':sha_file(BINARY)[1]}; persist()

    env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','LANG':'C','LC_ALL':'C','TMPDIR':str(ROOT/'tmp')}
    # Keep audit's Cargo state under this task root; HOME and CODEX_HOME remain inherited/unchanged.
    env['CARGO_HOME']=str(ROOT/'cargo-home')
    (ROOT/'tmp').mkdir(mode=0o700,exist_ok=True)
    vrc,vout,verr=run('tool-version',[str(BINARY),'--version'],ROOT,15,env)
    manifest['tool_version']={'exit':vrc,'stdout':vout.decode('utf-8','strict').strip(),'stderr':verr.decode('utf-8','strict').strip()}; persist()
    hrc,hout,herr=run('audit-help',[str(BINARY),'audit','--help'],ROOT,15,env)
    helptext=hout.decode('utf-8','strict')
    required=['--file','--db','--no-fetch','--no-yanked','--format']
    missing=[x for x in required if x not in helptext]
    manifest['tool_help']={'exit':hrc,'required_options_present':not missing,'missing_options':missing,'stdout_sha256':sha(hout),'stderr_sha256':sha(herr)}; persist()
    if missing: raise RuntimeError('required CLI flags absent from official binary help; stopped')

    lockdir=PKT/'locks'; lockdir.mkdir(mode=0o700)
    input_initial=[]
    for label,src in LOCKS:
        raw=src.read_bytes(); h=sha(raw); dest=lockdir/f'{label}.Cargo.lock'
        with dest.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        entry={'label':label,'source':str(src),'snapshot':str(dest),'bytes':len(raw),'sha256':h}
        manifest['inputs'].append(entry); input_initial.append((src,h)); persist()
    if len({e['sha256'] for e in manifest['inputs']}) != 4:
        manifest['notes'].append('The four lock snapshots have distinct hashes; kept as separate audit inputs.')

    # Clone only the official RustSec DB into fresh task-owned storage.
    git='/usr/bin/git'
    git_env=dict(env,GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull,GIT_TERMINAL_PROMPT='0',GIT_PAGER='cat',PAGER='cat')
    clone_argv=[git,'-c','protocol.file.allow=never','clone','--depth','1','--branch','main','https://github.com/RustSec/advisory-db.git',str(DB)]
    crc,cout,cerr=run('clone-official-advisory-db',clone_argv,ROOT,120,git_env)
    manifest['database']['clone_stdout_sha256']=sha(cout);manifest['database']['clone_stderr_sha256']=sha(cerr);persist()
    for name,args in [('db-head',['rev-parse','HEAD']),('db-commit-date',['show','-s','--format=%cI','HEAD']),('db-status',['status','--porcelain'])]:
        rc,out,err=run(name,[git,'--no-pager','--no-optional-locks','-C',str(DB),*args],ROOT,10,git_env)
        manifest['database'][name]=out.decode('utf-8','strict').strip();persist()
    if manifest['database']['db-status']:
        raise RuntimeError('freshly cloned advisory DB is unexpectedly dirty')
    manifest['database'].update({'url':'https://github.com/RustSec/advisory-db.git','clone_depth':1,'branch':'main','no_fetch_during_audit':True})
    persist()

    for entry in manifest['inputs']:
        scan_name='audit-'+entry['label']
        argv=[str(BINARY),'audit','--file',entry['snapshot'],'--db',str(DB),'--no-fetch','--no-yanked','--format','json']
        # Exit 1 is an advisory finding; retain it and continue the remaining independent lock scans.
        rc,out,err=run(scan_name,argv,ROOT,60,env,acceptable=(0,1))
        try:
            parsed=json.loads(out.decode('utf-8','strict'))
            (PKT/'commands'/f'{scan_name}.parsed.json').write_text(json.dumps(parsed,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
            finding_count=len(parsed.get('vulnerabilities',{}).get('list',[])) if isinstance(parsed,dict) else None
            warnings=parsed.get('warnings',{}) if isinstance(parsed,dict) else None
        except (UnicodeDecodeError,json.JSONDecodeError,AttributeError,TypeError):
            parsed=None;finding_count=None;warnings=None
        manifest['commands'][-1].update({'input_label':entry['label'],'input_sha256':entry['sha256'],
           'json_parsed':parsed is not None,'vulnerability_count':finding_count,'warnings_summary':warnings,
           'exit_interpretation':'advisory findings' if rc==1 else 'no vulnerability exit status'})
        persist()

    changed=[]
    for src,h in input_initial:
        if sha_file(src)[0]!=h: changed.append(str(src))
    manifest['postchecks']={'source_locks_unchanged':not changed,'changed_lock_paths':changed}
    # Record the shared cache HEAD before/after without changing it.
    shared=Path('/Users/evokessler/.cargo/advisory-db')
    rc,out,err=run('shared-db-head-after',[git,'--no-pager','--no-optional-locks','-C',str(shared),'rev-parse','HEAD'],ROOT,10,git_env)
    manifest['postchecks']['shared_advisory_db_head_after']=out.decode('utf-8','strict').strip()
    manifest['postchecks']['shared_advisory_db_expected_head']='7eebec69c352c7191b1f13eb95dd510eeca5d1de'
    manifest['postchecks']['shared_advisory_db_unchanged_head']=manifest['postchecks']['shared_advisory_db_head_after']==manifest['postchecks']['shared_advisory_db_expected_head']
    if changed or not manifest['postchecks']['shared_advisory_db_unchanged_head']:
        raise RuntimeError('post-scan immutability verification failed')
    status='complete'
except BaseException as exc:
    failure=f'{type(exc).__name__}: {exc}'
finally:
    manifest['status']=status;manifest['finished_at']=now();manifest['failure']=failure
    try:persist()
    except BaseException as exc:
        print(f'RECEIPT_WRITE_FAILURE {type(exc).__name__}',file=sys.stderr)
        raise
print(json.dumps({'status':status,'failure':failure,'receipt':str(receipt)},ensure_ascii=False))
if status!='complete': raise SystemExit(2)
