#!/bin/bash
set -euo pipefail
source /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-settings-draft-isolation-qualification/tmp
cd /Users/evokessler/.codex/worktrees/mac-test-roots/brn-rust
test "$(git rev-parse HEAD)" = 7462f0a04b5e195a4618cdd27af2a4fe7281c293
test -z "$(git status --porcelain)"
cargo test -p brn-desktop --features native-ui,native-test-support --bin brn-desktop threads_ui::pages_tests::copilot_connection_does_not_save_an_unsaved_effort_choice --locked --offline --jobs 1 -- --exact --nocapture
