# Synthetic comparison

This report uses a generated fixture, not owner or public data.
Metric: total cost divided by completed units, rounded half-up to cents.

| Alternative | Cost per completed unit |
|---|---:|
| Plan A | $3.00 |
| Plan B | $2.50 |
| Plan C | $3.00 |

Plan B has the lowest calculated cost per completed unit in this fixture.
