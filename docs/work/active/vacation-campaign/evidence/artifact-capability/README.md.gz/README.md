# Disposable M5 calculation and chart proof

This one-shot local proof uses only a generated three-row CSV. It calculates
cost per completed unit with `Decimal`, checks results against values fixed
independently in the proof source, renders an SVG chart with the already
installed ReportLab chart primitives, and writes a short Markdown report. It
does not call a model, provider, MCP endpoint, BRN service, network, or canonical
store. It does not use owner or public data.

The fixture is `synthetic_comparison.csv` (93 bytes). Expected values were set
before running the pipeline: Plan A $3.00, Plan B $2.50, Plan C $3.00. The
validation checks the SVG XML root, 640x360 dimensions, all category labels and
calculated labels; it checks the report table and conclusion against the same
independently fixed values. The successful artifacts are in `artifacts-final/`
and the machine-readable receipt is `run-receipt-final.json`.

## Reproduction

The proof intentionally refuses to overwrite an existing output directory. To
reproduce from a fresh copy while preserving this run's artifacts, copy only
the source and fixture into a newly created temporary directory:

```sh
proof_dir="$(mktemp -d /tmp/brn-m5-proof.XXXXXX)"
cp /Users/evokessler/.codex/worktrees/vacation-hardening/artifact-capability-proof/proof.py "$proof_dir/"
cp /Users/evokessler/.codex/worktrees/vacation-hardening/artifact-capability-proof/synthetic_comparison.csv "$proof_dir/"
cd "$proof_dir"
/Users/evokessler/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 proof.py
```

The output directory must not already exist. The proof enforces a 16 KiB input
limit, exactly three data rows, a fresh output directory directly under this
scratch folder, and a combined 2 MiB output limit. It validates the finished
SVG and report before producing a PASS receipt. A separate synthetic child
process sleeps; the wrapper times out at 0.4 seconds, sends terminate, waits up
to two seconds, and confirms the process is reaped. Its observed exit code was
`-15` and elapsed time was `0.402` seconds. This cancellation witness uses a
separate synthetic sleep child; it does not demonstrate cancellation or resource
containment for the calculation/chart pipeline itself.

The documented fresh-copy command was also run successfully in
`/private/tmp/brn-m5-proof.RNZztq`. The copied proof and CSV produced the same
chart and report bytes as the original run; both files compared byte-for-byte.
That run's receipt is preserved as `fresh-copy-reproduction-receipt.json`
(SHA-256 `21c21760847887c8fe36387e17c24ffa5d578cdf42e00d6995007aa31f7e0f6f`).

## Recorded environment and artifacts

- Python: 3.12.14, from the configured bundled runtime.
- ReportLab: 4.4.9; package metadata reports BSD license (see its included
  `license.txt`). Its SVG backend rendered successfully; PNG rendering was not
  attempted because SVG met this disposable proof's chart output.
- ReportLab declares Pillow and charset-normalizer as base dependencies; the
  proof imports neither directly. Versions and installed license metadata are
  recorded in `dependency-inventory.txt`.
- Input SHA-256: `709af791ef1eb54e1351d502da85a6002f59366097aee060eae76542ed9e038c`.
- Source SHA-256 (`proof.py`):
  `de90531507ccf7dea94c006d137a94f76bc09c7efb4610c2845c57638314e405`.
- Chart SHA-256: `c584614bf007aa38f468c535baa751527848836f2f3fd1b79c594dcc6385f295`.
- Report SHA-256: `a51f200730c39525d22ba55342bcf670bef504a0b4726d917de1518a73c77610`.
- The final run receipt records byte sizes, hashes, values, package/license,
  limits and cancellation observation. `proof.py` is the complete calculation,
  rendering, validation and wrapper source.

## Limits of this evidence

This proves one reusable calculation-and-artifact route exists in the current
bundled Python environment. The subprocess timeout is only a cooperative local
process-lifecycle witness. It does not establish filesystem or network
containment, memory/CPU limits, hostile-input resistance, a sandbox, concurrent
process safety, or cross-platform behavior. No PNG/backend compatibility was
qualified. BRN's existing managed image assets accept PNG, JPEG and WebP; this
proof emits SVG, so a production route would still need an approved and
validated conversion path or an explicit SVG asset contract.

No BRN adapter or agent invocation was built or tested. In particular, there is
no production permission here to launch a process or grant it file access.
Production activation would need an owner-approved exact tool/process, scratch
scope, cancellation/resource/output limits, and a reviewable candidate flow
that leaves canonical SQLite untouched until existing acceptance. This proof
does not establish model usefulness, BRN adoption, native usability, or owner
acceptance.
