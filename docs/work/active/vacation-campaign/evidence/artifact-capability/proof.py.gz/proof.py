#!/usr/bin/env python3
"""One bounded synthetic calculation + SVG/report artifact proof.

The process accepts only a fixed local input path and a fresh output directory.
It has no BRN, provider, network, or canonical-store integration.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from decimal import Decimal, ROUND_HALF_UP

from reportlab.graphics import renderSVG
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Drawing, String

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "synthetic_comparison.csv"
EXPECTED = {"Plan A": Decimal("3.00"), "Plan B": Decimal("2.50"), "Plan C": Decimal("3.00")}
MAX_INPUT = 16 * 1024
MAX_OUTPUT = 2 * 1024 * 1024
MAX_ROWS = 3


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_table() -> list[tuple[str, Decimal]]:
    raw = INPUT.read_bytes()
    if len(raw) > MAX_INPUT:
        raise ValueError("input exceeds 16 KiB")
    rows = list(csv.DictReader(raw.decode("utf-8").splitlines()))
    if len(rows) != MAX_ROWS or set(rows[0]) != {"alternative", "total_cost_usd", "completed_units"}:
        raise ValueError("unexpected table shape")
    out = []
    for row in rows:
        label = row["alternative"]
        if label not in EXPECTED or not row["completed_units"].isdigit():
            raise ValueError("unexpected row")
        cost = Decimal(row["total_cost_usd"])
        units = Decimal(row["completed_units"])
        if cost <= 0 or units <= 0:
            raise ValueError("cost and units must be positive")
        out.append((label, (cost / units).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)))
    if dict(out) != EXPECTED:
        raise ValueError("independently fixed expected values did not match")
    return out


def render_chart(values: list[tuple[str, Decimal]], path: Path) -> None:
    width, height = 640, 360
    drawing = Drawing(width, height)
    drawing.add(String(320, 328, "Synthetic cost per completed unit", textAnchor="middle", fontSize=15))
    chart = VerticalBarChart()
    chart.x, chart.y, chart.width, chart.height = 72, 70, 520, 230
    chart.data = [[float(value) for _, value in values]]
    chart.categoryAxis.categoryNames = [label for label, _ in values]
    chart.categoryAxis.labels.fontSize = 10
    chart.valueAxis.valueMin = 0
    chart.valueAxis.valueMax = 3.5
    chart.valueAxis.valueStep = 0.5
    chart.valueAxis.labelTextFormat = "$%.2f"
    chart.bars[0].fillColor = None
    from reportlab.lib import colors
    chart.bars[0].fillColor = colors.HexColor("#3973ac")
    drawing.add(chart)
    for index, (_, value) in enumerate(values):
        x = chart.x + chart.width * (index + 0.5) / len(values)
        y = chart.y + chart.height * float(value) / chart.valueAxis.valueMax + 8
        drawing.add(String(x, y, f"${value:.2f}", textAnchor="middle", fontSize=10))
    renderSVG.drawToFile(drawing, str(path))


def validate_svg(path: Path) -> None:
    raw = path.read_bytes()
    if not raw or len(raw) > MAX_OUTPUT:
        raise ValueError("SVG size outside 1..2 MiB")
    root = ET.fromstring(raw)
    if not root.tag.endswith("svg") or root.attrib.get("width") != "640" or root.attrib.get("height") != "360":
        raise ValueError("SVG root or dimensions invalid")
    text = " ".join(node.text or "" for node in root.iter() if node.tag.endswith("text"))
    for label in EXPECTED:
        if label not in text:
            raise ValueError(f"SVG missing category {label}")
    for value in EXPECTED.values():
        if f"${value:.2f}" not in text:
            raise ValueError(f"SVG missing calculated label ${value:.2f}")


def write_report(values: list[tuple[str, Decimal]], path: Path) -> None:
    lines = [
        "# Synthetic comparison",
        "",
        "This report uses a generated fixture, not owner or public data.",
        "Metric: total cost divided by completed units, rounded half-up to cents.",
        "",
        "| Alternative | Cost per completed unit |",
        "|---|---:|",
    ]
    lines.extend(f"| {label} | ${value:.2f} |" for label, value in values)
    lines += ["", "Plan B has the lowest calculated cost per completed unit in this fixture.", ""]
    path.write_text("\n".join(lines), encoding="utf-8")


def validate_report(path: Path, values: list[tuple[str, Decimal]]) -> None:
    text = path.read_text(encoding="utf-8")
    if len(text.encode("utf-8")) > MAX_OUTPUT:
        raise ValueError("report exceeds 2 MiB")
    for label, value in values:
        if f"| {label} | ${value:.2f} |" not in text:
            raise ValueError("report table does not match calculated values")
    if "Plan B has the lowest" not in text:
        raise ValueError("report conclusion missing")


def run_proof(out_dir: Path) -> dict:
    if not out_dir.is_absolute() or out_dir.exists():
        raise ValueError("output must be a fresh absolute directory")
    if out_dir.parent.resolve() != ROOT.resolve():
        raise ValueError("output must be directly inside the declared scratch folder")
    out_dir.mkdir()
    values = read_table()
    chart = out_dir / "comparison.svg"
    report = out_dir / "report.md"
    render_chart(values, chart)
    write_report(values, report)
    validate_svg(chart)
    validate_report(report, values)
    if chart.stat().st_size + report.stat().st_size > MAX_OUTPUT:
        raise ValueError("combined outputs exceed 2 MiB")
    return {
        "status": "PASS",
        "values": {label: f"{value:.2f}" for label, value in values},
        "input": {"path": INPUT.name, "bytes": INPUT.stat().st_size, "sha256": digest(INPUT)},
        "source": {"path": Path(__file__).name, "sha256": digest(Path(__file__).resolve())},
        "outputs": [
            {"path": p.name, "bytes": p.stat().st_size, "sha256": digest(p), "validated": True}
            for p in (chart, report)
        ],
    }


def cancellation_witness() -> dict:
    child = [sys.executable, str(Path(__file__).resolve()), "sleep-child"]
    proc = subprocess.Popen(child, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    started = time.monotonic()
    try:
        proc.wait(timeout=0.4)
        raise RuntimeError("sleep child unexpectedly exited")
    except subprocess.TimeoutExpired:
        proc.terminate()
    try:
        proc.wait(timeout=2.0)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=1.0)
        raise RuntimeError("cancel escalation failed to reap child")
    return {"timeout_seconds": 0.4, "termination": "terminate", "exit_code": proc.returncode, "elapsed_seconds": round(time.monotonic() - started, 3), "reaped": proc.poll() is not None}


def main() -> None:
    if sys.argv[1:] == ["sleep-child"]:
        time.sleep(30)
        return
    out = ROOT / "artifacts-final"
    cancellation = cancellation_witness()
    result = run_proof(out)
    result["cancellation"] = cancellation
    result["runtime"] = {"python": sys.version.split()[0], "reportlab": metadata.version("reportlab"), "reportlab_license": metadata.metadata("reportlab").get("License")}
    result["limits"] = {"input_bytes": MAX_INPUT, "rows": MAX_ROWS, "combined_output_bytes": MAX_OUTPUT, "output_directory": str(out)}
    (ROOT / "run-receipt-final.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
