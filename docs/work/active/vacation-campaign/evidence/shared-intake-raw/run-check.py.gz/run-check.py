from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,signal,sys
repo=Path('/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust');out=repo.parent/'shared-intake-evidence'
name=sys.argv[1];expected=int(sys.argv[2]);args=sys.argv[3:];assert args
source=repo/'crates/brn-writing-ui/src/writing.rs';before=source.read_bytes();fixture=repo/'crates/brn-threads-app/examples/native_review_groups_fixture.rs';fixture_before=fixture.read_bytes();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert shutil.disk_usage(repo).free>=2*1024**3,'require2GiB for this cached graph check'
env={k:v for k,v in os.environ.items() if not k.startswith('BRN_') or k.startswith('BRN_DWR_SHARED_')};env.update(PATH='/opt/homebrew/opt/rustup/bin:'+env.get('PATH',''),RUSTUP_TOOLCHAIN='1.98.1',CARGO_TARGET_DIR=str(repo/'target'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='1',TMPDIR=str(Path(os.environ['TMPDIR']).resolve()),DYLD_LIBRARY_PATH='/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib',BRN_XBERG_HELPER='/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper',BRN_XBERG_HELPER_BRN='/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper-brn')
(out/(name+'-source.rs')).write_bytes(before);(out/(name+'-fixture.rs')).write_bytes(fixture_before);start=time.monotonic();lowest=shutil.disk_usage(repo).free;stopped=None
with (out/(name+'.log')).open('wb') as log:
 p=subprocess.Popen(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  free=shutil.disk_usage(repo).free;lowest=min(lowest,free)
  if free<1024**3 or time.monotonic()-start>900:
   stopped='disk below1GiB' if free<1024**3 else '900s bound';os.killpg(p.pid,signal.SIGINT)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(1)
 code=p.wait()
assert source.read_bytes()==before and fixture.read_bytes()==fixture_before,'source changed while checking'
r={'name':name,'head':head,'source_sha256':hashlib.sha256(before).hexdigest(),'fixture_sha256':hashlib.sha256(fixture_before).hexdigest(),'command':args,'exit':code,'expected_exit':expected,'elapsed_seconds':time.monotonic()-start,'preflight_headroom_bytes':2*1024**3,'headroom_basis':'Existing cached native dependency graph and pinned artifacts; one UI metadata change and a developer-only fixture. Live1GiB stop guard retained.','lowest_free_bytes':lowest,'stopped':stopped,'environment':{k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','RUST_TEST_THREADS','TMPDIR','DYLD_LIBRARY_PATH','BRN_XBERG_HELPER','BRN_XBERG_HELPER_BRN','BRN_DWR_SHARED_DATA','BRN_DWR_SHARED_SOURCE','BRN_DWR_SHARED_CHAT'] if k in env}}
(out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
assert code==expected and stopped is None,'unexpected result'
if name=='baseline':
 text=(out/(name+'.log')).read_text();assert 'assertion `left == right` failed' in text and '1 failed' in text and 'truncated' in text,'not a distinguishing behavior failure'
