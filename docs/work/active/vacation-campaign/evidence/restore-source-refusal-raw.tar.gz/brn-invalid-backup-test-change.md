# Invalid backup refusal tests-only change

Branch `codex/restore-source-refusal`, baseline `a23f486b109c67e8d07c77800030e527b9a18002`.

Changed only the assigned test areas:

- `crates/brn-threads-core/src/restore.rs`: strengthened the existing corrupt/unsupported/foreign/empty source loop to require `Error::UnsafeDirectory`, while retaining source-byte preservation and absent target-parent assertions. Missing-source behavior remains a generic error assertion.
- `crates/brn/tests/agent_contract.rs`: extended the existing rejected-path contract test with a fresh literal non-SQLite source and nested absent restore target. It requires exit 6, `rejected`/`unsafe_directory`, `retry: refuse`, a message mentioning `BRN backup`, unchanged source bytes, and no target parent or restore stage.

No production code changed. No build or test execution was performed, per assignment; the lead is expected to run the focused red before implementation. `git diff --check` passed.
