#!/bin/zsh
set -eu
export PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:$PATH
export DYLD_LIBRARY_PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib
export CARGO_TARGET_DIR=/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target
export CARGO_BUILD_JOBS=1
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_INCREMENTAL=0
export BRN_XBERG_HELPER=$CARGO_TARGET_DIR/debug/brn-xberg-helper
export BRN_XBERG_HELPER_BRN=$CARGO_TARGET_DIR/debug/brn-xberg-helper-brn
task_temp_root=$(mktemp -d /private/tmp/brn-restore-refusal-checks.XXXXXX)
export TMPDIR=$task_temp_root
export TMP=$task_temp_root
export TEMP=$task_temp_root
printf 'Synthetic test root: %s\n' "$task_temp_root"
cargo fmt -p brn-threads-core -p brn --check
cargo test -p brn-threads-core --locked --offline --jobs 1
cargo test -p brn --test agent_contract --locked --offline --jobs 1
cargo clippy -p brn-threads-core -p brn --all-targets --locked --offline --jobs 1 -- -D warnings
