#!/bin/bash
set -euo pipefail
source /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-settings-draft-isolation-qualification/tmp
cd /Users/evokessler/.codex/worktrees/mac-test-roots/brn-rust
test "$(git rev-parse HEAD)" = 29a02b4f52506001bc79be69a2c1c78ae7a210d4
test -z "$(git status --porcelain)"
cargo test -p brn-desktop --features native-ui,native-test-support --bin brn-desktop threads_ui::pages_tests::the_helper_section_shows_its_tested_note_and_saves_with_settings --locked --offline --jobs 1 -- --exact --nocapture
