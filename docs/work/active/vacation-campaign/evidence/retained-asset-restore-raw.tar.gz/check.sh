#!/bin/zsh
set -eu
export PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:$PATH
export DYLD_LIBRARY_PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib
export CARGO_TARGET_DIR=/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target
export CARGO_BUILD_JOBS=1
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_INCREMENTAL=0
cargo fmt -p brn-threads-app --check
cargo test -p brn-threads-app --test chat retained_attachment_is_private_after_restart_then_keep_and_undo_change_same_note --locked --offline --jobs 1 -- --exact
cargo clippy -p brn-threads-app --test chat --locked --offline --jobs 1 -- -D warnings
