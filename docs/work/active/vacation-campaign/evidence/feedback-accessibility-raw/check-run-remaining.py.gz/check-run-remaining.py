from pathlib import Path
import subprocess,sys,json
out=Path(__file__).parent
r=json.loads((out/'selector-resumed.json').read_text());assert r['exit']==0 and not r['stopped']
assert '1 passed; 0 failed' in (out/'selector-resumed.log').read_text()
commands=[('lint',['cargo','clippy','--locked','--offline','-j','1','-p','brn-writing-ui','-p','brn-desktop','--all-targets','--features','brn-desktop/native-ui,brn-desktop/native-test-support','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check']),('production',['cargo','build','--locked','--offline','-j','1','-p','brn-desktop','--features','native-ui'])]
for name,args in commands:
 subprocess.run([sys.executable,str(out/'run-check.py'),name,'0',*args],check=True)
print('Selected native semantics, strict affected lint, format and ordinary native build passed.')
