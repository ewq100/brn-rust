import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {stripTypeScriptTypes} from 'node:module';
const base='/tmp/brn-helper-cache-proof';
const source=fs.readFileSync('/tmp/brn-rust-cache-pinned/src/cleanup.ts','utf8');
// Preserve cleaner bodies; adapt only imports to isolated built-ins/stubs.
const adapted=source.replace(/^import .*;\n/gm,'');
const prelude=`import fs from 'node:fs'; import path from 'node:path'; const core={debug(){}}; const CARGO_HOME='/unused'; const exists=async p=>fs.existsSync(p); const io={rmRF:async p=>{if(!p.startsWith('${base}/fixture/'))throw Error('outside fixture');await fs.promises.rm(p,{recursive:true,force:true})}};\n`;
const mod=stripTypeScriptTypes(prelude+adapted,{mode:'strip'});
fs.writeFileSync(path.join(base,'cleaner-isolated.mjs'),mod);
const {cleanTargetDir}=await import('./cleaner-isolated.mjs');
const rootMeta=JSON.parse(fs.readFileSync(path.join(base,'root-metadata.json')));
const helperMeta=JSON.parse(fs.readFileSync(path.join(base,'helper-metadata.json')));
const kinds=new Set(['lib','cdylib','dylib','rlib','staticlib','proc-macro']);
const packages=m=>m.packages.filter(p=>!p.manifest_path.startsWith(m.workspace_root)).map(p=>({name:p.name,version:p.version,targets:p.targets.filter(t=>t.kind.some(k=>kinds.has(k))).map(t=>t.name),path:path.dirname(p.manifest_path)}));
const rootPackages=packages(rootMeta),helperPackages=packages(helperMeta),rootNames=new Set(rootPackages.map(p=>p.name));
const exclusive=helperPackages.find(p=>!rootNames.has(p.name)&&p.targets.length);assert(exclusive);
const name=exclusive.targets[0].replaceAll('-','_');
const dep=`lib${name}-abc.rlib`;
const fixture=path.join(base,'fixture'); fs.mkdirSync(fixture); // no overwrite of a previous experiment
const touch=(p)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,'synthetic\n')};
function populate(target){for(const sub of ['deps','build','.fingerprint'])fs.mkdirSync(path.join(target,'debug',sub),{recursive:true});touch(path.join(target,'debug','deps',dep));touch(path.join(target,'debug','brn-xberg-helper'));touch(path.join(target,'debug','deps','brn_xberg_helper-abc'));touch(path.join(target,'debug','.fingerprint',exclusive.name+'-abc','lib.json'));touch(path.join(target,'debug','build',exclusive.name+'-abc','output'));}
const nested=path.join(fixture,'old','target','document-helpers','stock');populate(nested);
await cleanTargetDir(path.join(fixture,'old','target'),rootPackages);
assert(!fs.existsSync(path.join(nested,'debug','deps',dep)),'rejected nesting must expose lost exclusive dependency');
const repo=path.join(fixture,'new'),target=path.join(repo,'target'),helpers=path.join(repo,'.brn-ci-document-helpers');
fs.mkdirSync(target,{recursive:true});
for(const mode of ['stock','adapted'])populate(path.join(helpers,mode));
for(const file of ['artifacts/brn-xberg-helper','receipts/run.log','stock-root.txt','adapted-root.txt'])touch(path.join(helpers,file));
touch(path.join(target,'xberg-adapted','source-manifest.json'));
await cleanTargetDir(target,rootPackages);
for(const mode of ['stock','adapted'])await cleanTargetDir(path.join(helpers,mode),helperPackages);
const cachePaths=[target,path.join(helpers,'stock'),path.join(helpers,'adapted')];
assert(cachePaths.every((a,i)=>cachePaths.every((b,j)=>i===j||!b.startsWith(a+path.sep))));
const excluded=['artifacts/brn-xberg-helper','receipts/run.log','stock-root.txt','adapted-root.txt'].map(f=>path.join(helpers,f));
for(const file of excluded){assert(fs.existsSync(file));assert(!cachePaths.some(p=>file.startsWith(p+path.sep)));}
for(const mode of ['stock','adapted']){const p=path.join(helpers,mode,'debug');assert(fs.existsSync(path.join(p,'deps',dep)));assert(fs.existsSync(path.join(p,'.fingerprint',exclusive.name+'-abc','lib.json')));assert(fs.existsSync(path.join(p,'build',exclusive.name+'-abc','output')));assert(!fs.existsSync(path.join(p,'brn-xberg-helper')));assert(!fs.existsSync(path.join(p,'deps','brn_xberg_helper-abc')));}
assert(!fs.existsSync(path.join(target,'xberg-adapted','source-manifest.json')));
const result={observed_at:new Date().toISOString(),source:'Swatinem/rust-cache@6323deb102c322ba6fcbdcafc7e3dddab59af2b6',cleanup_sha256:crypto.createHash('sha256').update(source).digest('hex'),adaptation:'Only imports replaced with fs/path, quiet logger, exists and deletion-constrained io.rmRF; Node built-in TypeScript stripping; cleaner bodies unchanged. No registry or other action entrypoint invoked.',metadata:'Actual pinned-toolchain locked offline all-features root/helper metadata; names/targets filtered as pinned Workspace implementation.',exclusive_dependency:exclusive.name,checks:{rejected_nested_mapping:'PASS actual cleaner deletes helper-only dependency under root target',nonoverlapping_mapping:'PASS dependency/fingerprint/build retained in both helper targets',binaries:'PASS helper executables removed from debug and deps',archive_boundaries:'PASS configured paths exclude receipts/artifacts/source guards structurally',generated_source:'PASS synthetic generated source removed by root cleaner; production post-restore regeneration preserved separately'},limits:'Synthetic cleaner fixture, not an uploaded archive, complete action execution, actual cache hit or speed/storage measurement. Registry/git paths unchanged; no credential/cache API action.',initial_attempts:['cargo unavailable in default PATH (127)','guessed conventional cargo path absent (127)','correct pinned toolchain path recovered from existing receipts; metadata then passed'],node:process.version};
fs.writeFileSync(path.join(base,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
