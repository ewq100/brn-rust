from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
repo=Path('/Users/evokessler/.codex/worktrees/notice-state/brn-rust');out=repo.parent/'exact-note-read-guidance-evidence'
pin='9229085a9683a1c988a1cb12d647f52df18115f6'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==pin
source=repo/'crates/brn-ai/src/threads.rs';expected='42b59c2623da1c587104bd4f58637786c851c41d0e14f47d1173e1b72294a0a7'
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
(out/'source.rs').write_bytes(source.read_bytes());(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','33a62aae1b358f1de9475040eb180c63e0651f4f',pin,'--','crates/brn-ai/src/threads.rs'],cwd=repo))
env={k:v for k,v in os.environ.items() if not k.startswith('BRN_')}
env.update(PATH='/opt/homebrew/opt/rustup/bin:'+env.get('PATH',''),RUSTUP_TOOLCHAIN='1.98.1',CARGO_TARGET_DIR='/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='1',TMPDIR=str(Path(os.environ['TMPDIR']).resolve()),DYLD_LIBRARY_PATH='/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib')
commands=[('runtime',['cargo','test','-p','brn-ai','--lib','--features','scripted-runs','--locked','--offline','--jobs','1']),('lint',['cargo','clippy','-p','brn-ai','--all-targets','--features','scripted-runs','--locked','--offline','--jobs','1','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check']),('ordinary-cli',['cargo','build','-p','brn','--locked','--offline','--jobs','1'])]
results=[]
for name,cmd in commands:
 assert shutil.disk_usage(repo).free>=1024**3,'less than1GiB free before compile'
 assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
 start=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':name+'.log'})
 (out/'commands.json').write_text(json.dumps({'pin':pin,'source_sha256':expected,'environment':{k:env[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','RUST_TEST_THREADS','TMPDIR','DYLD_LIBRARY_PATH']},'commands':results},indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
cli=Path(env['CARGO_TARGET_DIR'])/'debug/brn';b=cli.read_bytes();assert b'Copy the complete opaque Note ID verbatim' in b,'CLI missing actual new schema text'
artifact=out/('brn-'+pin[:8]);shutil.copy2(cli,artifact)
(out/'binary.json').write_text(json.dumps({'source':pin,'path':str(artifact),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'new_schema_string_present':True,'native_observed':False},indent=2)+'\n')
print('Qualification commands completed; source-matched ordinary CLI retained.',flush=True)
