#!/bin/bash
set -euo pipefail
cd /Users/evokessler/.codex/worktrees/export-durability/brn-rust
source /tmp/brn-launcher-focus-qualification/environment.sh
test -z "$(git status --porcelain)"
test "$(git rev-parse HEAD)" = 8912801c24f5f3a3ec4fb55bb8e5d74b118dba51
python3 - <<'PY'
from pathlib import Path
import re,shutil,json,hashlib
root=Path('/tmp/brn-launcher-focus-qualification');text=(root/'negative.log').read_text();match=re.search(r'Running .*?\(([^)]+brn_desktop-[^)]+)\)',text);assert match;binary=Path(match.group(1));dest=root/'before-final';dest.mkdir(exist_ok=True);rows=[]
for p in [binary,binary.with_suffix('.d')]:
 if p.exists():shutil.copy2(p,dest/p.name);rows.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(dest/'index.json').write_text(json.dumps(rows,indent=2)+'\n')
PY
printf 'FINAL CANDIDATE '; git rev-parse HEAD
shasum -a 256 crates/brn-desktop/src/threads_ui.rs crates/brn-desktop/src/threads_dialogs_tests.rs
cargo test -p brn-desktop --features native-ui,native-test-support --bin brn-desktop threads_ui::dialogs_tests:: --locked --offline --jobs 1 -- --nocapture
cargo clippy -p brn-desktop --features native-ui,native-test-support --all-targets --locked --offline --jobs 1 -- -D warnings
cargo fmt -p brn-desktop -- --check
git diff --check
test -z "$(git status --porcelain)"
