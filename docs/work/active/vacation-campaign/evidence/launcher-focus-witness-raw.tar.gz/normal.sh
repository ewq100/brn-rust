#!/bin/bash
set -euo pipefail
cd /Users/evokessler/.codex/worktrees/export-durability/brn-rust
source /tmp/brn-launcher-focus-qualification/environment.sh
printf 'SOURCE '; git rev-parse HEAD
shasum -a 256 crates/brn-desktop/src/threads_dialogs_tests.rs crates/brn-desktop/src/threads_ui.rs
shasum -a 256 "$BRN_XBERG_HELPER" "$BRN_XBERG_HELPER_BRN"
cargo test -p brn-desktop --features native-ui,native-test-support --bin brn-desktop threads_ui::dialogs_tests::escape_closes_one_layer_at_a_time_and_never_stops_work --locked --offline --jobs 1 -- --exact --nocapture
