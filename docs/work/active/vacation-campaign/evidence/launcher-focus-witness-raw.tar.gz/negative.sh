#!/bin/bash
set -euo pipefail
cd /Users/evokessler/.codex/worktrees/export-durability/brn-rust
source /tmp/brn-launcher-focus-qualification/environment.sh
test -z "$(git status --porcelain)"
trap 'git restore -- crates/brn-desktop/src/threads_ui.rs' EXIT
python3 - <<'PY'
from pathlib import Path
import shutil,hashlib,json,re
root=Path('/tmp/brn-launcher-focus-qualification');text=(root/'normal.log').read_text();match=re.search(r'Running .*?\(([^)]+brn_desktop-[^)]+)\)',text);assert match, 'exact normal test binary missing';binary=Path(match.group(1));dest=root/'before-negative';dest.mkdir(exist_ok=True);rows=[]
for p in [binary,binary.with_suffix('.d')]:
 if p.exists():shutil.copy2(p,dest/p.name);rows.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(dest/'index.json').write_text(json.dumps(rows,indent=2)+'\n')
p=Path('crates/brn-desktop/src/threads_ui.rs');s=p.read_text();old='''    fn close_launcher(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.launcher_open {
            self.launcher_open = false;
            self.focus_tile_contents(window, cx);
            cx.notify();
        }
    }
''';assert s.count(old)==1;s=s.replace(old,old.replace('            self.focus_tile_contents(window, cx);','            // Temporary negative control: omit visible-content focus restoration.'));p.write_text(s)
PY
git diff --binary -- crates/brn-desktop/src/threads_ui.rs > /tmp/brn-launcher-focus-qualification/negative.patch
printf 'CANDIDATE '; git rev-parse HEAD
printf 'WIP production mutation SHA256\n'
shasum -a 256 crates/brn-desktop/src/threads_ui.rs crates/brn-desktop/src/threads_dialogs_tests.rs
cargo test -p brn-desktop --features native-ui,native-test-support --bin brn-desktop threads_ui::dialogs_tests::escape_closes_one_layer_at_a_time_and_never_stops_work --locked --offline --jobs 1 -- --exact --nocapture
