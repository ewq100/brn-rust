import subprocess,sys
checks=[
 ('fixture-build-fixed',['cargo','build','-p','brn-threads-app','--example','native_writing_fixture','--locked','--offline','--jobs','1']),
 ('fixture-state',['python3','../agent-first-final-evidence/qualify_fixture.py']),
 ('combined-native',['cargo','test','-p','brn-desktop','--features','native-ui,native-test-support','--bin','brn-desktop','--locked','--offline','--jobs','1']),
 ('combined-app-status',['cargo','test','-p','brn-threads-app','--lib','apply_status_tests','--locked','--offline','--jobs','1']),
 ('combined-cli',['cargo','test','-p','brn','--test','agent_runs','--test','agent_authority','--test','agent_contract','--locked','--offline','--jobs','1']),
 ('combined-clippy',['cargo','clippy','-p','brn-ai','-p','brn-threads-app','-p','brn-writing-ui','-p','brn-desktop','-p','brn','--all-targets','--features','brn-ai/scripted-runs,brn-desktop/native-test-support,brn-writing-ui/native-test-support','--locked','--offline','--jobs','1','--','-D','warnings']),
 ('combined-fmt',['cargo','fmt','--all','--','--check']),
 ('production-native',['cargo','build','-p','brn-desktop','--features','native-ui','--bin','brn-desktop','--locked','--offline','--jobs','1']),
]
for name,args in checks:
 code=subprocess.call([sys.executable,'../agent-first-final-evidence/run_check.py',name,*args])
 if code:sys.exit(code)
