import hashlib,json,subprocess,sqlite3
from pathlib import Path
folder=Path(__file__).resolve().parent
binary=Path('/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target/debug/examples/native_writing_fixture')
root=folder/'native-fixture'
expected={'original':'tere tere õun\n\nThis is a synthetic writing fixture.\n','unrelated':'UNRELATED synthetic note — unchanged.\n','revised':'tere tere õun\n\nThis synthetic writing fixture is clearer.\n'}
checks=[]
def run(label,args,ok):
 p=subprocess.run([str(binary),*args],capture_output=True,text=True,cwd=folder)
 (folder/(label+'.stdout')).write_text(p.stdout);(folder/(label+'.stderr')).write_text(p.stderr)
 checks.append({'label':label,'command':[str(binary),*args],'exit_code':p.returncode,'expected_success':ok})
 assert (p.returncode==0)==ok,(label,p.stderr)
def files(path):
 return {str(f.relative_to(path)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(path.rglob('*')) if f.is_file()}
assert not root.exists()
run('fixture-fresh',['--output',str(root)],True)
manifest=json.loads((root/'manifest.json').read_text())
for key,value in expected.items():
 assert manifest['source_constants'][key]==value
 assert manifest['source_constants'][key+'_sha256']==hashlib.sha256(value.encode()).hexdigest()
assert manifest['comments'][0]['range_utf8_bytes']==[0,4]
assert manifest['comments'][1]['range_utf8_bytes']==[10,14]
for comment in manifest['comments']:
 start,end=comment['range_utf8_bytes'];assert expected['original'].encode()[start:end].decode()==comment['quote']
database=root/'workspace'/'threads.sqlite3'
c=sqlite3.connect(database.as_uri()+'?mode=ro',uri=True)
c.execute('PRAGMA query_only=ON');c.execute('BEGIN')
records={row[0]:json.loads(row[1]) for row in c.execute('SELECT id,body FROM records')}
assert records[manifest['target_note']['id']]['data']['Note']['markdown']==expected['original']
assert records[manifest['unrelated_note']['id']]['data']['Note']['markdown']==expected['unrelated']
settings=[json.loads(row[0])['data']['Settings'] for row in c.execute("SELECT body FROM revisions WHERE json_type(body,'$.data.Settings') IS NOT NULL")]
assert settings and all(s.get('auth_file') is None and s.get('credentials_dir') is None for s in settings)
assert any(s['provider']=='offline-fixture' and s.get('helper') is None for s in settings)
operation=manifest['candidate']['operation_id']
assert c.execute('SELECT count(*) FROM receipts WHERE operation=?',(operation,)).fetchone()[0]==0
request=json.loads(c.execute('SELECT request FROM operations WHERE id=?',(operation,)).fetchone()[0])
writes=[w for w in request['writes'] if w['id']==manifest['target_note']['id']]
assert len(writes)==1 and writes[0]['data']['Note']['markdown']==expected['revised']
for comment in manifest['comments']:
 actual=records[comment['id']]['data']['Comment']
 assert actual['quote']==comment['quote'] and actual['body']==comment['body']
c.rollback();c.close()
before=files(root)
run('fixture-existing-directory',['--output',str(root)],False)
assert files(root)==before
sentinel=folder/'existing-fixture-sentinel.txt';sentinel.write_text('preserve existing bytes\n')
run('fixture-existing-file',['--output',str(sentinel)],False)
assert sentinel.read_text()=='preserve existing bytes\n'
relative='must-not-create-relative-fixture';assert not (folder/relative).exists()
run('fixture-relative',['--output',relative],False)
assert not (folder/relative).exists()
result={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),'checks':checks,'independent_observations':['exact original/unrelated canonical bytes','exact replacement remains prepared without receipt','exact UTF8 comment anchors','all settings history excludes auth and credential paths','existing directory/file unchanged','relative root refused without creation'],'native_interaction':False,'v2_evidence_qualification':False}
(folder/'fixture-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print('Fixture: fresh exact synthetic state and three refusal cases passed; no native interaction')
