import subprocess,sys
checks=[
 ('combined-clippy',['cargo','clippy','-p','brn-ai','-p','brn-threads-app','-p','brn-writing-ui','-p','brn-desktop','-p','brn','--all-targets','--features','brn-ai/scripted-runs,brn-desktop/native-test-support,brn-writing-ui/native-test-support','--locked','--offline','--jobs','1','--','-D','warnings']),
 ('combined-fmt',['cargo','fmt','--all','--','--check']),
 ('production-native',['cargo','build','-p','brn-desktop','--features','native-ui','--bin','brn-desktop','--locked','--offline','--jobs','1']),
]
for name,args in checks:
 code=subprocess.call([sys.executable,'../agent-first-final-evidence/run_check.py',name,*args])
 if code:sys.exit(code)
