#!/bin/bash
set -euo pipefail
source /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-preview-cancellation-qualification/tmp
cd /Users/evokessler/.codex/worktrees/export-durability/brn-rust
test "$(git rev-parse HEAD)" = cacab2e535c27b6d8541e4e6ff77afbcea0d31b0
test -z "$(git status --porcelain)"
cargo test -p brn --test agent_bounds timeout_during_preview_fifo_wait_is_a_soft_deadline_without_changes --locked --offline --jobs 1 -- --exact
cargo clippy -p brn --all-targets --locked --offline --jobs 1 -- -D warnings
cargo fmt -p brn -- --check
git diff --check
