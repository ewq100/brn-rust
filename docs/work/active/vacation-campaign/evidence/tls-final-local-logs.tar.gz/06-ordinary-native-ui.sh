#!/bin/zsh
set -eu
. /tmp/brn-launcher-focus-qualification/environment.sh
export TMPDIR=/private/tmp/brn-tls-qualification-20261022T1026
export ORT_SKIP_DOWNLOAD=1 ORT_OFFLINE=1
export ORT_LIB_LOCATION=/Users/evokessler/Library/Caches/ort.pyke.io/dfbin/aarch64-apple-darwin/6934874e2e953576d9c1db47ff1af39c62c4f4220dbe6f988e131f72879674c7
cargo build -p brn-desktop --bin brn-desktop --features native-ui --locked --offline --jobs 1
