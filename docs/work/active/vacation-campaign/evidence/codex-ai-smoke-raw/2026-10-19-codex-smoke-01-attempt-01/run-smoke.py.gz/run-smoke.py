from pathlib import Path
import os,json,subprocess,time,hashlib,datetime
out=Path(__file__).resolve().parent
repo=Path('/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust')
ledger=repo/'docs/work/active/vacation-campaign/evidence/codex-ai-test-ledger.json'
d=json.loads(ledger.read_text());a=next(x for x in d['attempts'] if x['evidence_directory']==str(out))
assert a['status']=='reserved'
cli=Path('/Users/evokessler/.codex/worktrees/worker-drain-budget/proposed-writing-feedback-artifacts/brn-4e81fcba-e321553bc2c2abca')
assert hashlib.sha256(cli.read_bytes()).hexdigest()==a['binary_sha256']
auth=Path.home()/'.codex/auth.json';assert auth.is_file()
auth_before=auth.stat()
for name in ['private-home','tmp']: (out/name).mkdir(mode=0o700,exist_ok=False)
env={'HOME':str(out/'private-home'),'CODEX_HOME':str(out/'private-home/.codex'),'TMPDIR':str(out/'tmp'),'TMP':str(out/'tmp'),'TEMP':str(out/'tmp'),'PATH':'/usr/bin:/bin:/opt/homebrew/bin','DYLD_LIBRARY_PATH':'/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib'}
for k in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy','SSL_CERT_FILE','SSL_CERT_DIR']:
 if k in os.environ: env[k]=os.environ[k]
data=out/'data';commands=[]
def call(name,args,deadline=30):
 command=[str(cli),'--json','--data-dir',str(data),*args]
 redacted=[('[existing owner Codex auth file]' if x==str(auth) else x) for x in command]
 started=time.monotonic()
 r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=deadline)
 (out/(name+'.stdout.json')).write_bytes(r.stdout);(out/(name+'.stderr.log')).write_bytes(r.stderr)
 commands.append({'name':name,'args':redacted,'exit':r.returncode,'elapsed_seconds':time.monotonic()-started})
 v=json.loads(r.stdout)
 if r.returncode!=0: raise RuntimeError(name+': '+str(v.get('error',{}).get('code','failed')))
 return v['result']
result={'attempt_id':a['id'],'provider':'Codex','model':a['model'],'effort':a['effort'],'native_observed':False}
try:
 call('init',['init','--purpose','test'])
 note_text='Synthetic test only.\nCodeword: rannatuli-õun-17.\nItems: 4 red blocks and 5 blue blocks.\n'
 # These are intentional newline bytes, not a serialized escape sequence.
 note=call('note',['note-create','--title','Synthetic account smoke','--text',note_text])
 chat=call('thread',['thread-start','--title','Synthetic Codex smoke'])
 call('configure',['configure','--provider','Codex','--model',a['model'],'--effort',a['effort'],'--auth-file',str(auth),'--helper','off'])
 prompt='Read Note '+note['id']+'. Reply exactly in this form: CODEWORD=<the codeword in that note>; TOTAL=<the sum of red and blue blocks>. Respond in chat only. Do not edit, create or prepare any records and do not use external sources.'
 assert len(note_text.encode())+len(prompt.encode())<=8192
 (out/'prompt.txt').write_text(prompt)
 a['status']='running';a['started_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();ledger.write_text(json.dumps(d,indent=2)+'\n')
 response=call('ask',['--timeout','180','ask','--thread',chat['id'],'--prompt-file',str(out/'prompt.txt'),'--budget','4','--trace','summary'],186)
 after=call('note-after',['read','--id',note['id']]);candidates=call('candidates-after',['candidates','--limit','10']);runs=call('runs-after',['runs','--thread',chat['id']])
 answer=response.get('answer','')
 assert 'rannatuli-õun-17' in answer and 'TOTAL=9' in answer,(answer,'unexpected semantic result')
 assert after==note,'canonical note changed'
 assert candidates['candidates']==[],'unexpected candidate'
 a['status']='passed';result.update(passed=True,note_id=note['id'],thread_id=chat['id'],answer=answer,note_unchanged=True,no_candidates=True,runs=runs)
except Exception as error:
 a['status']='failed';result.update(passed=False,error_type=type(error).__name__,error=str(error))
finally:
 a['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 auth_after=auth.stat();result['auth_source_metadata_unchanged']=(auth_before.st_ino,auth_before.st_size,auth_before.st_mtime_ns)==(auth_after.st_ino,auth_after.st_size,auth_after.st_mtime_ns)
 result['commands']=commands
 (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 a['result_file']=str(out/'result.json');ledger.write_text(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['attempt_id','model','passed','native_observed']},ensure_ascii=False))
 if not result['passed']: print(json.dumps({k:result.get(k) for k in ['error_type','error']},ensure_ascii=False))
