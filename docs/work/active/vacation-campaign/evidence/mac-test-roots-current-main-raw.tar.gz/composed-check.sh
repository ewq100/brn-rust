#!/bin/zsh
set -eu
export PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:$PATH
export DYLD_LIBRARY_PATH=/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib
export CARGO_TARGET_DIR=/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target
export CARGO_BUILD_JOBS=1
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_INCREMENTAL=0
git rev-parse HEAD
printf 'Inherited Mac TMPDIR: %s\n' "$TMPDIR"
cargo fmt -p brn-threads-core --check
cargo test -p brn-threads-core --locked --offline --jobs 1
cargo clippy -p brn-threads-core --test mcp_policy --locked --offline --jobs 1 -- -D warnings
