import hashlib,json,os,pathlib,subprocess,sys,time,shutil
root=pathlib.Path('/Users/evokessler/.codex/worktrees/notice-state/brn-rust')
evidence=root.parent/'targeted-edit-evidence'
name,*command=sys.argv[1:]
env=os.environ.copy()
env.update(PATH='/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin:'+env['PATH'],CARGO_TARGET_DIR='/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',DYLD_LIBRARY_PATH='/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin/lib',BRN_XBERG_HELPER='/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper',BRN_XBERG_HELPER_BRN='/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper-brn')
tracked=subprocess.check_output(['git','diff','--name-only','67d62aec'],cwd=root,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(tracked+untracked)) if (root/p).is_file()}
meta={'command':command,'environment':{k:env[k] for k in ('PATH','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_BUILD_JOBS','RUST_TEST_THREADS','DYLD_LIBRARY_PATH','BRN_XBERG_HELPER','BRN_XBERG_HELPER_BRN')},'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'toolchain':subprocess.check_output(['rustc','--version'],env=env,text=True).strip(),'source_sha256':source,'started':time.time()}
(evidence/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
if shutil.disk_usage(root).free < 1024**3:
 raise SystemExit('Disk below 1GiB; refusing command')
print('CHECK_START='+name,flush=True)
with (evidence/(name+'.log')).open('w') as log:
 process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,text=True)
 while process.poll() is None:
  if shutil.disk_usage(root).free < 1024**3:
   process.terminate();meta['disk_stop']=True;break
  time.sleep(1)
 result=process.wait()
print((evidence/(name+'.log')).read_text()[-9000:],flush=True)
meta.update(exit_code=result,finished=time.time(),log_sha256=hashlib.sha256((evidence/(name+'.log')).read_bytes()).hexdigest())
(evidence/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
print('CHECK_EXIT='+str(result),flush=True)
sys.exit(result)
