#!/usr/bin/env python3
"""One-shot, read-only continuation for the already fetched RustSec DB and verified cargo-audit binary.

Inert until explicitly launched. The first baseline report is validated in place, never rerun.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import threading
import time
import tomllib
import uuid

ROOT = Path('/private/tmp/brn-advisory-audit-20261022')
CONFIG_PATH = ROOT / 'continuation-config.json'
OUTPUT = ROOT / 'packet-continuation'
HELPER = Path('/tmp/brn-mac13-preparation/prepare.py')
EXPECTED_HELPER_SHA = 'cd272ff3734a2a46c2a83ff944a9d2f15d768e6bef45de03df49378009854813'
MAX_OUTPUT = 1024 * 1024
OVERALL_SECONDS = 300.0
CLEANUP_RESERVE_SECONDS = 30.0
START_FREE_BYTES = 2 * 1024**3
LIVE_FREE_BYTES = 1024**3


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_hash(path: Path) -> tuple[str, int]:
    digest = hashlib.sha256()
    total = 0
    with path.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
            total += len(chunk)
    return digest.hexdigest(), total


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


def atomic_json(path: Path, value: object) -> None:
    temp = path.with_name(path.name + '.tmp-' + uuid.uuid4().hex)
    payload = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True).encode('utf-8') + b'\n'
    try:
        with temp.open('xb') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
        fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


class StopRun(RuntimeError):
    pass


class AuditContinuation:
    def __init__(self, config: dict, cleanup) -> None:
        self.config = config
        self.cleanup = cleanup
        self.started = time.monotonic()
        self.deadline = self.started + OVERALL_SECONDS
        self.commands: list[dict] = []
        self.packet = OUTPUT
        self.commands_dir = self.packet / 'commands'
        self.snapshots_dir = self.packet / 'db-snapshots'
        self.locks_dir = self.packet / 'locks'
        self.receipt_path = self.packet / 'continuation-receipt.json'
        self.manifest = {
            'schema': 'brn.current-lock-advisory-continuation.v1',
            'status': 'running', 'started_at': utc_now(), 'task_root': str(ROOT),
            'config_sha256': sha256(CONFIG_PATH.read_bytes()), 'commands': self.commands,
            'source_inputs': [], 'database_snapshots': [], 'scan_results': [],
            'limits': {'overall_seconds': OVERALL_SECONDS,
                       'cleanup_reserve_seconds': CLEANUP_RESERVE_SECONDS,
                       'max_combined_output_bytes_per_command': MAX_OUTPUT,
                       'minimum_start_free_bytes': START_FREE_BYTES,
                       'minimum_live_free_bytes': LIVE_FREE_BYTES,
                       'scan_flags': ['--no-fetch', '--no-yanked', '--format', 'json'],
                       'ignored_advisories': [], 'target_arch': [], 'target_os': [],
                       'severity_threshold': None},
            'native_observed': False, 'owner_accepted': False,
            'notes': ['Existing main-213 baseline report is validated in place; it is not rerun.',
                      'The earlier 003 root snapshot and original attempt packets are preserved unscanned.',
                      'Exit 1 means vulnerability findings; it is retained as a result, not retried.',
                      'A lockfile match is not reachability or exposure evidence.',
                      '--no-yanked omits yanked checking.'],
        }

    def persist(self) -> None:
        self.manifest['elapsed_seconds'] = round(time.monotonic() - self.started, 3)
        self.manifest['free_bytes'] = shutil.disk_usage('/private/tmp').free
        atomic_json(self.receipt_path, self.manifest)

    def remaining(self) -> float:
        value = self.deadline - time.monotonic() - CLEANUP_RESERVE_SECONDS
        if value <= 0:
            raise StopRun('overall deadline reached cleanup reserve')
        if shutil.disk_usage('/private/tmp').free < LIVE_FREE_BYTES:
            raise StopRun('private tmp free space below 1 GiB')
        return value

    def run(self, name: str, argv: list[str], cwd: Path, timeout: float,
            env: dict[str, str], accepted: tuple[int, ...] = (0,)) -> tuple[int, bytes, bytes]:
        timeout = min(timeout, self.remaining())
        index = len(self.commands) + 1
        prefix = f'{index:02d}-{name}'
        stdout_path = self.commands_dir / f'{prefix}.stdout'
        stderr_path = self.commands_dir / f'{prefix}.stderr'
        row = {'index': index, 'name': name, 'argv': argv, 'cwd': str(cwd),
               'timeout_seconds': round(timeout, 3), 'stdout_path': str(stdout_path),
               'stderr_path': str(stderr_path), 'max_combined_output_bytes': MAX_OUTPUT,
               'started_at': utc_now()}
        self.commands.append(row)
        self.persist()
        proc = None
        threads: list[threading.Thread] = []
        state = {'used': 0, 'overflow': False, 'reader_errors': []}
        lock = threading.Lock()
        overflow = threading.Event()
        errors: list[str] = []
        signals: list[str] = []
        stop_reason = None

        def drain(pipe, path: Path) -> None:
            try:
                with path.open('xb') as output:
                    while True:
                        chunk = pipe.read(65536)
                        if not chunk:
                            break
                        with lock:
                            remaining = MAX_OUTPUT - state['used']
                            if remaining <= 0:
                                state['overflow'] = True
                                overflow.set()
                                break
                            kept = chunk[:remaining]
                            output.write(kept)
                            state['used'] += len(kept)
                            if len(kept) != len(chunk):
                                state['overflow'] = True
                                overflow.set()
                                break
                    output.flush()
                    os.fsync(output.fileno())
            except BaseException as exc:
                state['reader_errors'].append(f'{type(exc).__name__}: {exc}')
                overflow.set()
            finally:
                try:
                    pipe.close()
                except OSError:
                    pass

        try:
            proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, cwd=str(cwd), env=env,
                                    start_new_session=True, close_fds=True)
            threads = [threading.Thread(target=drain, args=(proc.stdout, stdout_path), daemon=True),
                       threading.Thread(target=drain, args=(proc.stderr, stderr_path), daemon=True)]
            for thread in threads:
                thread.start()
            command_deadline = time.monotonic() + timeout
            while proc.poll() is None:
                if overflow.is_set():
                    stop_reason = 'output cap reached or bounded capture failed'
                    break
                if time.monotonic() >= command_deadline:
                    stop_reason = 'command deadline reached'
                    break
                if time.monotonic() >= self.deadline - CLEANUP_RESERVE_SECONDS:
                    stop_reason = 'overall cleanup reserve reached'
                    break
                if shutil.disk_usage('/private/tmp').free < LIVE_FREE_BYTES:
                    stop_reason = 'private tmp free space below 1 GiB'
                    break
                time.sleep(0.05)
            clean = self.cleanup(proc, signals, errors)
            for thread in threads:
                thread.join(timeout=1.0)
            if any(thread.is_alive() for thread in threads):
                errors.append('output reader remained alive after process-group cleanup')
            row.update({'return_code': proc.returncode, 'leader_reaped': proc.returncode is not None,
                        'group_absent': clean, 'signals_sent': signals, 'cleanup_errors': errors,
                        'output_bytes': state['used'], 'output_overflow': state['overflow'],
                        'reader_errors': state['reader_errors'], 'stop_reason': stop_reason,
                        'finished_at': utc_now()})
            for label, path in (('stdout', stdout_path), ('stderr', stderr_path)):
                if path.exists():
                    row[label + '_sha256'], row[label + '_bytes'] = file_hash(path)
            self.persist()
            if (stop_reason or not clean or errors or state['overflow'] or state['reader_errors']
                    or proc.returncode not in accepted):
                raise StopRun(f'{name} failed or stopped; see raw command record')
            if signals:
                raise StopRun(f'{name} required descendant cleanup; see raw command record')
            return proc.returncode, stdout_path.read_bytes(), stderr_path.read_bytes()
        except BaseException:
            if proc is not None:
                clean = self.cleanup(proc, signals, errors)
                row.update({'return_code': proc.returncode, 'leader_reaped': proc.returncode is not None,
                            'group_absent': clean, 'signals_sent': signals,
                            'cleanup_errors': errors, 'finished_at': utc_now()})
            try:
                self.persist()
            except BaseException:
                pass
            raise

    def git(self, name: str, repo: Path, args: list[str], timeout: float = 15.0,
            accepted: tuple[int, ...] = (0,)) -> bytes:
        git = '/usr/bin/git'
        env = dict(self.env(), GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull,
                   GIT_TERMINAL_PROMPT='0', GIT_PAGER='cat', PAGER='cat')
        argv = [git, '--no-pager', '--no-optional-locks', '-C', str(repo), *args]
        _, stdout, stderr = self.run(name, argv, ROOT, timeout, env, accepted)
        if stderr:
            raise StopRun(name + ': unexpected Git stderr; raw capture retained')
        return stdout

    def env(self) -> dict[str, str]:
        env = {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'LANG': 'C', 'LC_ALL': 'C',
               'TMPDIR': str(ROOT / 'tmp'), 'CARGO_HOME': str(ROOT / 'cargo-home'),
               'CARGO_NET_OFFLINE': 'true'}
        for name in ('HOME', 'CODEX_HOME'):
            if name in os.environ:
                env[name] = os.environ[name]
        return env

    def source_proof(self, item: dict) -> dict:
        checkout = Path(item['checkout'])
        rel = item['lock_path']
        expected_commit = item.get('commit')
        head = self.git('source-' + item['label'] + '-head', checkout, ['rev-parse', 'HEAD']).decode().strip()
        if expected_commit and head != expected_commit:
            raise StopRun(item['label'] + ': source HEAD differs from pinned commit')
        status_args = ['status', '--porcelain', '--untracked-files=all']
        if not expected_commit:
            status_args.extend(['--', rel])
        status = self.git('source-' + item['label'] + '-status', checkout, status_args).decode()
        if status:
            raise StopRun(item['label'] + ': selected lockfile is dirty or untracked')
        tree = self.git('source-' + item['label'] + '-tree', checkout,
                        ['ls-tree', '-r', '-z', '--full-tree', 'HEAD', '--', rel])
        entries = [x for x in tree.split(b'\0') if x]
        if len(entries) != 1:
            raise StopRun(item['label'] + ': lock path is not a unique tracked tree entry')
        meta, tree_path = entries[0].split(b'\t', 1)
        mode, kind, blob = meta.decode('ascii').split(' ')
        if tree_path.decode('utf-8', 'strict') != rel or mode != '100644' or kind != 'blob':
            raise StopRun(item['label'] + ': tracked lock entry has unexpected type/path')
        source = checkout / rel
        st = source.lstat()
        if not stat.S_ISREG(st.st_mode) or source.is_symlink():
            raise StopRun(item['label'] + ': lock source is not a regular non-symlink file')
        data = source.read_bytes()
        if len(data) != item['lock_bytes'] or sha256(data) != item['lock_sha256']:
            raise StopRun(item['label'] + ': lock bytes differ from frozen configuration')
        if git_blob_sha1(data) != blob.decode('ascii'):
            raise StopRun(item['label'] + ': file bytes do not match tracked Git blob')
        with __import__('io').BytesIO(data) as stream:
            parsed = tomllib.load(stream)
        if not isinstance(parsed.get('package'), list) or len(parsed['package']) != item['package_count']:
            raise StopRun(item['label'] + ': TOML package count differs from pinned config')
        return {'label': item['label'], 'checkout': str(checkout), 'head_observed': head,
                'lock_path': rel, 'bytes': len(data), 'sha256': sha256(data),
                'git_blob_sha1': blob.decode('ascii'), 'package_count': len(parsed['package']),
                'status_clean_for_path': True, 'git_mode': mode, 'snapshot_source': str(source)}

    def snapshot_db(self, label: str) -> dict:
        db = Path(self.config['database']['path'])
        head = self.git('db-' + label + '-head', db, ['rev-parse', 'HEAD']).decode().strip()
        if head != self.config['database']['head']:
            raise StopRun('advisory database HEAD changed from pinned commit')
        status = self.git('db-' + label + '-status', db,
                          ['status', '--porcelain', '--untracked-files=all']).decode()
        if status:
            raise StopRun('advisory database checkout is dirty')
        raw = self.git('db-' + label + '-tree', db,
                       ['ls-tree', '-r', '-z', '--full-tree', 'HEAD', '--', 'crates', 'rust'], timeout=20.0)
        expected: dict[str, tuple[str, str, str]] = {}
        for record in raw.split(b'\0'):
            if not record:
                continue
            metadata, raw_path = record.split(b'\t', 1)
            mode, kind, blob = metadata.decode('ascii').split(' ')
            path = raw_path.decode('utf-8', 'strict')
            if not path.startswith(('crates/', 'rust/')) or not path.endswith('.md'):
                raise StopRun('unexpected non-record path under advisory collections')
            if mode != '100644' or kind != 'blob' or path in expected:
                raise StopRun('tracked advisory record has duplicate or unexpected Git type')
            expected[path] = (mode, kind, blob)
        if len(expected) != self.config['database']['expected_record_files']:
            raise StopRun('tracked advisory-record count differs from pinned evidence')

        observed: dict[str, tuple[str, int, str]] = {}
        for collection in ('crates', 'rust'):
            base = db / collection
            if not base.is_dir() or base.is_symlink():
                raise StopRun('advisory collection directory missing or symlinked')
            for root, dirs, files in os.walk(base, followlinks=False):
                for dirname in dirs:
                    path = Path(root) / dirname
                    if path.is_symlink():
                        raise StopRun('symlink directory found beneath advisory collections')
                for filename in files:
                    path = Path(root) / filename
                    rel = path.relative_to(db).as_posix()
                    st = path.lstat()
                    if not stat.S_ISREG(st.st_mode) or path.is_symlink():
                        raise StopRun('nonregular/symlink file beneath advisory collections')
                    data = path.read_bytes()
                    observed[rel] = (sha256(data), len(data), git_blob_sha1(data))
        if set(observed) != set(expected):
            raise StopRun('filesystem advisory-record paths differ from tracked tree')
        records = []
        for path in sorted(expected):
            mode, kind, blob = expected[path]
            sha, size, computed_blob = observed[path]
            if blob != computed_blob:
                raise StopRun('advisory record bytes differ from Git tree blob')
            records.append({'path': path, 'git_blob_sha1': blob, 'sha256': sha, 'bytes': size})
        canonical = json.dumps(records, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        snapshot = {'label': label, 'head': head, 'status_clean': True,
                    'record_count': len(records), 'inventory_sha256': sha256(canonical),
                    'tree_stdout_sha256': sha256(raw), 'records': records}
        path = self.snapshots_dir / f'{label}.json'
        atomic_json(path, snapshot)
        snapshot['snapshot_path'] = str(path)
        return snapshot

    def verify_lock_snapshot(self, item: dict, proof: dict, stage: str) -> None:
        path = Path(proof['snapshot_path'])
        st = path.lstat()
        if not stat.S_ISREG(st.st_mode) or path.is_symlink():
            raise StopRun(item['label'] + ': lock snapshot is not a regular non-symlink file')
        digest, size = file_hash(path)
        if size != item['lock_bytes'] or digest != item['lock_sha256']:
            raise StopRun(item['label'] + ': lock snapshot bytes changed at ' + stage)
        self.manifest.setdefault('snapshot_verifications', []).append({
            'label': item['label'], 'stage': stage, 'path': str(path),
            'bytes': size, 'sha256': digest, 'regular_nonsymlink': True})
        self.persist()

    def validate_report(self, name: str, raw: bytes, stderr: bytes, code: int,
                        lock_snapshot: dict, db_snapshot: dict, expected_db_count: int) -> dict:
        try:
            report = json.loads(raw.decode('utf-8', 'strict'))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise StopRun(name + ': malformed report JSON') from exc
        if not isinstance(report, dict) or set(('database','lockfile','settings','vulnerabilities','warnings')) - set(report):
            raise StopRun(name + ': missing report section')
        dbinfo, lockinfo = report['database'], report['lockfile']
        settings, vulns, warnings = report['settings'], report['vulnerabilities'], report['warnings']
        if not all(isinstance(x, dict) for x in (dbinfo, lockinfo, settings, vulns, warnings)):
            raise StopRun(name + ': report sections have invalid types')
        if dbinfo.get('advisory-count') != expected_db_count:
            raise StopRun(name + ': advisory count differs from frozen baseline')
        report_commit = dbinfo.get('last-commit')
        if report_commit is not None and report_commit != db_snapshot['head']:
            raise StopRun(name + ': nonnull report DB commit conflicts with frozen DB')
        last_updated = dbinfo.get('last-updated')
        if last_updated is not None and not isinstance(last_updated, str):
            raise StopRun(name + ': last-updated has invalid JSON type')
        if lockinfo.get('dependency-count') != lock_snapshot['package_count']:
            raise StopRun(name + ': report dependency count differs from input lock')
        if (settings.get('ignore') != [] or settings.get('target_arch') != []
                or settings.get('target_os') != [] or settings.get('severity') is not None):
            raise StopRun(name + ': unexpected advisory/target/severity filter')
        vlist = vulns.get('list')
        count, found = vulns.get('count'), vulns.get('found')
        if (not isinstance(vlist, list) or any(not isinstance(item, dict) for item in vlist)
                or type(count) is not int or type(found) is not bool):
            raise StopRun(name + ': malformed vulnerability summary')
        if count != len(vlist) or found != bool(vlist):
            raise StopRun(name + ': vulnerability count/found/list disagree')
        if (found and code != 1) or (not found and code != 0):
            raise StopRun(name + ': exit status conflicts with vulnerability result')
        if any(not isinstance(kind, str) or not isinstance(items, list)
               or any(not isinstance(item, dict) for item in items)
               for kind, items in warnings.items()):
            raise StopRun(name + ': malformed warning report')
        parsed_path = self.commands_dir / f'{name}.parsed.json'
        atomic_json(parsed_path, report)
        return {'name': name, 'return_code': code, 'input_label': lock_snapshot['label'],
                'input_sha256': lock_snapshot['sha256'], 'dependency_count': lock_snapshot['package_count'],
                'database_head_external': db_snapshot['head'], 'report_last_commit': report_commit,
                'report_last_updated': last_updated, 'advisory_count': dbinfo['advisory-count'],
                'vulnerability_count': count, 'vulnerabilities_found': found,
                'vulnerabilities': [{'id': item.get('advisory', {}).get('id'),
                                     'package': item.get('package', {}).get('name'),
                                     'version': item.get('package', {}).get('version')}
                                    for item in vlist],
                'warnings': warnings, 'settings': settings,
                'parsed_json_path': str(parsed_path), 'stderr_bytes': len(stderr)}


def main() -> int:
    if platform.machine() != 'arm64':
        raise StopRun('expected arm64 host')
    if OUTPUT.exists():
        raise StopRun('continuation packet path already exists; refusing overwrite')
    if shutil.disk_usage('/private/tmp').free < START_FREE_BYTES:
        raise StopRun('less than 2 GiB free at start')
    if not HELPER.is_file() or file_hash(HELPER)[0] != EXPECTED_HELPER_SHA:
        raise StopRun('approved owned-process cleanup helper hash mismatch')
    spec = importlib.util.spec_from_file_location('approved_cleanup_attempt2', HELPER)
    helper_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper_module)
    cleanup = helper_module.stop_and_reap

    config = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
    if config.get('schema') != 'brn.current-lock-advisory-continuation.v1':
        raise StopRun('unexpected fixed provenance config schema')
    if config['tool']['sha256'] != '33fbe81adca1b794f4ffe98574d59b0ebe6fcfdb310976fafed98a094c795111':
        raise StopRun('binary hash pin differs')
    if config['database']['head'] != '59ef7abf8ce56ea80fe7eba97ba3835449009fa4':
        raise StopRun('database commit pin differs')
    tool = Path(config['tool']['path'])
    if file_hash(tool)[0] != config['tool']['sha256']:
        raise StopRun('verified audit binary changed')
    previous_packet = Path(config['previous_packet'])
    old_snapshot = Path(config['preserved_unscanned']['snapshot'])
    if file_hash(old_snapshot)[0] != config['preserved_unscanned']['sha256']:
        raise StopRun('preserved 003 root snapshot changed')
    output = OUTPUT
    output.mkdir(mode=0o700)
    runner = AuditContinuation(config, cleanup)
    runner.packet.mkdir(exist_ok=True)
    runner.commands_dir.mkdir(mode=0o700)
    runner.snapshots_dir.mkdir(mode=0o700)
    runner.locks_dir.mkdir(mode=0o700)
    (ROOT / 'tmp').mkdir(mode=0o700, exist_ok=True)
    try:
        runner.persist()
        db = Path(config['database']['path'])
        if not db.is_dir():
            raise StopRun('pinned task DB directory missing')
        if file_hash(tool)[0] != config['tool']['sha256']:
            raise StopRun('audit binary changed after initial check')

        # Validate the completed baseline in its original packet without rerunning it.
        prev_receipt = json.loads((previous_packet / 'scan-receipt.json').read_text(encoding='utf-8'))
        if prev_receipt.get('status') != 'failed':
            raise StopRun('baseline original failure status was not retained')
        if prev_receipt.get('database', {}).get('db-head') != config['database']['head']:
            raise StopRun('baseline receipt DB HEAD differs from fixed pin')
        if prev_receipt.get('binary', {}).get('sha256') != config['tool']['sha256']:
            raise StopRun('baseline receipt binary differs from fixed pin')
        if prev_receipt.get('archive', {}).get('sha256') != 'ec7ca4263769593df4d909be85b94a6b79efa2897be5d2bb8ebd516e823175af':
            raise StopRun('baseline receipt archive digest differs from official asset pin')
        if '0.22.2' not in prev_receipt.get('tool_version', {}).get('stdout', ''):
            raise StopRun('baseline receipt does not confirm pinned tool version')
        if file_hash(previous_packet / 'scan-receipt.json')[0] != config['previous_baseline']['receipt_sha256']:
            raise StopRun('original attempt-2 receipt changed')
        baseline_row = next((x for x in prev_receipt.get('commands', [])
                             if x.get('name') == 'audit-main213-root-lock'), None)
        if not baseline_row or baseline_row.get('return_code') != 1:
            raise StopRun('baseline command status missing or changed')
        if baseline_row.get('stdout_sha256') != config['previous_baseline']['stdout_sha256']:
            raise StopRun('baseline raw stdout hash differs from pin')
        if baseline_row.get('stderr_sha256') != hashlib.sha256(b'').hexdigest():
            raise StopRun('baseline stderr hash differs from empty-stream capture')
        baseline_stdout = Path(baseline_row['stdout_path'])
        if file_hash(baseline_stdout)[0] != config['previous_baseline']['stdout_sha256']:
            raise StopRun('baseline raw stdout changed')
        baseline_lock = Path(config['previous_packet']) / 'locks/main213-root-lock.Cargo.lock'
        if file_hash(baseline_lock)[0] != config['previous_baseline']['lock_sha256']:
            raise StopRun('baseline input snapshot changed')
        base_lock_data = tomllib.loads(baseline_lock.read_text(encoding='utf-8'))
        base_meta = {'label': config['previous_baseline']['label'],
                     'sha256': config['previous_baseline']['lock_sha256'],
                     'package_count': len(base_lock_data['package'])}
        expected_argv = baseline_row.get('argv', [])
        flag_values = {}
        for flag in ('--file', '--db', '--format'):
            if flag not in expected_argv or expected_argv.index(flag) + 1 >= len(expected_argv):
                raise StopRun('baseline command is missing a required option value')
            flag_values[flag] = expected_argv[expected_argv.index(flag) + 1]
        if (baseline_row.get('stdout_path') != str(baseline_stdout)
                or '--no-fetch' not in expected_argv or '--no-yanked' not in expected_argv
                or flag_values != {'--file': str(baseline_lock), '--db': str(config['database']['path']), '--format': 'json'}):
            raise StopRun('baseline command provenance/flags differ from pinned scan')
        runner.manifest['baseline_in_place'] = runner.validate_report(
            'baseline-main213-root-lock', baseline_stdout.read_bytes(),
            Path(baseline_row['stderr_path']).read_bytes(), baseline_row['return_code'],
            base_meta, {'head': config['database']['head']}, config['database']['expected_advisory_count'])
        if runner.manifest['baseline_in_place']['advisory_count'] != config['database']['expected_advisory_count']:
            raise StopRun('baseline report advisory count differs from pinned DB')
        if (runner.manifest['baseline_in_place']['vulnerability_count'] != config['previous_baseline']['vulnerability_count']
                or sum(len(v) for v in runner.manifest['baseline_in_place']['warnings'].values())
                != config['previous_baseline']['warning_count']):
            raise StopRun('baseline finding/warning totals differ from original evidence')
        runner.manifest['baseline_in_place']['raw_stdout_sha256'] = config['previous_baseline']['stdout_sha256']
        runner.manifest['baseline_in_place']['original_receipt_status'] = 'failed (preserved provenance-check stop)'
        runner.persist()

        # Prepare exact final candidate and helper lock snapshots, with Git blob proofs.
        inputs = [config['source_candidate'], *config['helper_inputs']]
        for item in inputs:
            proof = runner.source_proof(item)
            source = Path(item['checkout']) / item['lock_path']
            data = source.read_bytes()
            if (len(data) != item['lock_bytes'] or sha256(data) != proof['sha256']
                    or git_blob_sha1(data) != proof['git_blob_sha1']):
                raise StopRun(item['label'] + ': source changed between proof and snapshot copy')
            dest = runner.locks_dir / f"{item['label']}.Cargo.lock"
            with dest.open('xb') as stream:
                stream.write(data); stream.flush(); os.fsync(stream.fileno())
            proof['snapshot_path'] = str(dest)
            runner.manifest['source_inputs'].append(proof)
            runner.verify_lock_snapshot(item, proof, 'immediately-after-copy')

        shared_db = Path('/Users/evokessler/.cargo/advisory-db')
        shared_head_before = runner.git('shared-db-head-before', shared_db, ['rev-parse', 'HEAD']).decode().strip()
        if shared_head_before != config['shared_default_db_head']:
            raise StopRun('shared default advisory DB HEAD differs from original observation')
        runner.manifest['shared_default_db_head_before'] = shared_head_before
        db_initial = runner.snapshot_db('initial')
        if db_initial['record_count'] != config['database']['expected_record_files']:
            raise StopRun('initial DB inventory count differs from pin')
        runner.manifest['database_snapshots'].append(db_initial)
        if runner.manifest['baseline_in_place']['advisory_count'] != config['database']['expected_advisory_count']:
            raise StopRun('baseline count does not match DB pin')
        runner.persist()

        env = runner.env()
        for item, lock_snapshot in zip(inputs, runner.manifest['source_inputs'], strict=True):
            before = runner.snapshot_db(lock_snapshot['label'] + '-before')
            if before['inventory_sha256'] != db_initial['inventory_sha256'] or before['head'] != db_initial['head']:
                raise StopRun('DB identity/record inventory changed before scan')
            runner.manifest['database_snapshots'].append(before)
            runner.persist()
            argv = [str(tool), 'audit', '--file', lock_snapshot['snapshot_path'],
                    '--db', str(db), '--no-fetch', '--no-yanked', '--format', 'json']
            runner.verify_lock_snapshot(item, lock_snapshot, 'immediately-before-audit')
            try:
                code, stdout, stderr = runner.run('audit-' + item['label'], argv, ROOT, 60.0, env, (0, 1, 2))
            finally:
                runner.verify_lock_snapshot(item, lock_snapshot, 'immediately-after-audit')
            after = runner.snapshot_db(lock_snapshot['label'] + '-after')
            if after['inventory_sha256'] != before['inventory_sha256'] or after['head'] != before['head']:
                raise StopRun('DB identity/record inventory changed during scan')
            runner.manifest['database_snapshots'].append(after)
            runner.persist()
            if code == 2:
                raise StopRun('audit command failed operationally; raw output retained')
            result = runner.validate_report('audit-' + item['label'], stdout, stderr, code,
                                            lock_snapshot, after, config['database']['expected_advisory_count'])
            runner.manifest['scan_results'].append(result)
            runner.persist()

        # Verify input sources and shared/default database remained untouched.
        for item, proof in zip(inputs, runner.manifest['source_inputs'], strict=True):
            final_proof = runner.source_proof(item)
            if (final_proof['head_observed'] != proof['head_observed']
                    or final_proof['git_blob_sha1'] != proof['git_blob_sha1']
                    or final_proof['sha256'] != proof['sha256']):
                raise StopRun(item['label'] + ': source provenance changed during packet')
        if file_hash(previous_packet / 'scan-receipt.json')[0] != config['previous_baseline']['receipt_sha256']:
            raise StopRun('original attempt-2 receipt changed during packet')
        shared_head = runner.git('shared-db-head-after', shared_db, ['rev-parse', 'HEAD']).decode().strip()
        if shared_head != shared_head_before:
            raise StopRun('shared default advisory DB HEAD changed')
        runner.manifest['postchecks'] = {'source_lock_hashes_unchanged': True,
                                         'shared_default_db_head_after': shared_head,
                                         'shared_default_db_head_unchanged': True,
                                         'old_003_snapshot_preserved_unscanned': True}
        runner.manifest['status'] = 'complete'
        runner.manifest['finished_at'] = utc_now()
        runner.persist()
        return 0
    except BaseException as exc:
        runner.manifest['status'] = 'failed'
        runner.manifest['failure'] = f'{type(exc).__name__}: {exc}'
        runner.manifest['finished_at'] = utc_now()
        runner.persist()
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
