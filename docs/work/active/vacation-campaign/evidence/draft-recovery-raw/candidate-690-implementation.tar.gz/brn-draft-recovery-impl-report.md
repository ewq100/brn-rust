# Writing composer draft recovery candidate

- Local candidate `690c2c3f31a0f11e3405f2f2d0479be024190eb8` on `codex/writing-draft-recovery`; baseline `bc8a08e64b0dc1e2b33ff181dfdb54b62f59f5e4`.
- Worktree `/Users/evokessler/.codex/worktrees/export-durability/brn-rust` is clean. No push, PR, merge, release or native launch.
- Complete final patch: `/tmp/brn-draft-recovery-impl-final.diff`; SHA-256 `5b9f6e2415776e9f78c2c6de180a38f6e57d1c3db4ffdac409eccb75523eec56`.
- Machine-readable complete commands, environment per attempt, source/check hashes and native bindings: `/tmp/brn-draft-recovery-impl-qualification.json`.

The existing first-passage-comment regression retains its original exact Unicode/multiline draft and unrelated-note/draft assertions. It now passes at the same reopened-composer assertion that failed twice against old production. Both old logs and all intermediate patches/logs remain intact.

`Store::transfer_chat_draft` owns the generation/collision decision under the existing SQLite writer transaction. Optional exact generations distinguish absence from a stored generation-zero row. It refuses any stale source/target or occupied target, inserts exact latest text at the target and retains an empty advancing source tombstone in one commit. A synthetic abort on the source clear proves target insertion rolls back. `save_chat_draft` is unchanged.

`adopt_writing_thread` supplies visible Note text or the stored Note draft while another chat is shown. It updates cached generations/drafts/chat only after the committed receipt. If an explicitly opened target is already displayed and empty, it restores the editor together with the cache; live target typing refuses even before autosave has fired. Failed persistence leaves saved rows, cached generations and visible input intact, with an error notice. The existing rewrite chain receives its Window solely to synchronize that editor. Ordinary composer send/queue and contextual Edit note paths are untouched.

Final source checks all passed: original regression1, draft family22, full chat_storage11, full desktop336 with1existing ignored, strict all-target desktop/core Clippy, formatting and diff check. All Cargo build/test/lint calls used direct pinned1.98.1, --locked --offline --jobs1 and the supplied shared target/helpers; the runner enforced >=2GiB before start and stopped its own process group below1GiB. No low-disk stop occurred.

The ignored desktop supply test needs a separate CLI-useful-intake fixture. Cargo retained its pre-existing block0.1.6 future-compatibility advisory. Full core broader checks may run hosted; this local scope exercised the complete affected storage test family.

Ordinary production `native-ui` build passed once after the final source pin. Immutable executable and supplied matching helpers: `/Users/evokessler/.codex/artifacts/brn-draft-recovery/20261020T121434Z-690c2c3f`. Manifest: `/Users/evokessler/.codex/artifacts/brn-draft-recovery/20261020T121434Z-690c2c3f/manifest.json`. Executable SHA-256 `6d220deea6fe5196fc1df8c7cf9c694982349df45313b7003b5f6f2651441144`. Copies are read-only; earlier artifacts and shared targets were preserved.

Implementation and local checks are complete. Independent review remains lead-owned; native observation/owner acceptance are pending and unclaimed. Next: review/disposition and authorized integration, then reconcile this source/binary binding before the later synthetic Mac recovery journey.
