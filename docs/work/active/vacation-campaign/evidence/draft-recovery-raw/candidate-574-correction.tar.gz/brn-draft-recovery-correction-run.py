import subprocess, pathlib, os, sys, time, shutil, signal, json, hashlib, datetime
root='/Users/evokessler/.codex/worktrees/export-durability/brn-rust'
slug=sys.argv[1]
command=sys.argv[2:]
base=pathlib.Path('/tmp/brn-draft-recovery-correction-'+slug)
if base.with_suffix('.log').exists():
    raise SystemExit('Refusing to replace existing attempt log')
env=os.environ.copy()
toolchain='/Users/evokessler/.rustup/toolchains/1.98.1-aarch64-apple-darwin'
overrides={'PATH':toolchain+'/bin:'+env['PATH'], 'CARGO_TARGET_DIR':'/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target', 'CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','DYLD_LIBRARY_PATH':toolchain+'/lib','BRN_XBERG_HELPER':'/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper','BRN_XBERG_HELPER_BRN':'/Users/evokessler/.codex/worktrees/notice-state/document-helpers/artifacts/brn-xberg-helper-brn'}
env.update(overrides)
free=shutil.disk_usage(root).free
if free<2*1024**3: raise SystemExit('Less than 2GiB available before build')
patch=subprocess.check_output(['git','diff','--binary'],cwd=root)
record={'command':command,'overrides':overrides,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_before_bytes':free}
base.with_suffix('.diff').write_bytes(patch)
start=time.monotonic()
with base.with_suffix('.log').open('w') as out:
    out.write(json.dumps(record)+'\n');out.flush()
    p=subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
    stopped=False
    while p.poll() is None:
        if shutil.disk_usage(root).free<1024**3:
            os.killpg(p.pid,signal.SIGTERM);stopped=True
            break
        time.sleep(3)
    code=p.wait()
record.update(exit_code=code,elapsed_seconds=round(time.monotonic()-start,2),free_after_bytes=shutil.disk_usage(root).free,stopped_for_disk=stopped)
base.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['command','patch_sha256','exit_code','elapsed_seconds','free_after_bytes','stopped_for_disk']}))
print('\n'.join(base.with_suffix('.log').read_text().splitlines()[1:][-28:]))
raise SystemExit(code)
