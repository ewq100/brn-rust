# Composer recovery attention correction

- Local frozen candidate `5744d102573134474c38ae1352ea1abfccb53567` on `codex/writing-draft-recovery`; clean worktree.
- Preserved parent `690c2c3f31a0f11e3405f2f2d0479be024190eb8` and all original implementation/evidence/native artifacts.
- Correction diff SHA-256 `18587c448196b6c3f6d320e15a693e0e2988a46ddeaeec1db805d79110f4c2f7` at `/tmp/brn-draft-recovery-correction-final.diff`.
- Complete `bc8a08e64b0dc1e2b33ff181dfdb54b62f59f5e4` to corrected candidate diff SHA-256 `053e287b24c5f06541299f39f804bb5668b3a7995011e900d1f69c0bf39e3ee7` at `/tmp/brn-draft-recovery-correction-complete-candidate.diff`.
- Commands, environments, source/check/log hashes and native bindings: `/tmp/brn-draft-recovery-correction-qualification.json`.

The independent P2 is validated. On unchanged690 production, the new actual first-comment handler witness ran with an injected bounded background worker. Its Finished event went through poll_worker. Draft/source/target/cached generations remained intact, then the notice assertion failed: completion text replaced the unresolved recovery/copy warning. The compiled failure is retained in `02-old-source-red` and its test-only patch. No real provider or native interaction was used.

The existing NoticeState now retains only diagnosed composer recovery attention keyed by Note. Ordinary set/clear/startup/completion still maintain ordinary/work state beneath it, and completion still records its exact remembered result and tone. Recovery attention has its own Error provenance and names the affected Note. A committed successful handoff removes only that Note's attention. Explicit Dismiss removes only the currently displayed recovery warning and hides the underlying ordinary banner; Last work status can still restore the remembered work outcome. Ordinary errors keep their prior non-sticky lifecycle. No string matching or general alert bus/framework was added.

The same poller witness turns green and checks rendered warning visibility, exact unchanged draft data/generations, Dismiss and work-result restoration. A second actual handler witness creates two failed Note handoffs, retries the second successfully while the first warning remains identifiable even with another Note displayed, then retries the first successfully and clears its attention. The NoticeState transition test covers input/startup clear, completion, exact-scope acknowledgement, one-warning Dismiss, remembered outcome provenance and ordinary-error replacement.

Final-source checks passed: background witness1, draft focus24, notice focus17, full desktop339 with1existing ignored, strict all-target desktop Clippy, fmt/diff checks and one ordinary native-ui production build. Final broad receipts pin clean `5744d102573134474c38ae1352ea1abfccb53567`. Unchanged complete chat_storage11 qualification is reused from690, whose core tree remains identical. The ignored external CLI-intake fixture and pre-existing block0.1.6 advisory remain visible.

New immutable production app/helpers/manifest: `/Users/evokessler/.codex/artifacts/brn-draft-recovery/20261020T122407Z-5744d102`. App SHA-256 `ef3034acdd2654554ce1b606ae0371ea953fc3b4001e08269c66edb878874acb`. Source commit/tree, exact build log and unchanged supplied helper source/receipt bindings are in its manifest. Prior690 executable hash was rechecked unchanged. Nothing was launched.

The build slot is released. Independent targeted review/disposition remains lead-owned; native observation, owner acceptance, publication and integration remain separate pending/unclaimed gates. No push, PR, merge or release occurred here.
