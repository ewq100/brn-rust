# Composer draft adoption reproduction

## Scope and checkout

- Worktree: `/Users/evokessler/.codex/worktrees/export-durability/brn-rust`
- Branch: `codex/writing-draft-recovery`
- Tested source: old production HEAD `bc8a08e64b0dc1e2b33ff181dfdb54b62f59f5e4`
- Only changed file: `crates/brn-desktop/src/threads_writing_tests.rs`
- `git diff --check`: passed. No production repair was made.

The existing `adding_passage_feedback_keeps_the_document_and_does_not_start_ai` test now uses the actual first `post_comment` path. It types an exact multiline Unicode draft into a Note's `NewForNote` composer, posts a passage comment, confirms the comment creates/adopts a Thread without starting AI, then opens a fresh `ThreadsUi` over the same disposable SQLite workspace without changing or navigating the original composer. It asserts the exact text is recovered from the Thread destination after reopening. It also checks the Note bytes and an unrelated Note plus an unrelated saved Thread draft remain intact.

## Old-source result

The targeted test compiled and ran twice against the unchanged production implementation. Both failures were behavioral at the new recovery assertion, not compile or harness failures:

- Attempt 1: test finished in 0.04s; restarted composer was `""`, expected `"Keep this draft · õun\nSecond line — preserved."`; exit 101. Output: `/tmp/brn-draft-recovery-attempts/attempt-1-old-source.log`.
- Attempt 2 after adding the unrelated Note/draft preservation assertions: same exact result at final test line 82; exit 101. Output: `/tmp/brn-draft-recovery-attempts/attempt-2-old-source.log`.

Command for both attempts:

```sh
cargo test --locked --offline --jobs 1 --features native-ui,native-test-support -p brn-desktop adding_passage_feedback_keeps_the_document_and_does_not_start_ai
```

Both used the direct Rust 1.98.1 toolchain, shared target `/Users/evokessler/.codex/worktrees/vacation-hardening/brn-rust/target`, the supplied helper paths, and serial test execution. `cargo clean -p brn-desktop` removed 50 package artifacts (390.7 MiB) before the first attempt; the affected package rebuilt from this checkout. Available disk was 27 GiB before and after the runs.

## Hashes and artifacts

- Initial regression source before adding unrelated-draft assertions: SHA-256 `63e51089fc664a62ef6eac5ad7889865785c2a07b00202489851490d17992953`; initial patch SHA-256 `a3c97dd8a2ec2fa057a699669898bc80e18f5c316e4c790f6490f445931c8b07`.
- Final test source SHA-256 `12492a9d61d14b1018e98a46bf9a18de51c2abdc3fb4c7306cb7835ad53c0ce9`.
- Final binary patch SHA-256 `b9fc6a28a9e4c6be1f2e002b7dd1aca2c137f9c5cbcf0f92bd1abe6f66731864`; patch: `/tmp/brn-draft-recovery-patch.diff`.
- Test output hashes: attempt 1 `97d12f74466c5c38a09d67deac2965bdd53df6108bab0023a8299a1c54e3e4d8`; attempt 2 `f4ba2236d024f2e6143be1e834c2587f0c5a36e69e332c591b039f4ff878231e`.

This establishes the requested old-source reproduction. The test remains red until the separately selected production repair is made and the same targeted test passes.
